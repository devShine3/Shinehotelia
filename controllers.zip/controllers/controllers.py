import io
import xlsxwriter
from odoo import http
from odoo.http import request
import base64


class MyModelController(http.Controller):
    @http.route("/hotelia/index", type="http", auth="public")
    def index(self):
        return "hello world"

    @http.route("/hotelia/download_excel/", auth="public")
    def download_excel_controller(self):
        # Create a new Excel workbook
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {"in_memory": True})
        worksheet = workbook.add_worksheet()
        worksheet.set_column("A:I", 20)

        # Write data to the worksheet
        data = [
            [
                "guest_name",
                "arrival",
                "departure",
                "room_type",
                "room_no",
                "group_id",
                "agent_id",
                "company_id",
            ],
            [
                "Ba",
                "2023-03-07 06:30:00",
                "2023-03-08 10:59:55",
                "Executive",
                601,
                "AAAGroup",
                "Agent1",
                "AAA",
            ],
        ]
        for row_num, row_data in enumerate(data):
            for col_num, cell_data in enumerate(row_data):
                worksheet.write(row_num, col_num, cell_data)

        # Close the workbook
        workbook.close()

        # Encode the workbook data as a base64-encoded string
        excel_data = base64.b64encode(output.getvalue())

        # Set the file name and content type
        file_name = "Reservation Sample File.xlsx"
        content_type = (
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )

        # Return the file as a response
        response = request.make_response(base64.b64decode(excel_data))
        response.headers.set("Content-Disposition", "attachment", filename=file_name)
        response.headers.set("Content-Type", content_type)
        response.set_cookie("fileToken", file_name)
        return response

    @http.route(["/salesdata/"], type="http", auth="public", website=True)
    def sale_data(self, **post):
        sales_data = request.env["hotel.bill"].sudo().search([])
        values = {"records": sales_data}
        return request.render("hotelia.tmp_sales_data", values)
