from odoo import http, SUPERUSER_ID, _
from odoo.addons.portal.controllers.portal import CustomerPortal
from odoo.exceptions import (
    ValidationError,
    AccessError,
    MissingError,
    UserError,
    AccessDenied,
)
from odoo.http import request, content_disposition
import re
from io import BytesIO
import xlsxwriter
import io
from odoo import models, api, _, fields
import time
from datetime import timedelta, datetime
from odoo.exceptions import UserError
import logging

_logger = logging.getLogger(__name__)


class GuestInHouseCustomerPortal(CustomerPortal):
    _inherit = "report.report_xlsx.abstract"

    @http.route(["/my/guest_in_house/report"], type="http", auth="public", website=True)
    def portal_guest_in_house_report(
        self, access_token=None, report_type=None, download=False, **kw
    ):
        guest_in_house_data = request.session.get("guest_in_house_data")
        # guest_in_house_excel_data = request.session.get('guest_in_house_excel_data')
        company = request.env.company
        values = {
            "data": guest_in_house_data["data"],
            "lines": guest_in_house_data["lines"],
            # 'data': guest_in_house_excel_data['data'],
            "company": {
                "logo": company.logo,
                "company_details": company.company_details,
            },
            "page_name": "guest_in_house_report",
        }
        return request.render("hotelia.portal_guest_in_house_page", values)

    @http.route(
        ["/my/guest_in_house/report/download"], type="http", auth="public", website=True
    )
    def guest_in_house_download(self, **kw):
        guest_in_house = request.session.get("guest_in_house_data")
        return self._show_guest_in_house_report(
            model=guest_in_house,
            report_type="pdf",
            report_ref="hotelia.action_guest_in_house_template",
            download=True,
        )

    # @http.route(['/my/guest_in_house/report/download_xlsx'], type='http', auth="public", website=True)
    # def guest_in_house_download_xlsx(self, **kw):
    # data = {}
    # data['form'] = {
    #     'report_date': fields.Date.today(),
    #     # Add other fields as needed for your XLSX report
    # }
    # print(data['from'])
    # report = request.env.ref('hotelia.action_guest_in_house_template_xlsx').with_context(landscape=True)

    # Generate the XLSX report
    # report_action = report.report_action(request, data=data)
    # data = {'report_type': report_type, }
    # print_data = request.session.get('print_data')
    # Return the report action to trigger the download
    # return report_action
    # guest_in_house = request.session.get('guest_in_house_data')
    # guest_in_house = request.session.get('guest_in_house_data')
    # _logger.debug("guest_in_house_data: %s", guest_in_house_data)
    # _logger.debug("guest_in_house_excel_data: %s", guest_in_house)
    # print(guest_in_house)
    # return self._show_guest_in_house_report(model=guest_in_house, report_type="xlsx",
    #                                         report_ref="hotelia.action_guest_in_house_template_xlsx", download=True)
    # result = report.hotelia.report_gih_xlsx.generate_xlsx_report()
    # print(result)
    # xlsx = request.env['report.hotelia.report_gih_xlsx'].create({})
    # print(wizard)
    # xlsx.generate_xlsx_report()
    # print(xlsx.generate_xlsx_report())
    # return ("hi")
    # return self._show_guest_in_house_report(model=wizard, report_type="xlsx",
    #                                         report_ref="hotelia.action_guest_in_house_template", download=True)
    # data = request.session.get('guest_in_house_data')
    # Excel_data = request.env
    # xlsx_report = request.env['report.hotelia.report_gih_xlsx']
    # workbook = "my_workbook.xlsx"
    # data = {}
    # data['form'] = xlsx_report.read()
    # lines = xlsx_report.get_lines(data.get('form'))
    # xlsx_report.generate_xlsx_report(xlsx_report, workbook, data)
    # return _("Function called successfully.")
    # return self._show_guest_in_house_report(model=guest_in_house, report_type="xlsx", report_ref="hotelia.action_guest_in_house_template_xlsx", download=True)

    def _show_guest_in_house_report(
        self, model, report_type, report_ref, download=False
    ):
        if report_type not in ("html", "pdf", "text"):
            raise UserError(_("Invalid report type: %s", report_type))

        guest_in_house = model

        report_sudo = request.env.ref(report_ref).with_user(SUPERUSER_ID)

        if not isinstance(report_sudo, type(request.env["ir.actions.report"])):
            raise UserError(_("%s is not the reference of a report", report_ref))

        if hasattr(guest_in_house, "company_id"):
            report_sudo = report_sudo.with_company(guest_in_house.company_id)

        method_name = "_render_qweb_%s" % (report_type)
        # method_name_xlsx = '_render_xlsx'

        data = {
            "report_type": report_type,
        }
        print_data = request.session.get("print_data")
        # print(print_data)
        data["form"] = print_data["form"]
        # print(data)

        # if report_type == 'xlsx':
        #     report_method = getattr(report_sudo, method_name_xlsx, None)
        #     if not report_method:
        #         raise UserError(_("HI XLSX"))
        # else:
        #     report_method = getattr(report_sudo, method_name, None)
        #     if not report_method:
        #         raise UserError(_("OK %s" % report_type))

        # report = report_method([guest_in_house], data=data)[0]
        report = getattr(report_sudo, method_name)([guest_in_house], data=data)[0]
        # print(report)
        reporthttpheaders = [
            (
                "Content-Type",
                "application/pdf" if report_type == "pdf" else "text/html",
            ),
            ("Content-Length", len(report)),
        ]
        if report_type == "pdf" and download:
            filename = "Guest In House Report.pdf"
            reporthttpheaders.append(
                ("Content-Disposition", content_disposition(filename))
            )
        return request.make_response(report, headers=reporthttpheaders)
        # if report_type == 'pdf' and download:
        #     filename = "Guest In House Report.pdf"
        #     reporthttpheaders = [
        #         ('Content-Type', 'application/pdf' if report_type == 'pdf' else 'text/html'),
        #         ('Content-Length', len(report)),
        #     ]
        #     reporthttpheaders.append(('Content-Disposition', content_disposition(filename)))
        # elif report_type == 'xlsx' and download:
        #     filename = "Guest In House Report Excel.xlsx"
        #     content_type = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        #     reporthttpheaders = [
        #         ('Content-Type', content_type),
        #         ('Content-Length', len(report)),
        #         ('Content-Disposition', content_disposition(filename))
        #     ]
        # return request.make_response(report, headers=reporthttpheaders)
