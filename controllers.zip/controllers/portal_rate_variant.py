from odoo import http, SUPERUSER_ID, _
from odoo.addons.portal.controllers.portal import CustomerPortal
from odoo.exceptions import (
    ValidationError,
    AccessError,
    MissingError,
    UserError,
    AccessDenied,
)
from odoo.http import request, content_disposition
import re


class RateVariantCustomerPortal(CustomerPortal):
    @http.route(["/my/rate_variant/report"], type="http", auth="public", website=True)
    def portal_rate_variant_report(
        self, access_token=None, report_type=None, download=False, **kw
    ):
        rv_data = request.session.get("rv_data")
        company = request.env.company
        values = {
            "data": rv_data["data"],
            "lines": rv_data["lines"],
            "company": {
                "logo": company.logo,
                "company_details": company.company_details,
            },
            "page_name": "rate_variant_report",
        }
        if (
            isinstance(values["data"]["report_date"].day, str)
            and isinstance(values["data"]["report_date"].month, str)
            and isinstance(values["data"]["report_date"].year, str)
        ):
            values["data"]["report_date"] = (
                str(values["data"]["report_date"].day)
                + "-"
                + str(values["data"]["report_date"].month)
                + "-"
                + str(values["data"]["report_date"].year)
            )
            for res in values["lines"]["rv"]:
                res["rsv_date"] = (
                    str(res["rsv_date"].day)
                    + "-"
                    + str(res["rsv_date"].month)
                    + "-"
                    + str(res["rsv_date"].year)
                )
                res["arrival"] = (
                    str(res["arrival"].day)
                    + "-"
                    + str(res["arrival"].month)
                    + "-"
                    + str(res["arrival"].year)
                )
                res["departure"] = (
                    str(res["departure"].day)
                    + "-"
                    + str(res["departure"].month)
                    + "-"
                    + str(res["departure"].year)
                )
        return request.render("hotelia.portal_rate_variant_page", values)

    @http.route(
        ["/my/rate_variant/report/download"], type="http", auth="public", website=True
    )
    def rate_variant_download(self, **kw):
        rv = request.session.get("rv_data")
        return self._show_rate_variant_report(
            model=rv,
            report_type="pdf",
            report_ref="hotelia.action_rv_report_template",
            download=True,
        )

    def _show_rate_variant_report(self, model, report_type, report_ref, download=False):
        if report_type not in ("html", "pdf", "text"):
            raise UserError(_("Invalid report type: %s", report_type))

        rv = model

        report_sudo = request.env.ref(report_ref).with_user(SUPERUSER_ID)

        if not isinstance(report_sudo, type(request.env["ir.actions.report"])):
            raise UserError(_("%s is not the reference of a report", report_ref))

        if hasattr(rv, "company_id"):
            report_sudo = report_sudo.with_company(rv.company_id)

        method_name = "_render_qweb_%s" % (report_type)
        data = {"report_type": report_type}
        print_data = request.session.get("print_data")
        data["form"] = print_data["form"]
        report = getattr(report_sudo, method_name)([rv], data=data)[0]
        reporthttpheaders = [
            (
                "Content-Type",
                "application/pdf" if report_type == "pdf" else "text/html",
            ),
            ("Content-Length", len(report)),
        ]
        if report_type == "pdf" and download:
            filename = "Rate Variant Report.pdf"
            reporthttpheaders.append(
                ("Content-Disposition", content_disposition(filename))
            )
        return request.make_response(report, headers=reporthttpheaders)
