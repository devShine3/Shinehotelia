from odoo import http, SUPERUSER_ID, _
from odoo.addons.portal.controllers.portal import CustomerPortal
from odoo.exceptions import (
    ValidationError,
    AccessError,
    MissingError,
    UserError,
    AccessDenied,
)
from odoo.http import request, content_disposition
import re


class PaymentDetailCustomerPortal(CustomerPortal):
    @http.route(["/my/payment_detail/report"], type="http", auth="public", website=True)
    def portal_pd_report(
        self, access_token=None, report_type=None, download=False, **kw
    ):
        pd_data = request.session.get("pd_data")
        company = request.env.company
        values = {
            "data": pd_data["data"],
            "lines": pd_data["lines"],
            "company": {
                "logo": company.logo,
                "company_details": company.company_details,
            },
            "page_name": "pd_report",
        }
        if (
            isinstance(values["data"]["report_date"].day, str)
            and isinstance(values["data"]["report_date"].month, str)
            and isinstance(values["data"]["report_date"].year, str)
        ):
            values["data"]["report_date"] = (
                str(values["data"]["report_date"].day)
                + "-"
                + str(values["data"]["report_date"].month)
                + "-"
                + str(values["data"]["report_date"].year)
            )
            for res in values["lines"]["pd"]:
                res["rsv_date"] = (
                    str(res["rsv_date"].day)
                    + "-"
                    + str(res["rsv_date"].month)
                    + "-"
                    + str(res["rsv_date"].year)
                )
                res["arrival"] = (
                    str(res["arrival"].day)
                    + "-"
                    + str(res["arrival"].month)
                    + "-"
                    + str(res["arrival"].year)
                )
                res["departure"] = (
                    str(res["departure"].day)
                    + "-"
                    + str(res["departure"].month)
                    + "-"
                    + str(res["departure"].year)
                )
        return request.render("hotelia.portal_pd_page", values)

    @http.route(
        ["/my/payment_detail/report/download"], type="http", auth="public", website=True
    )
    def pd_download(self, **kw):
        pd = request.session.get("pd_data")
        return self._show_pd_report(
            model=pd,
            report_type="pdf",
            report_ref="hotelia.action_pd_report_template",
            download=True,
        )

    def _show_pd_report(self, model, report_type, report_ref, download=False):
        if report_type not in ("html", "pdf", "text"):
            raise UserError(_("Invalid report type: %s", report_type))

        pd = model

        report_sudo = request.env.ref(report_ref).with_user(SUPERUSER_ID)

        if not isinstance(report_sudo, type(request.env["ir.actions.report"])):
            raise UserError(_("%s is not the reference of a report", report_ref))

        if hasattr(pd, "company_id"):
            report_sudo = report_sudo.with_company(pd.company_id)

        method_name = "_render_qweb_%s" % (report_type)
        data = {"report_type": report_type}
        print_data = request.session.get("print_data")
        data["form"] = print_data["form"]
        report = getattr(report_sudo, method_name)([pd], data=data)[0]
        reporthttpheaders = [
            (
                "Content-Type",
                "application/pdf" if report_type == "pdf" else "text/html",
            ),
            ("Content-Length", len(report)),
        ]
        if report_type == "pdf" and download:
            filename = "Payment Detail Report.pdf"
            reporthttpheaders.append(
                ("Content-Disposition", content_disposition(filename))
            )
        return request.make_response(report, headers=reporthttpheaders)
