from odoo import http, SUPERUSER_ID, _
from odoo.addons.portal.controllers.portal import CustomerPortal
from odoo.exceptions import (
    ValidationError,
    AccessError,
    MissingError,
    UserError,
    AccessDenied,
)
from odoo.http import request, content_disposition
import re


class TransactionCustomerPortal(CustomerPortal):
    @http.route(["/my/transactions/report"], type="http", auth="public", website=True)
    def portal_transactions_report(
        self, access_token=None, report_type=None, download=False, **kw
    ):
        transaction_data = request.session.get("transaction_data")
        company = request.env.company
        values = {
            "data": transaction_data["data"],
            "lines": transaction_data["lines"],
            "company": {
                "logo": company.logo,
                "company_details": company.company_details,
            },
            "page_name": "transactions_report",
        }
        return request.render("hotelia.portal_transaction_page", values)

    @http.route(
        ["/my/transactions/report/download"], type="http", auth="public", website=True
    )
    def transaction_download(self, **kw):
        transaction = request.session.get("transaction_data")
        return self._show_transaction_report(
            model=transaction,
            report_type="pdf",
            report_ref="hotelia.action_transaction_report_template",
            download=True,
        )

    def _show_transaction_report(self, model, report_type, report_ref, download=False):
        if report_type not in ("html", "pdf", "text"):
            raise UserError(_("Invalid report type: %s", report_type))

        transaction = model

        report_sudo = request.env.ref(report_ref).with_user(SUPERUSER_ID)

        if not isinstance(report_sudo, type(request.env["ir.actions.report"])):
            raise UserError(_("%s is not the reference of a report", report_ref))

        if hasattr(transaction, "company_id"):
            report_sudo = report_sudo.with_company(transaction.company_id)

        method_name = "_render_qweb_%s" % (report_type)
        data = {"report_type": report_type}
        print_data = request.session.get("print_data")
        data["form"] = print_data["form"]
        report = getattr(report_sudo, method_name)([transaction], data=data)[0]
        reporthttpheaders = [
            (
                "Content-Type",
                "application/pdf" if report_type == "pdf" else "text/html",
            ),
            ("Content-Length", len(report)),
        ]
        if report_type == "pdf" and download:
            # filename = "%s.pdf" % (re.sub('\W+', '-', transaction._get_report_base_filename()))
            filename = "Transaction Report.pdf"
            reporthttpheaders.append(
                ("Content-Disposition", content_disposition(filename))
            )
        return request.make_response(report, headers=reporthttpheaders)
