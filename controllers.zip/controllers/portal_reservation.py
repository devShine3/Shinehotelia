from odoo import http, SUPERUSER_ID, _
from odoo.addons.portal.controllers.portal import CustomerPortal
from odoo.exceptions import (
    ValidationError,
    AccessError,
    MissingError,
    UserError,
    AccessDenied,
)
from odoo.http import request, content_disposition
import re


class ReservationCustomerPortal(CustomerPortal):
    @http.route(["/my/reservations/report"], type="http", auth="public", website=True)
    def portal_reservations_report(
        self, access_token=None, report_type=None, download=False, **kw
    ):
        reservation_data = request.session.get("reservation_data")
        company = request.env.company
        values = {
            "data": reservation_data["data"],
            "lines": reservation_data["lines"],
            "company": {
                "logo": company.logo,
                "company_details": company.company_details,
            },
            "page_name": "reservations_report",
        }
        if (
            isinstance(values["data"]["report_date"].day, str)
            and isinstance(values["data"]["report_date"].month, str)
            and isinstance(values["data"]["report_date"].year, str)
        ):
            values["data"]["report_date"] = (
                str(values["data"]["report_date"].day)
                + "-"
                + str(values["data"]["report_date"].month)
                + "-"
                + str(values["data"]["report_date"].year)
            )
            for res in values["lines"]["reservation"]:
                res["rsv_date"] = (
                    str(res["rsv_date"].day)
                    + "-"
                    + str(res["rsv_date"].month)
                    + "-"
                    + str(res["rsv_date"].year)
                )
                res["arrival"] = (
                    str(res["arrival"].day)
                    + "-"
                    + str(res["arrival"].month)
                    + "-"
                    + str(res["arrival"].year)
                )
                res["departure"] = (
                    str(res["departure"].day)
                    + "-"
                    + str(res["departure"].month)
                    + "-"
                    + str(res["departure"].year)
                )
        return request.render("hotelia.portal_reservation_page", values)

    @http.route(
        ["/my/reservations/report/download"], type="http", auth="public", website=True
    )
    def reservation_download(self, **kw):
        reservation = request.session.get("reservation_data")
        return self._show_reservation_report(
            model=reservation,
            report_type="pdf",
            report_ref="hotelia.action_reservation_report_template",
            download=True,
        )
        # return request.env['hotelia.action_reservation_report_template'].report_action(self, data=print_data)

        # print_data = request.session.get('print_data')
        # reservation_wizard = request.env['hotel.reservation.report.wizard'].create({})
        # report = reservation_wizard.print_preview(data=print_data)
        # reporthttpheaders = [
        #     ('Content-Type', 'application/pdf'), #'text/html'
        #     ('Content-Length', len(report)),
        # ]
        # return request.make_response(report, headers=reporthttpheaders)

        # get reservation using print_data
        # reservation_report_details = request.env['report.hotelia.report_reservation_details']
        # reservation = reservation_report_details._get_report_values(docids=None, data=print_data)

    def _show_reservation_report(self, model, report_type, report_ref, download=False):
        if report_type not in ("html", "pdf", "text"):
            raise UserError(_("Invalid report type: %s", report_type))

        reservation = model

        report_sudo = request.env.ref(report_ref).with_user(SUPERUSER_ID)

        if not isinstance(report_sudo, type(request.env["ir.actions.report"])):
            raise UserError(_("%s is not the reference of a report", report_ref))

        if hasattr(reservation, "company_id"):
            report_sudo = report_sudo.with_company(reservation.company_id)

        method_name = "_render_qweb_%s" % report_type
        data = {"report_type": report_type}
        print_data = request.session.get("print_data")
        data["form"] = print_data["form"]
        report = getattr(report_sudo, method_name)([reservation], data=data)[0]
        reporthttpheaders = [
            (
                "Content-Type",
                "application/pdf" if report_type == "pdf" else "text/html",
            ),
            ("Content-Length", len(report)),
        ]
        if report_type == "pdf" and download:
            # filename = "%s.pdf" % (re.sub('\W+', '-', reservation._get_report_base_filename()))
            filename = "Reservation Report.pdf"
            reporthttpheaders.append(
                ("Content-Disposition", content_disposition(filename))
            )
        return request.make_response(report, headers=reporthttpheaders)
