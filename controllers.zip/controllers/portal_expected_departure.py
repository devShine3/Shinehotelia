from odoo import http, SUPERUSER_ID, _
from odoo.addons.portal.controllers.portal import CustomerPortal
from odoo.exceptions import (
    ValidationError,
    AccessError,
    MissingError,
    UserError,
    AccessDenied,
)
from odoo.http import request, content_disposition
import re


class EDepartureCustomerPortal(CustomerPortal):
    @http.route(
        ["/my/expected_departure/report"], type="http", auth="public", website=True
    )
    def portal_edeparture_report(
        self, access_token=None, report_type=None, download=False, **kw
    ):
        dp_data = request.session.get("dp_data")
        company = request.env.company
        values = {
            "data": dp_data["data"],
            "lines": dp_data["lines"],
            "company": {
                "logo": company.logo,
                "company_details": company.company_details,
            },
            "page_name": "edeparture_report",
        }
        if (
            isinstance(values["data"]["report_date"].day, str)
            and isinstance(values["data"]["report_date"].month, str)
            and isinstance(values["data"]["report_date"].year, str)
        ):
            values["data"]["report_date"] = (
                str(values["data"]["report_date"].day)
                + "-"
                + str(values["data"]["report_date"].month)
                + "-"
                + str(values["data"]["report_date"].year)
            )
            for res in values["lines"]["dp"]:
                res["rsv_date"] = (
                    str(res["rsv_date"].day)
                    + "-"
                    + str(res["rsv_date"].month)
                    + "-"
                    + str(res["rsv_date"].year)
                )
                res["arrival"] = (
                    str(res["arrival"].day)
                    + "-"
                    + str(res["arrival"].month)
                    + "-"
                    + str(res["arrival"].year)
                )
                res["departure"] = (
                    str(res["departure"].day)
                    + "-"
                    + str(res["departure"].month)
                    + "-"
                    + str(res["departure"].year)
                )
        return request.render("hotelia.portal_edeparture_page", values)

    @http.route(
        ["/my/expected_departure/report/download"],
        type="http",
        auth="public",
        website=True,
    )
    def edeparture_download(self, **kw):
        dp = request.session.get("dp_data")
        return self._show_edeparture_report(
            model=dp,
            report_type="pdf",
            report_ref="hotelia.action_edp_report_template",
            download=True,
        )

    def _show_edeparture_report(self, model, report_type, report_ref, download=False):
        if report_type not in ("html", "pdf", "text"):
            raise UserError(_("Invalid report type: %s", report_type))

        dp = model

        report_sudo = request.env.ref(report_ref).with_user(SUPERUSER_ID)

        if not isinstance(report_sudo, type(request.env["ir.actions.report"])):
            raise UserError(_("%s is not the reference of a report", report_ref))

        if hasattr(dp, "company_id"):
            report_sudo = report_sudo.with_company(dp.company_id)

        method_name = "_render_qweb_%s" % (report_type)
        data = {"report_type": report_type}
        print_data = request.session.get("print_data")
        data["form"] = print_data["form"]
        report = getattr(report_sudo, method_name)([dp], data=data)[0]
        reporthttpheaders = [
            (
                "Content-Type",
                "application/pdf" if report_type == "pdf" else "text/html",
            ),
            ("Content-Length", len(report)),
        ]
        if report_type == "pdf" and download:
            filename = "Expected Departure Report.pdf"
            reporthttpheaders.append(
                ("Content-Disposition", content_disposition(filename))
            )
        return request.make_response(report, headers=reporthttpheaders)
