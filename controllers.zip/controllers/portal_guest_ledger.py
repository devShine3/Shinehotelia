from odoo import http, SUPERUSER_ID, _
from odoo.addons.portal.controllers.portal import CustomerPortal
from odoo.exceptions import (
    ValidationError,
    AccessError,
    MissingError,
    UserError,
    AccessDenied,
)
from odoo.http import request, content_disposition
import re


class GuestLedgerCustomerPortal(CustomerPortal):
    @http.route(["/my/guest_ledger/report"], type="http", auth="public", website=True)
    def portal_guest_ledger_report(
        self, access_token=None, report_type=None, download=False, **kw
    ):
        guest_data = request.session.get("guest_data")
        company = request.env.company
        values = {
            "data": guest_data["data"],
            "lines": guest_data["lines"],
            "company": {
                "logo": company.logo,
                "company_details": company.company_details,
            },
            "page_name": "guest_ledger_report",
        }
        return request.render("hotelia.portal_guest_ledger_page", values)

    @http.route(
        ["/my/guest_ledger/report/download"], type="http", auth="public", website=True
    )
    def guest_ledger_download(self, **kw):
        guest = request.session.get("guest_data")
        return self._show_guest_ledger_report(
            model=guest,
            report_type="pdf",
            report_ref="hotelia.action_guest_ledger_report_template",
            download=True,
        )

    def _show_guest_ledger_report(self, model, report_type, report_ref, download=False):
        if report_type not in ("html", "pdf", "text"):
            raise UserError(_("Invalid report type: %s", report_type))

        guest = model

        report_sudo = request.env.ref(report_ref).with_user(SUPERUSER_ID)

        if not isinstance(report_sudo, type(request.env["ir.actions.report"])):
            raise UserError(_("%s is not the reference of a report", report_ref))

        if hasattr(guest, "company_id"):
            report_sudo = report_sudo.with_company(guest.company_id)

        method_name = "_render_qweb_%s" % (report_type)
        data = {"report_type": report_type}
        print_data = request.session.get("print_data")
        data["form"] = print_data["form"]
        report = getattr(report_sudo, method_name)([guest], data=data)[0]
        reporthttpheaders = [
            (
                "Content-Type",
                "application/pdf" if report_type == "pdf" else "text/html",
            ),
            ("Content-Length", len(report)),
        ]
        if report_type == "pdf" and download:
            # filename = "%s.pdf" % (re.sub('\W+', '-', transaction._get_report_base_filename()))
            filename = "Guest Ledger Report.pdf"
            reporthttpheaders.append(
                ("Content-Disposition", content_disposition(filename))
            )
        return request.make_response(report, headers=reporthttpheaders)
