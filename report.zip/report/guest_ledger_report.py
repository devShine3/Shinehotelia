# -*- coding: utf-8 -*-
from datetime import time
from odoo import models, api, _
from odoo.exceptions import UserError
from datetime import datetime, timedelta
import logging

_logger = logging.getLogger(__name__)


class ReportGL(models.AbstractModel):
    _name = "report.hotelia.report_guest_ledger"
    _description = "Guest Ledger Report"

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get("form"):
            raise UserError(
                _("Form content is missing, this report cannot be printed.")
            )
        return {
            "data": data["form"],
            "lines": self.get_lines(data.get("form")),
        }

    @api.model
    def get_lines(self, options):
        groups_sample = (
            {
                "summary_lines": [
                    {
                        "group": "currency",
                        "lines": [],
                        "total": {},
                        "net": 0.0,
                    }
                ],
                "detail_lines": [
                    {
                        "group": "date",
                        "currency": "currency_name",
                        "lines": [],
                        "total": {},
                        "net": 0.0,
                        "difference": 0.0,
                    }
                ],
            },
        )

        groups = {
            "summary_lines": [],
            "detail_lines": [],
            "payment_types": [],
            "grand_total": 0.0,
        }

        moves = {}
        where_clause = ""
        if options["report_type"] == "summary":
            sql = """
                select res.name,rs.name,res.guest_name,ag.name,res.remark,'',res.departure_date,
                sum(tl.trans_price),sum(tl.tax),sum(tl.service),sum(tl.discount),res.id
                                from hms_registration res
                                left join hmslite_agentsetup ag on res.reg_agent_id=ag.id
                                left join hms_room_setup rs on res.reg_room_no = rs.id
                                join hms_trans_line tl on res.id = tl.reg_id
                                join hms_transaction t on tl.trans_lines_id = t.id
                                where  res."Rsv_Type" = 'registration' 
                                and res.function_id = '2' %s and t.name !='Advance Receipt' 
                                and (tl.bill_id IS NULL OR tl.bill_name IS NULL)
                                Group by res.name,res.guest_name,res.departure_date,rs.name,ag.name,res.deposit,res.remark,res.id
                                order by res.name
                 """
            if options["report_format"] == "departure":
                if options["date_to"]:
                    where_clause += (
                        """and res.departure_date = '%s'  """ % options["date_to"]
                    )
                summary = sql % where_clause
            else:
                summary = sql % where_clause
            self.env.cr.execute(summary)
            results = self.env.cr.fetchall()
            if results:
                for result in results:
                    reg_no = str(result[11])
                    paid_amt = 0
                    company_obj = self.env.user.sudo().company_id

                    if reg_no:
                        for amt in reg_no:
                            paid_amt_sql = """
                                SELECT sum(tl.trans_price) + sum(tl.tax) + sum(tl.service) - sum(tl.discount)
                                FROM hms_trans_line tl
                                JOIN hms_transaction t ON tl.trans_lines_id = t.id
                                WHERE tl.reg_id = %s AND t.name = 'Advance Receipt' """ % int(
                                reg_no
                            )
                            self.env.cr.execute(paid_amt_sql)
                            paid_amt = self.env.cr.fetchone()[0] or 0.00
                            paid_amt = paid_amt * -1

                    base_currency = self.env["res.currency"].search(
                        [("hotelia_base_currency", "=", True)], limit=1
                    )
                    trans_line = (
                        self.env["hms.trans.line"]
                        .search(
                            [
                                ("reg_id", "=", result[11]),
                                ("trans_currency", "!=", base_currency.id),
                            ],
                            limit=1,
                        )
                        .trans_currency.id
                    )
                    _logger.info(f"{trans_line} --PPPPPPP")

                    if trans_line:
                        trans_currency = self.env["res.currency"].search(
                            [("id", "=", trans_line)], limit=1
                        )
                        rate = base_currency._get_conversion_rate(
                            trans_currency,
                            base_currency,
                            company_obj,
                            datetime.now().date(),
                        )
                        if rate is None:
                            rate = 1
                        total_amt = result[7] + result[8] + result[9] - result[10]
                        total_amt = total_amt * rate
                    else:
                        total_amt = result[7] + result[8] + result[9] - result[10]

                    net_amt = total_amt - paid_amt

                    if result[4] == "<p><br></p>":
                        remark = " "
                    else:
                        remark = result[4]

                    moves = {
                        "reg_no": result[0],
                        "room_no": result[1],
                        "guest_name": result[2],
                        "agent_name": result[3],
                        "remark": remark,
                        "trans_currency": result[5],
                        "total_amt": total_amt,
                        "paid_amt": paid_amt,
                        "net_amt": net_amt,
                    }
                    found = False
                    for item in groups["summary_lines"]:
                        if item:
                            found = True
                            break
                    if found == True:
                        item["lines"].append(moves)
                        item["net"] += net_amt
                    else:
                        detail_group = {
                            "group": result[5],
                            "lines": [moves],
                            "net": net_amt,
                        }
                        groups["summary_lines"].append(detail_group)

        if options["report_type"] == "detail":
            where_clause = ""
            where_advance_clause = ""
            transaction_sql = """
                select t.name,
                sum(tl.trans_price),sum(tl.tax),
                sum(tl.service), sum(tl.discount),0,
                c.name,reg.name,tl.id,rs.name,reg.guest_name,tl.trans_date,tl.trans_type
                                 from hms_trans_line tl
                                 join hms_transaction t on tl.trans_lines_id = t.id
                                 Join hms_registration reg on tl.reg_id = reg.id
                                 left join hms_room_setup rs on reg.reg_room_no = rs.id
                                 join res_currency c on tl.trans_currency = c.id
                         where tl.id is not null %s 
                         and (tl.bill_id IS NULL OR tl.bill_name IS NULL)
                         group by reg.name,tl.id,rs.name,reg.guest_name,
                         tl.trans_date,t.name, c.name,tl.trans_type
            """
            if options["report_format"] == "departure":
                if options["date_to"]:
                    where_clause += (
                        """and reg.departure_date = '%s'  """ % options["date_to"]
                    )
                sql_transaction = transaction_sql % where_clause
            else:
                sql_transaction = transaction_sql % where_clause

            self.env.cr.execute(sql_transaction)
            results = self.env.cr.fetchall()
            if results:
                for result in results:
                    company_obj = self.env.user.sudo().company_id
                    base_currency = self.env["res.currency"].search(
                        [("hotelia_base_currency", "=", True)], limit=1
                    )
                    trans_currency = self.env["res.currency"].search(
                        [("name", "=", result[6])], limit=1
                    )
                    rate = base_currency._get_conversion_rate(
                        trans_currency,
                        base_currency,
                        company_obj,
                        datetime.now().date(),
                    )

                    trans_price = result[1] + result[2] + result[3] - result[4]
                    trans_price = trans_price * rate

                    moves = {
                        "name": result[0],
                        "trans_price": trans_price or 0.00,
                        "trans_currency": result[6],
                        "RegNo": result[7],
                        "TransNo": result[8],
                        "TransDate": result[11],
                        "transtype": result[12],
                    }
                    found = False
                    for item in groups["detail_lines"]:
                        if item["group"]["reg_no"] == result[7]:
                            found = True
                            break
                    if found == True:
                        item["lines"].append(moves)
                        item["net"] += trans_price

                    else:
                        group = {
                            "reg_no": result[7],
                            "room_no": result[9],
                            "guest": result[10],
                        }
                        detail_group = {
                            "group": group,
                            "lines": [moves],
                            "net": trans_price,
                        }
                        groups["detail_lines"].append(detail_group)
        return groups
