# -*- coding: utf-8 -*-
# from datetime import date
# from datetime import time,datetime, timedelta
# from datetime import datetime
from datetime import datetime
from datetime import timedelta

from odoo import models, api, _, fields
from odoo.exceptions import UserError
import logging

_logger = logging.getLogger(__name__)


class GuestInHousetWizard(models.AbstractModel):
    _name = "report.hotelia.report_guest_in_house_details"
    _description = "Reservation Report"

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get("form"):
            raise UserError(
                _("Form content is missing, this report cannot be printed.")
            )
        return {
            "data": data["form"],
            "lines": self.get_lines(data.get("form")),
        }

    @api.model
    def get_lines(self, options):
        groups = {"reservation": [], "registration": [], "total": 0.0}

        moves = {}
        total_count = 0
        sql = """ select CASE WHEN res."Rsv_Type" in ('check_out','transfer') AND '%s' = res.departure_date THEN NULL ELSE res.name END,gl.name,res.arrival_date,res.departure_date,
              rt.name,res."Rsv_Type",rs.name ,res.reg_date,rs.name,
              ag.name,res.reg_room_type,res.reg_group_id,hc.name,
              hm.name,cast(res.reg_adult as int),cast(res.reg_child as int),gl.date_of_birth,
              gl.gender,res.contact_person,
              gl.nrc,gl.passport_no,'',res.reg_arrival,res.reg_departure,hg.citizen,hg.father_name,hg.street,gl.visa_no
              from hms_registration res
              join hms_guestline gl on res.id = gl.registration_id
              join hms_room_type rt on res.reg_room_type = rt.id
              join hotel_guest hg on hg.id=gl.guest_id
              left join hms_room_setup rs on res.reg_room_no = rs.id
              left join hmslite_agentsetup ag on res.reg_agent_id=ag.id
              left join hmslite_companysetup hc on res.reg_company_id=hc.id
              left join hms_national hm on gl.nationality=hm.id
              where res.id is not null and res.function_id = '2' and
              rt.name <>'Dummy Room'
               """ % (options["choose_date"])
        sql_count = """ select count(DISTINCT CASE WHEN res."Rsv_Type" in ('check_out','transfer') AND '%s' = res.departure_date THEN NULL ELSE res.name END)
              from hms_registration res
              join hms_guestline gl on res.id = gl.registration_id
              join hms_room_type rt on res.reg_room_type = rt.id
              join hotel_guest hg on hg.id=gl.guest_id
              left join hms_room_setup rs on res.reg_room_no = rs.id
              left join hmslite_agentsetup ag on res.reg_agent_id=ag.id
              left join hmslite_companysetup hc on res.reg_company_id=hc.id
              left join hms_national hm on gl.nationality=hm.id
              where res.id is not null and res.function_id = '2' and
              rt.name <>'Dummy Room'
                  """ % (options["choose_date"])

        string_date = ""
        if isinstance(options["choose_date"], str):
            string_date = options["choose_date"]
        else:
            string_date = options["choose_date"].strftime("%Y-%m-%d")

        # Convert the string to a date object
        date_obj = datetime.strptime(str(string_date), "%Y-%m-%d").date()
        # Add one day to the date
        new_date_obj_dep = date_obj - timedelta(days=1)
        new_date_obj_arriv = date_obj + timedelta(days=1)

        # Convert the new date object back to a string in the same format as the original string
        date_arrival = new_date_obj_arriv.strftime("%Y-%m-%d")
        if options["agent"]:
            sql = sql + """ and res.reg_agent_id=%s""" % options["agent"][0]
            sql_count = sql_count + """ and res.reg_agent_id=%s""" % options["agent"][0]
        if options["group"]:
            sql = sql + """ and res.reg_group_id='%s' """ % options["group"][1]
            sql_count = (
                sql_count + """ and res.reg_group_id='%s' """ % options["group"][1]
            )
        if options["company"]:
            sql = sql + """ and res.reg_company_id=%s""" % options["company"][0]
            sql_count = (
                sql_count + """ and res.reg_company_id=%s""" % options["company"][0]
            )
        if options["national"] == "local":
            sql = sql + """ and  hg.citizen = 'local' """
            sql_count = sql_count + """ and  hg.citizen = 'local' """
        if options["national"] == "foreigner":
            sql = sql + """ and  hg.citizen = 'foreign' """
            sql_count = sql_count + """ and  hg.citizen = 'foreign' """
        if options["choose_date"]:
            current_date = fields.Date.context_today(self)
            current_date = datetime.strptime(str(current_date), "%Y-%m-%d").date()

            choose_date = datetime.strptime(options["choose_date"], "%Y-%m-%d").date()

            if choose_date == current_date:
                sql = (
                    sql
                    + """ and '%s' >= res.arrival_date and '%s' <= res.departure_date and res."Rsv_Type" not in ('cancel', 'noshow', 'check_out') 
                    and (res."Rsv_Type" not in ('check_out','transfer') OR '%s' <> res.departure_date) """
                    % (options["choose_date"], options["choose_date"], options["choose_date"])
                )
                sql_count = (
                    sql_count
                    + """ and '%s' >= res.arrival_date and '%s' <= res.departure_date and res."Rsv_Type" not in ('cancel', 'noshow', 'check_out') """
                    % (options["choose_date"], options["choose_date"])
                )
            elif choose_date < current_date:
                sql = (
                    sql
                    + """ and '%s' >= res.arrival_date and '%s' <= res.departure_date and res."Rsv_Type" not in ('cancel', 'noshow') 
                    and (res."Rsv_Type" not in ('check_out','transfer') OR '%s' <> res.departure_date) """
                    % (options["choose_date"], options["choose_date"], options["choose_date"])
                )
                sql_count = (
                    sql_count
                    +""" and '%s' >= res.arrival_date and '%s' <= res.departure_date and res."Rsv_Type" not in ('cancel', 'noshow') """
                    % (options["choose_date"], options["choose_date"])
                )

        _logger.info(f"{sql} --guest in house sql query ")
        self.env.cr.execute(sql_count)
        results_count = self.env.cr.fetchall()
        for c in results_count:
            total_count = c[0]

        self.env.cr.execute(sql)
        results = self.env.cr.fetchall()
        if results:
            for result in results:
                visa = ""
                if result[20] and result[20] != "False":
                    visa = result[20]
                if result[16]:
                    date_of_birth = result[16] or 0
                    current_date = datetime.now()
                    age = current_date.year - date_of_birth.year
                    # Check if the birthday has already occurred this year
                    if current_date.month < date_of_birth.month or (
                        current_date.month == date_of_birth.month
                        and current_date.day < date_of_birth.day
                    ):
                        age -= 1
                else:
                    age = ""
                    # stay_duration
                if result[2] and result[3]:
                    sp = (result[3] - result[2]).days
                else:
                    sp = 0

                moves = {
                    "rsv_date": result[7],
                    "total_room": result[0],
                    "room_type": result[4],
                    "Rsv_Type": result[5],
                    "room_no": result[6],
                    "agent_id": result[9],
                    "group_id": result[11],
                    "company_id": result[12],
                    "guest_name": result[1],
                    "dob": result[16],
                    "age": age,
                    "sex": result[17],
                    "father": result[18],
                    "id": result[19],
                    "Visa": visa,
                    "national": result[13],
                    "address": result[21],
                    "arrival": result[2],
                    "departure": result[3],
                    "sp": sp,
                    "adult": result[14],
                    "child": result[15],
                    "father_name": result[25],
                    "address_street": result[26],
                    "visa_no" : result[27],
                }
                groups["reservation"].append(moves)
                groups["total"] = total_count
        return groups
