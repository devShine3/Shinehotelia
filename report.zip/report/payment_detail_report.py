# -*- coding: utf-8 -*-
from datetime import time
from odoo import models, api, _
from odoo.exceptions import UserError
from datetime import datetime, timedelta


class ReportTrans(models.AbstractModel):
    _name = "report.hotelia.report_payment_detail"
    _description = "Payment Detail Report"

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get("form"):
            raise UserError(
                _("Form content is missing, this report cannot be printed.")
            )
        return {
            "data": data["form"],
            "lines": self.get_lines(data.get("form")),
        }

    @api.model
    def _group_by(self):
        return """
            group by t.name, c.name
        """

    @api.model
    def get_lines(self, options):
        groups = {"transaction_lines": [], "sales": 0.0, "receipt": 0.0}
        where_clause = ""
        transaction_sql = """

        select b.bill_date,res.guest_name,rs.name,b.name,p.name,c.name,p.amount,rp.name,ag.name
            from hotel_payment_line p
            join hotel_payment hp on p.payment_code = hp.id
            join hotel_bill b on p.bill_id = b.id
			left join hms_registration res on b.reg_ids = res.id
            left join hms_room_setup rs on res.reg_room_no = rs.id
			left join hmslite_agentsetup ag on res.reg_agent_id=ag.id
            left join res_currency c on hp.currency = c.id
           left join res_users u on p.create_uid = u.id
           left join res_partner rp on u.partner_id = rp.id
            where p.id is not null %s order by b.name
        """

        if options["date_from"]:
            where_clause += " and b.bill_date >= '%s' " % options["date_from"]
        if options["date_to"]:
            string_date = options["date_to"]
            date_obj = datetime.strptime(str(string_date), "%Y-%m-%d").date()
            new_date_obj = date_obj + timedelta(days=1)
            date_to = new_date_obj.strftime("%Y-%m-%d")
            where_clause += " and b.bill_date < '%s' " % date_to

        if options["agent"] and options["all_or_agent"] == "agent":
            where_clause += " and ag.id= %s " % options["agent"][0]

        if options["user_id"] and options["report_type"] == "user":
            where_clause += " and u.id= %s " % options["user_id"][0]

        if options["payment_type"] and options["report_type"] == "payment":
            where_clause += " and hp.id= %s " % options["payment_type"][0]

        sql_transaction = transaction_sql % where_clause
        base_currency = self.env["res.currency"].search(
            [("hotelia_base_currency", "=", True)], limit=1
        )
        company_obj = self.env.user.sudo().company_id
        self.env.cr.execute(sql_transaction)
        results = self.env.cr.fetchall()
        if results:
            for result in results:
                moves = {
                    "bdate": result[0],
                    "guestname": result[1],
                    "room": result[2],
                    "bno": result[3],
                    "ptye": result[4],
                    "currency": result[5],
                    "amount": result[6],
                }
                groups["transaction_lines"].append(moves)
        return groups
