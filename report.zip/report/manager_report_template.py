# -*- coding: utf-8 -*-
from datetime import date as dt
from datetime import datetime, timedelta
from datetime import time

import datetime
from odoo import models, api, _
from odoo.exceptions import UserError
from odoo import models, fields, api
from dateutil import parser
import logging
from datetime import datetime, date

_logger = logging.getLogger(__name__)


class ReportManager(models.AbstractModel):
    _name = "report.hotelia.report_manager"
    _description = "Manager Report"

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get("form"):
            raise UserError(
                _("Form content is missing, this report cannot be printed.")
            )
        return {
            "data": data["form"],
            "lines": self.get_lines(data.get("form")),
        }

    @api.model
    def get_lines(self, options):
        groups = {
            "month_body_arr": [],
            "year_body_arr": [],
            "day_body_arr": [],
        }
        moves = {}
        # months = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
        today_date = dt.today()
        today = datetime.strptime(str(today_date), "%Y-%m-%d").date()
        current_month = today.month
        current_year = today.year
        if options["cyear"] == current_year:
            months = []
            for month in range(1, current_month + 1):
                months.append(month)
        else:
            months = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]

        month_dict = {
            1: "Jan",
            2: "Feb",
            3: "Mar",
            4: "Apr",
            5: "May",
            6: "Jun",
            7: "Jul",
            8: "Aug",
            9: "Sep",
            10: "Oct",
            11: "Nov",
            12: "Dec",
        }
        # bymonth
        if options["report_type"] == "bymonth":
            for month in months:
                work_in_sql = """
                        select count(id) from hms_registration
                            where "iamregistered" = 'True'
                            and id is not null AND EXTRACT(MONTH FROM create_date)=%s AND EXTRACT(Year FROM create_date)=%s
                """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(work_in_sql)
                results = self.env.cr.fetchall()
                work_in_count = 0
                for result in results:
                    work_in_count = result[0]

                # Room With Reservation
                r_with_r_sql = """
                                select count(id) from hotel_reservation 
                                    where id in (select reservation_id from hms_registration)
                                     AND EXTRACT(MONTH FROM create_date)=%s AND EXTRACT(Year FROM create_date)=%s
                            """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(r_with_r_sql)
                results = self.env.cr.fetchall()
                room_with_reserve = 0
                for result in results:
                    room_with_reserve = result[0]

                # Arrival Rooms
                arrival_sql = """
                        select count(id) from hotel_reservation 
                        where id not in (select id from hms_registration)
                        and "Rsv_Type" != 'check_out'
                         AND EXTRACT(MONTH FROM create_date)=%s AND EXTRACT(Year FROM create_date)=%s
                        """ % (
                    month,
                    options["cyear"],
                )

                self.env.cr.execute(arrival_sql)
                results = self.env.cr.fetchall()
                arr_room = 0
                for result in results:
                    arr_room = result[0]

                # Complimentary Rooms
                complimentary_sql = """
                        select  count(hr.id) from hms_registration hr
                        join hms_customer_type ct  on hr.reg_customer_type = ct.id where ct.name = 'complimentary' 
                        AND EXTRACT(MONTH FROM hr.create_date)=%s AND EXTRACT(Year FROM hr.create_date)=%s
                            """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(complimentary_sql)
                results = self.env.cr.fetchall()
                com_room = 0
                for result in results:
                    com_room = result[0]

                # house_use Rooms
                houseuse_sql = """
                        select count(id) from hotel_reservation  
                        where "Rsv_Type" = 'confirmed'
                        AND EXTRACT(MONTH FROM create_date)=%s AND EXTRACT(Year FROM create_date)=%s
                            """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(houseuse_sql)
                results = self.env.cr.fetchall()
                house_use = 0
                for result in results:
                    house_use = result[0]

                # Day Use  Rooms
                day_use_sql = """
                       select count(id) from hms_registration 
                               where "Rsv_Type" = 'check_out'
                                and arrival_date = departure_date
                        AND EXTRACT(MONTH FROM create_date)=%s AND EXTRACT(Year FROM create_date)=%s
                            """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(day_use_sql)
                results = self.env.cr.fetchall()
                day_use = 0
                for result in results:
                    day_use = result[0]

                # AgentRooms
                agent_room_sql = """
                       select count(hrs.id) from hms_registration  hr
                            join hms_room_setup as hrs on hrs.id= reg_room_no
                            where hr.reg_agent_id is not null 
                        AND EXTRACT(MONTH FROM hr.create_date)=%s AND EXTRACT(Year FROM hr.create_date)=%s
                            """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(agent_room_sql)
                results = self.env.cr.fetchall()
                agent_room = 0
                for result in results:
                    agent_room = result[0]

                # DepartureRooms
                departure_room_sql = """
                        select count(hrs.id) from hms_registration  hr
                            join hms_room_setup as hrs on hrs.id= reg_room_no
                            where  hr."Rsv_Type" = 'check_out' 
                            AND EXTRACT(MONTH FROM hr.create_date)=%s AND EXTRACT(Year FROM hr.create_date)=%s
                            """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(departure_room_sql)
                results = self.env.cr.fetchall()
                departure_room = 0
                for result in results:
                    departure_room = result[0]

                # OccupiedRooms
                occupied_room_sql = """
                        select count(id) from hms_room_setup
                            where  room_status= 'o_dirty'
                            AND EXTRACT(MONTH FROM create_date)=%s AND EXTRACT(Year FROM create_date)=%s
                            """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(occupied_room_sql)
                results = self.env.cr.fetchall()
                occupied_room = 0
                for result in results:
                    occupied_room = result[0]

                # arrival_guest
                arrival_guest_sql = """
                        select COALESCE(SUM(adult), 0),COALESCE(SUM(child), 0) from hotel_reservation 
                        where "Rsv_Type" = 'registration'
                        AND EXTRACT(MONTH FROM create_date)=%s AND EXTRACT(Year FROM create_date)=%s
                            """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(arrival_guest_sql)
                results = self.env.cr.fetchall()
                arrival_guest = 0
                for result in results:
                    arrival_guest = result[0] + result[1]

                # departure_guest
                departure_guest_sql = """
                        select COALESCE(SUM(reg_adult), 0),COALESCE(SUM(reg_child), 0) from hms_registration 
                        where "Rsv_Type" = 'check_out'
                        AND EXTRACT(MONTH FROM create_date)=%s AND EXTRACT(Year FROM create_date)=%s
                            """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(departure_guest_sql)
                results = self.env.cr.fetchall()
                departure_guest = 0
                for result in results:
                    departure_guest = result[0] + result[1]

                # occupied_guest
                occupied_guest_sql = """
                        select  COALESCE(SUM(reg_adult), 0),COALESCE(SUM(reg_child), 0) from hms_registration
                        where "Rsv_Type" = 'registration' and EXTRACT(MONTH FROM create_date)=%s AND EXTRACT(Year FROM create_date)=%s
                            """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(occupied_guest_sql)
                results = self.env.cr.fetchall()
                occupied_guest = 0
                for result in results:
                    occupied_guest = result[0] + result[1]

                # Cancellation
                cancellation_sql = """
                        select count(id) from hotel_reservation where "Rsv_Type" = 'cancel'
                            AND EXTRACT(MONTH FROM create_date)=%s AND EXTRACT(Year FROM create_date)=%s
                            """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(cancellation_sql)
                results = self.env.cr.fetchall()
                cancellation_room = 0
                for result in results:
                    cancellation_room = result[0]

                # Noshow
                noshow_room_sql = """
                        select count(id) from hotel_reservation 
                        where "Rsv_Type" = 'noshow'
                            AND EXTRACT(MONTH FROM create_date)=%s AND EXTRACT(Year FROM create_date)=%s
                            """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(noshow_room_sql)
                results = self.env.cr.fetchall()
                noshow_room = 0
                for result in results:
                    noshow_room = result[0]

                # occupancy
                occupied_sql = """
                        select count(id) from hms_registration
                        where "Rsv_Type" = 'registration' and EXTRACT(MONTH FROM create_date)=%s AND EXTRACT(Year FROM create_date)=%s
                            """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(occupied_sql)
                results = self.env.cr.fetchall()
                occupied = 0
                for result in results:
                    occupied = result[0]

                total_rooms_sql = """
                        select count(id) from hms_room_setup
                            """
                self.env.cr.execute(total_rooms_sql)
                results = self.env.cr.fetchall()
                total_rooms = 0
                for result in results:
                    total_rooms = result[0]

                out_sql = """
                        select count(id) from hms_room_setup where room_status = 'ooo' or room_status= 'oos'
                            """
                self.env.cr.execute(out_sql)
                results = self.env.cr.fetchall()
                oo_romms = 0
                for result in results:
                    oo_romms = result[0]

                available_room = total_rooms - oo_romms
                occrm = occupied * 100
                occupancy = occrm / available_room
                occupancy = round(occupancy, 2)

                # bed_Occupancy
                bed_sql = """
                    select SUM(CAST(hr.reg_extra_bed AS integer)),SUM(CAST(hrs.no_of_bed AS integer)) from hms_registration hr 
                    join hms_room_setup hrs on hr.reg_room_no = hrs.id where reg_extra_bed != 'null' 
                    and hr."Rsv_Type" = 'registration' and EXTRACT(MONTH FROM hr.create_date)=%s AND EXTRACT(Year FROM hr.create_date)=%s
                            """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(bed_sql)
                results = self.env.cr.fetchall()
                beds = 0
                for result in results:
                    extra_bed = result[0] or 0
                    no_of_bed = result[1] or 0
                    beds = extra_bed + no_of_bed
                if occupied_guest and beds:
                    bed_occupancy = occupied_guest * 100 / beds
                    bed_occupancy = round(bed_occupancy, 2)
                else:
                    bed_occupancy = 0

                # Average Rate/Rm. ($US)
                total_rr_us = """
                            SELECT sum(room_rate) FROM HMS_ROOM_rate hr
                            join res_currency c on hr.currency = c.id where c.name = 'USD'
                            and EXTRACT(MONTH FROM hr.create_date)=%s AND EXTRACT(Year FROM hr.create_date)=%s
                            """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(total_rr_us)
                results = self.env.cr.fetchall()
                total_rr_us = 0
                for result in results:
                    if result:
                        total_rr_us = result[0] or 0

                sum_room_amount = """select sum(payment_amount) from hotel_bill hb
                                            join res_currency c on hb.currency = c.id
                                            where c.name = 'USD'
                                            and EXTRACT(MONTH FROM hb.bill_date)=%s 
                                            AND EXTRACT(Year FROM hb.bill_date)=%s
                                            """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(sum_room_amount)
                r = self.env.cr.fetchall()
                for record in r:
                    sum_room_amount = record[0] or 0

                if total_rr_us and sum_room_amount:
                    ar_room_us = total_rr_us / sum_room_amount
                    ar_room_us = round(ar_room_us, 2)
                else:
                    ar_room_us = 0
                # Average Rate/Rm. (MMK)
                total_rr_mmk = """
                                        SELECT sum(room_rate) FROM HMS_ROOM_rate hr
                                        join res_currency c on hr.currency = c.id where c.name = 'MMK' 
                                        and EXTRACT(MONTH FROM hr.create_date)=%s AND EXTRACT(Year FROM hr.create_date)=%s
                                        """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(total_rr_mmk)
                results = self.env.cr.fetchall()
                total_rr_mmk = 0
                for result in results:
                    if result:
                        total_rr_mmk = result[0] or 0

                sum_room_amount_mmk = """select sum(payment_amount) from hotel_bill hb
                                                        join res_currency c on hb.currency = c.id
                                                        where c.name = 'MMK'
                                                        and EXTRACT(MONTH FROM hb.bill_date)=%s 
                                                        AND EXTRACT(Year FROM hb.bill_date)=%s
                                                        """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(sum_room_amount_mmk)
                r = self.env.cr.fetchall()
                for record in r:
                    sum_room_amount_mmk = record[0] or 0

                if total_rr_mmk and sum_room_amount_mmk:
                    ar_room_mmk = total_rr_mmk / sum_room_amount_mmk
                    ar_room_mmk = round(ar_room_mmk, 2)
                else:
                    ar_room_mmk = 0

                # Average Rate/Guest. ($US)
                sum_guest_amount = """select COALESCE(SUM(hr.reg_adult), 0),COALESCE(SUM(hr.reg_child), 0) from hotel_bill hb join res_currency c on hb.currency = c.id
                           join hms_registration hr on  hr.id = hb.reg_ids 
                           where c.name = 'USD'	
                            and EXTRACT(MONTH FROM hb.bill_date)=%s AND EXTRACT(Year FROM hb.bill_date)=%s
                                                           """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(sum_guest_amount)
                r = self.env.cr.fetchall()
                for record in r:
                    sum_guest_amount = record[0] or 0
                if total_rr_us and sum_guest_amount:
                    ar_guest_us = total_rr_us / sum_guest_amount
                    ar_guest_us = round(ar_guest_us, 2)
                else:
                    ar_guest_us = 0

                # Average Rate/Guest. (MMK)
                sum_guest_amount_mmk = """select COALESCE(SUM(hr.reg_adult), 0),COALESCE(SUM(hr.reg_child), 0) from hotel_bill hb join res_currency c on hb.currency = c.id
                           join hms_registration hr on  hr.id = hb.reg_ids 
                           where c.name = 'MMK'	
                            and EXTRACT(MONTH FROM hb.bill_date)=%s AND EXTRACT(Year FROM hb.bill_date)=%s
                                                           """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(sum_guest_amount_mmk)
                r = self.env.cr.fetchall()
                for record in r:
                    sum_guest_amount_mmk = record[0] or 0
                if total_rr_mmk and sum_guest_amount_mmk:
                    ar_guest_mmk = total_rr_mmk / sum_guest_amount_mmk
                    ar_guest_mmk = round(ar_guest_mmk, 2)
                else:
                    ar_guest_mmk = 0

                # Total Revenue (base Currency) (MMK)
                total_revenue_mmk = """select sum(hb.payment_amount)from hotel_bill hb join res_currency c on hb.currency = c.id
                                                   join hms_registration hr on  hr.id = hb.reg_ids 
                                                   where hotelia_base_currency = true 
                                                   and function_id = '2' 
                                                   and hr."Rsv_Type" != 'transfer'
                                                    and EXTRACT(MONTH FROM hb.bill_date)=%s 
                                                    and EXTRACT(Year FROM hb.bill_date)=%s
                                                                       """ % (
                    month,
                    options["cyear"],
                )
                self.env.cr.execute(total_revenue_mmk)
                results = self.env.cr.fetchall()
                for record in results:
                    total_revenue_mmk = record[0] or 0

                # Revenue Per Room (base Currency)
                tr_sql = """
                                    select count(id) from hms_room_setup
                                        """
                self.env.cr.execute(tr_sql)
                results = self.env.cr.fetchall()
                tr = 0
                for result in results:
                    if result:
                        tr = result[0]
                available_room = tr - oo_romms
                if total_revenue_mmk and available_room:
                    revenue_room_mmk = total_revenue_mmk / available_room
                    revenue_room_mmk = round(revenue_room_mmk, 2)
                else:
                    revenue_room_mmk = 0

                groups["month_body_arr"].append(
                    {
                        "month_header": month_dict[month],
                        "work_in_count": work_in_count,
                        "room_with_reserve": room_with_reserve,
                        "arr_room": arr_room,
                        "com_room": com_room,
                        "house_use": house_use,
                        "day_use": day_use,
                        "agent_room": agent_room,
                        "departure_room": departure_room,
                        "occupied_room": occupied_room,
                        "arrival_guest": arrival_guest,
                        "departure_guest": departure_guest,
                        "occupied_guest": occupied_guest,
                        "cancellation_room": cancellation_room,
                        "noshow_room": noshow_room,
                        "occupancy": occupancy,
                        "bed_Occupancy": bed_occupancy,
                        "ar_room_us": ar_room_us,
                        "ar_room_mmk": ar_room_mmk,
                        "ar_guest_us": ar_guest_us,
                        "ar_guest_mmk": ar_guest_mmk,
                        "revenue_room_mmk": revenue_room_mmk,
                        "total_revenue_mmk": total_revenue_mmk,
                    }
                )
        # byyears
        yt = int(options["yearto"]) + 1
        years = [year for year in range(options["yearfrom"], yt)]
        if options["report_type"] == "byyear":
            for year in years:
                work_in_sql = (
                    """
                         select count(id) from hms_registration
                             where "iamregistered" = 'True'
                             and id is not null 
                             AND EXTRACT(year FROM create_date)=%s 
                 """
                    % year
                )
                self.env.cr.execute(work_in_sql)
                results = self.env.cr.fetchall()
                work_in_count = 0
                for result in results:
                    work_in_count = result[0]

                # Room With Reservation
                r_with_r_sql = (
                    """
                                 select count(id) from hotel_reservation 
                                    where id in (select reservation_id from hms_registration)
                                     AND EXTRACT(year FROM create_date)=%s 
                 """
                    % year
                )
                self.env.cr.execute(r_with_r_sql)
                results = self.env.cr.fetchall()
                room_with_reserve = 0
                for result in results:
                    room_with_reserve = result[0]

                # Arrival Rooms
                arrival_sql = (
                    """
                         select count(id) from hotel_reservation
                         where id not in (select id from hms_registration)
                         and "Rsv_Type" != 'check_out' AND EXTRACT(year FROM create_date)=%s 
                 """
                    % year
                )

                self.env.cr.execute(arrival_sql)
                results = self.env.cr.fetchall()
                arr_room = 0
                for result in results:
                    arr_room = result[0]

                # Complimentary Rooms
                complimentary_sql = (
                    """
                         select  count(hr.id) from hms_registration hr
                         join hms_customer_type ct  on hr.reg_customer_type = ct.id where ct.name = 'complimentary'
                         AND EXTRACT(year FROM hr.create_date)=%s 
                 """
                    % year
                )

                self.env.cr.execute(complimentary_sql)
                results = self.env.cr.fetchall()
                com_room = 0
                for result in results:
                    com_room = result[0]

                # house_use Rooms
                houseuse_sql = (
                    """
                         select count(id) from hotel_reservation
                         where "Rsv_Type" = 'confirmed'
                         AND EXTRACT(year FROM create_date)=%s 
                 """
                    % year
                )
                self.env.cr.execute(houseuse_sql)
                results = self.env.cr.fetchall()
                house_use = 0
                for result in results:
                    house_use = result[0]

                # Day Use  Rooms
                day_use_sql = (
                    """
                        select count(id) from hms_registration
                                where "Rsv_Type" = 'check_out'
                                 and arrival_date = departure_date
                         AND EXTRACT(year FROM create_date)=%s 
                 """
                    % year
                )
                self.env.cr.execute(day_use_sql)
                results = self.env.cr.fetchall()
                day_use = 0
                for result in results:
                    day_use = result[0]

                # AgentRooms
                agent_room_sql = (
                    """
                        select count(hrs.id) from hms_registration  hr
                             join hms_room_setup as hrs on hrs.id= reg_room_no
                             where hr.reg_agent_id is not null
                         AND EXTRACT(year FROM hr.create_date)=%s 
                 """
                    % year
                )
                self.env.cr.execute(agent_room_sql)
                results = self.env.cr.fetchall()
                agent_room = 0
                for result in results:
                    agent_room = result[0]

                # DepartureRooms
                departure_room_sql = (
                    """
                         select count(hrs.id) from hms_registration  hr
                             join hms_room_setup as hrs on hrs.id= reg_room_no
                             where  hr."Rsv_Type" = 'check_out'
                             AND EXTRACT(year FROM hr.create_date)=%s 
                 """
                    % year
                )
                self.env.cr.execute(departure_room_sql)
                results = self.env.cr.fetchall()
                departure_room = 0
                for result in results:
                    departure_room = result[0]

                # OccupiedRooms
                occupied_room_sql = (
                    """
                         select count(id) from hms_room_setup
                             where  room_status= 'o_dirty'
                             AND EXTRACT(year FROM create_date)=%s 
                 """
                    % year
                )
                self.env.cr.execute(occupied_room_sql)
                results = self.env.cr.fetchall()
                occupied_room = 0
                for result in results:
                    occupied_room = result[0]

                # arrival_guest
                arrival_guest_sql = (
                    """
                         select COALESCE(SUM(adult), 0),COALESCE(SUM(child), 0) from hotel_reservation
                         where "Rsv_Type" = 'registration'
                         AND EXTRACT(year FROM create_date)=%s 
                 """
                    % year
                )
                self.env.cr.execute(arrival_guest_sql)
                results = self.env.cr.fetchall()
                arrival_guest = 0
                for result in results:
                    arrival_guest = result[0] + result[1]

                # departure_guest
                departure_guest_sql = (
                    """
                         select COALESCE(SUM(reg_adult), 0),COALESCE(SUM(reg_child), 0) from hms_registration
                         where "Rsv_Type" = 'check_out'
                         AND EXTRACT(year FROM create_date)=%s 
                 """
                    % year
                )
                self.env.cr.execute(departure_guest_sql)
                results = self.env.cr.fetchall()
                departure_guest = 0
                for result in results:
                    departure_guest = result[0] + result[1]

                # occupied_guest
                occupied_guest_sql = (
                    """
                         select COALESCE(SUM(hr.reg_adult), 0),COALESCE(SUM(hr.reg_child), 0) from hms_room_setup hrs
                         join hms_registration hr on hrs.id = hr.reg_room_no
                             where  hrs.room_status= 'o_dirty' or hrs.room_status= 'o_clean'
                             AND EXTRACT(year FROM hr.create_date)=%s 
                 """
                    % year
                )
                self.env.cr.execute(occupied_guest_sql)
                results = self.env.cr.fetchall()
                occupied_guest = 0
                for result in results:
                    occupied_guest = result[0] + result[1]

                # Cancellation
                cancellation_sql = (
                    """
                         select count(id) from hotel_reservation where "Rsv_Type" = 'cancel'
                             AND EXTRACT(year FROM create_date)=%s 
                 """
                    % year
                )
                self.env.cr.execute(cancellation_sql)
                results = self.env.cr.fetchall()
                cancellation_room = 0
                for result in results:
                    cancellation_room = result[0]

                # Noshow
                noshow_room_sql = (
                    """
                         select count(id) from hotel_reservation
                         where "Rsv_Type" = 'noshow'
                             AND EXTRACT(year FROM create_date)=%s 
                 """
                    % year
                )
                self.env.cr.execute(noshow_room_sql)
                results = self.env.cr.fetchall()
                noshow_room = 0
                for result in results:
                    noshow_room = result[0]

                # occupancy
                occupied_sql = (
                    """
                                    select count(id) from hms_registration
                                    where "Rsv_Type" = 'registration' 
                                    AND EXTRACT(year FROM create_date)=%s 
                 """
                    % year
                )
                self.env.cr.execute(occupied_sql)
                results = self.env.cr.fetchall()
                occupied = 0
                for result in results:
                    occupied = result[0]

                total_rooms_sql = """
                                    select count(id) from hms_room_setup
                                        """
                self.env.cr.execute(total_rooms_sql)
                results = self.env.cr.fetchall()
                total_rooms = 0
                for result in results:
                    total_rooms = result[0]

                out_sql = (
                    """
                                    select count(id) from hms_room_setup where room_status = 'ooo' or room_status= 'oos'
                                       AND EXTRACT(year FROM write_date)=%s 
                 """
                    % year
                )
                self.env.cr.execute(out_sql)
                results = self.env.cr.fetchall()
                oo_romms = 0
                for result in results:
                    oo_romms = result[0]

                available_room = total_rooms - oo_romms
                occrm = occupied * 100
                occupancy = occrm / available_room
                occupancy = round(occupancy, 2)

                # bed_Occupancy
                bed_sql = (
                    """
                                        select SUM(CAST(hr.reg_extra_bed AS integer)),SUM(CAST(hrs.no_of_bed AS integer)) from hms_registration hr 
                                        join hms_room_setup hrs on hr.reg_room_no = hrs.id where reg_extra_bed != 'null' 
                                        and hr."Rsv_Type" = 'registration' AND EXTRACT(year FROM hr.create_date)=%s 
                 """
                    % year
                )
                self.env.cr.execute(bed_sql)
                results = self.env.cr.fetchall()
                beds = 0
                for result in results:
                    extra_bed = result[0] or 0
                    no_of_bed = result[1] or 0
                    beds = extra_bed + no_of_bed
                if occupied_guest and beds:
                    bed_occupancy = occupied_guest * 100 / beds
                    bed_occupancy = round(bed_occupancy, 2)
                else:
                    bed_occupancy = 0

                # Average Rate/Rm. ($US)
                total_rr_us = (
                    """
                                        SELECT sum(room_rate) FROM HMS_ROOM_rate hr
                                        join res_currency c on hr.currency = c.id where c.name = 'USD'
                                       AND EXTRACT(year FROM hr.create_date)=%s 
                 """
                    % year
                )
                self.env.cr.execute(total_rr_us)
                results = self.env.cr.fetchall()
                total_rr_us = 0
                for result in results:
                    if result:
                        total_rr_us = result[0] or 0

                sum_room_amount = (
                    """select sum(payment_amount) from hotel_bill hb
                                                        join res_currency c on hb.currency = c.id
                                                        where c.name = 'USD'
                                                        AND EXTRACT(year FROM hb.bill_date)=%s 
                                                        """
                    % year
                )
                self.env.cr.execute(sum_room_amount)
                r = self.env.cr.fetchall()
                for record in r:
                    sum_room_amount = record[0] or 0

                if total_rr_us and sum_room_amount:
                    ar_room_us = total_rr_us / sum_room_amount
                    ar_room_us = round(ar_room_us, 2)
                else:
                    ar_room_us = 0

                # Average Rate/Rm. (MMK)
                total_rr_mmk = (
                    """
                            SELECT sum(room_rate) FROM HMS_ROOM_rate hr
                            join res_currency c on hr.currency = c.id where c.name = 'MMK' 
                            AND EXTRACT(year FROM hr.create_date)=%s 
                 """
                    % year
                )
                self.env.cr.execute(total_rr_mmk)
                results = self.env.cr.fetchall()
                total_rr_mmk = 0
                for result in results:
                    if result:
                        total_rr_mmk = result[0] or 0

                sum_room_amount_mmk = (
                    """ select sum(payment_amount) from hotel_bill hb
                                                                    join res_currency c on hb.currency = c.id
                                                                    where c.name = 'MMK'
                                                                    AND EXTRACT(year FROM hb.bill_date)=%s 
                                                        """
                    % year
                )
                self.env.cr.execute(sum_room_amount_mmk)
                r = self.env.cr.fetchall()
                for record in r:
                    sum_room_amount_mmk = record[0] or 0

                if total_rr_mmk and sum_room_amount_mmk:
                    ar_room_mmk = total_rr_mmk / sum_room_amount_mmk
                    ar_room_mmk = round(ar_room_mmk, 2)
                else:
                    ar_room_mmk = 0

                # Average Rate/Guest. ($US)
                sum_guest_amount = (
                    """select COALESCE(SUM(hr.reg_adult), 0),COALESCE(SUM(hr.reg_child), 0) from hotel_bill hb join res_currency c on hb.currency = c.id
                                       join hms_registration hr on  hr.id = hb.reg_ids 
                                       where c.name = 'USD'	
                                       AND EXTRACT(year FROM hb.bill_date)=%s 
                                                        """
                    % year
                )
                self.env.cr.execute(sum_guest_amount)
                r = self.env.cr.fetchall()
                for record in r:
                    sum_guest_amount = record[0] or 0
                if total_rr_us and sum_guest_amount:
                    ar_guest_us = total_rr_us / sum_guest_amount
                    ar_guest_us = round(ar_guest_us, 2)
                else:
                    ar_guest_us = 0

                # Average Rate/Guest. (MMK)
                sum_guest_amount_mmk = (
                    """select COALESCE(SUM(hr.reg_adult), 0),COALESCE(SUM(hr.reg_child), 0) from hotel_bill hb join res_currency c on hb.currency = c.id
                                       join hms_registration hr on  hr.id = hb.reg_ids 
                                       where c.name = 'MMK'	
                                       AND EXTRACT(year FROM hb.bill_date)=%s 
                                                        """
                    % year
                )
                self.env.cr.execute(sum_guest_amount_mmk)
                r = self.env.cr.fetchall()
                for record in r:
                    sum_guest_amount_mmk = record[0] or 0
                if total_rr_mmk and sum_guest_amount_mmk:
                    ar_guest_mmk = total_rr_mmk / sum_guest_amount_mmk
                    ar_guest_mmk = round(ar_guest_mmk, 2)
                else:
                    ar_guest_mmk = 0

                # Total Revenue (base Currency) (MMK)
                total_revenue_mmk = (
                    """select sum(hb.payment_amount)from hotel_bill hb join res_currency c on hb.currency = c.id
                                                               join hms_registration hr on  hr.id = hb.reg_ids 
                                                               where hotelia_base_currency = true 
                                                               and function_id = '2' 
                                                               and hr."Rsv_Type" != 'transfer'
                                                                AND EXTRACT(year FROM hb.bill_date)=%s 
                                                        """
                    % year
                )
                self.env.cr.execute(total_revenue_mmk)
                results = self.env.cr.fetchall()
                for record in results:
                    total_revenue_mmk = record[0] or 0

                # Revenue Per Room (base Currency)
                tr_sql = """
                        select count(id) from hms_room_setup
                            """
                self.env.cr.execute(tr_sql)
                results = self.env.cr.fetchall()
                tr = 0
                for result in results:
                    if result:
                        tr = result[0]
                available_room = tr - oo_romms
                if total_revenue_mmk and available_room:
                    revenue_room_mmk = total_revenue_mmk / available_room
                    revenue_room_mmk = round(revenue_room_mmk, 2)
                else:
                    revenue_room_mmk = 0

                groups["year_body_arr"].append(
                    {
                        "yearname": year,
                        "work_in_count": work_in_count,
                        "room_with_reserve": room_with_reserve,
                        "arr_room": arr_room,
                        "com_room": com_room,
                        "house_use": house_use,
                        "day_use": day_use,
                        "agent_room": agent_room,
                        "departure_room": departure_room,
                        "occupied_room": occupied_room,
                        "arrival_guest": arrival_guest,
                        "departure_guest": departure_guest,
                        "occupied_guest": occupied_guest,
                        "cancellation_room": cancellation_room,
                        "noshow_room": noshow_room,
                        "occupancy": occupancy,
                        "bed_Occupancy": bed_occupancy,
                        "ar_room_us": ar_room_us,
                        "ar_room_mmk": ar_room_mmk,
                        "ar_guest_us": ar_guest_us,
                        "ar_guest_mmk": ar_guest_mmk,
                        "revenue_room_mmk": revenue_room_mmk,
                        "total_revenue_mmk": total_revenue_mmk,
                    }
                )

        # Calculate M-T-D date range
        string_date = options["cdate"]
        today = datetime.strptime(str(string_date), "%Y-%m-%d").date()
        mtd_start_date = dt(today.year, today.month, 1)
        mtd_end_date = today
        ytd_start_date = dt(today.year, 1, 1)
        ytd_end_date = today

        dates_array = ["Today", "MTD", "YTD"]
        if options["report_type"] == "bydate":
            for date in dates_array:
                work_in_sql = """
                        select count(id) from hms_registration
                            where "iamregistered" = 'True'
                            and id is not null 
                """
                if date == "Today":
                    work_in_sql += " AND create_date >= '%s' " % options["cdate"]
                if date == "MTD":
                    work_in_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    work_in_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )
                self.env.cr.execute(work_in_sql)
                results = self.env.cr.fetchall()
                work_in_count = 0
                for result in results:
                    work_in_count = result[0]

                # Room With Reservation
                r_with_r_sql = """
                               select count(id) from hotel_reservation 
                                    where id in (select reservation_id from hms_registration)
                """
                if date == "Today":
                    r_with_r_sql += " AND arrival_date >= '%s' " % options["cdate"]
                if date == "MTD":
                    r_with_r_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    r_with_r_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )
                self.env.cr.execute(r_with_r_sql)
                results = self.env.cr.fetchall()
                room_with_reserve = 0
                for result in results:
                    room_with_reserve = result[0]

                # Arrival Rooms
                arrival_sql = """
                        select count(id) from hotel_reservation
                        where id not in (select id from hms_registration)
                        and "Rsv_Type" != 'check_out'
                """
                if date == "Today":
                    arrival_sql += " AND arrival_date = '%s' " % options["cdate"]
                if date == "MTD":
                    arrival_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    arrival_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )
                self.env.cr.execute(arrival_sql)
                results = self.env.cr.fetchall()
                arr_room = 0
                for result in results:
                    arr_room = result[0]

                # Complimentary Rooms
                complimentary_sql = """
                        select  count(hr.id) from hms_registration hr
                        join hms_customer_type ct  on hr.reg_customer_type = ct.id where ct.name = 'complimentary'
                """
                if date == "Today":
                    complimentary_sql += (
                        " AND hr.arrival_date = '%s' " % options["cdate"]
                    )
                if date == "MTD":
                    complimentary_sql += (
                        " and hr.create_date >= '%s' and hr.create_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    complimentary_sql += (
                        " and hr.create_date >= '%s' and hr.create_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )
                self.env.cr.execute(complimentary_sql)
                results = self.env.cr.fetchall()
                com_room = 0
                for result in results:
                    com_room = result[0]

                # house_use Rooms
                houseuse_sql = """
                        select count(id) from hotel_reservation
                        where "Rsv_Type" = 'confirmed'
                """
                if date == "Today":
                    houseuse_sql += " AND arrival_date = '%s' " % options["cdate"]
                if date == "MTD":
                    houseuse_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    houseuse_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )
                self.env.cr.execute(houseuse_sql)
                results = self.env.cr.fetchall()
                house_use = 0
                for result in results:
                    house_use = result[0]

                # Day Use  Rooms
                day_use_sql = """
                       select count(id) from hms_registration
                               where "Rsv_Type" = 'check_out'
                                and arrival_date = departure_date
                """
                if date == "Today":
                    day_use_sql += " AND arrival_date = '%s' " % options["cdate"]
                if date == "MTD":
                    day_use_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    day_use_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )
                self.env.cr.execute(day_use_sql)
                results = self.env.cr.fetchall()
                day_use = 0
                for result in results:
                    day_use = result[0]

                # AgentRooms
                agent_room_sql = """
                       select count(hrs.id) from hms_registration  hr
                            join hms_room_setup as hrs on hrs.id= reg_room_no
                            where hr.reg_agent_id is not null
                """
                if date == "Today":
                    agent_room_sql += " AND hr.arrival_date = '%s' " % options["cdate"]
                if date == "MTD":
                    agent_room_sql += (
                        " and hr.create_date >= '%s' and hr.create_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    agent_room_sql += (
                        " and hr.create_date >= '%s' and hr.create_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )
                self.env.cr.execute(agent_room_sql)
                results = self.env.cr.fetchall()
                agent_room = 0
                for result in results:
                    agent_room = result[0]

                # DepartureRooms
                departure_room_sql = """
                        select count(hrs.id) from hms_registration  hr
                            join hms_room_setup as hrs on hrs.id= reg_room_no
                            where  hr."Rsv_Type" = 'check_out'
                """
                if date == "Today":
                    departure_room_sql += (
                        " AND hr.arrival_date = '%s' " % options["cdate"]
                    )
                if date == "MTD":
                    departure_room_sql += (
                        " and hr.create_date >= '%s' and hr.create_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    departure_room_sql += (
                        " and hr.create_date >= '%s' and hr.create_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )
                self.env.cr.execute(departure_room_sql)
                results = self.env.cr.fetchall()
                departure_room = 0
                for result in results:
                    departure_room = result[0]

                # OccupiedRooms
                occupied_room_sql = """
                        select count(id) from hms_room_setup
                            where  room_status= 'o_dirty'
                """
                if date == "Today":
                    occupied_room_sql += " AND create_date = '%s' " % options["cdate"]
                if date == "MTD":
                    occupied_room_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    occupied_room_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )
                self.env.cr.execute(occupied_room_sql)
                results = self.env.cr.fetchall()
                occupied_room = 0
                for result in results:
                    occupied_room = result[0]

                # arrival_guest
                arrival_guest_sql = """
                        select COALESCE(SUM(adult), 0),COALESCE(SUM(child), 0) from hotel_reservation
                        where "Rsv_Type" = 'registration'
                """
                if date == "Today":
                    arrival_guest_sql += " AND arrival_date = '%s' " % options["cdate"]
                if date == "MTD":
                    arrival_guest_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    arrival_guest_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )
                self.env.cr.execute(arrival_guest_sql)
                results = self.env.cr.fetchall()
                arrival_guest = 0
                for result in results:
                    arrival_guest = result[0] + result[1]

                # departure_guest
                departure_guest_sql = """
                        select COALESCE(SUM(reg_adult), 0),COALESCE(SUM(reg_child), 0) from hms_registration
                        where "Rsv_Type" = 'check_out'
                """
                if date == "Today":
                    departure_guest_sql += (
                        " AND arrival_date = '%s' " % options["cdate"]
                    )
                if date == "MTD":
                    departure_guest_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    departure_guest_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )
                self.env.cr.execute(departure_guest_sql)
                results = self.env.cr.fetchall()
                departure_guest = 0
                for result in results:
                    departure_guest = result[0] + result[1]

                # occupied_guest
                occupied_guest_sql = """
                        select COALESCE(SUM(hr.reg_adult), 0),COALESCE(SUM(hr.reg_child), 0) from hms_room_setup hrs
                        join hms_registration hr on hrs.id = hr.reg_room_no
                            where  hrs.room_status= 'o_dirty' or hrs.room_status= 'o_clean'
                """
                if date == "Today":
                    occupied_guest_sql += (
                        " AND hr.arrival_date = '%s' " % options["cdate"]
                    )
                if date == "MTD":
                    occupied_guest_sql += (
                        " and hr.create_date >= '%s' and hr.create_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    occupied_guest_sql += (
                        " and hr.create_date >= '%s' and hr.create_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )
                self.env.cr.execute(occupied_guest_sql)
                results = self.env.cr.fetchall()
                occupied_guest = 0
                for result in results:
                    occupied_guest = result[0] + result[1]

                # Cancellation
                cancellation_sql = """
                        select count(id) from hotel_reservation where "Rsv_Type" = 'cancel'
                """
                if date == "Today":
                    cancellation_sql += " AND arrival_date = '%s' " % options["cdate"]
                if date == "MTD":
                    cancellation_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    cancellation_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )
                self.env.cr.execute(cancellation_sql)
                results = self.env.cr.fetchall()
                cancellation_room = 0
                for result in results:
                    cancellation_room = result[0]

                # Noshow
                noshow_room_sql = """
                        select count(id) from hotel_reservation
                        where "Rsv_Type" = 'noshow'
                """
                if date == "Today":
                    noshow_room_sql += " AND arrival_date = '%s' " % options["cdate"]
                if date == "MTD":
                    noshow_room_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    noshow_room_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )
                self.env.cr.execute(noshow_room_sql)
                results = self.env.cr.fetchall()
                noshow_room = 0
                for result in results:
                    noshow_room = result[0]

                # occupied_guest_dayuse
                occupied_guest_du_sql = """
                  select COALESCE(SUM(reg_adult), 0),COALESCE(SUM(reg_child), 0) from hms_registration 
                                   where  "Rsv_Type" = 'check_out' and  arrival_date = departure_date
                """
                if date == "Today":
                    occupied_guest_du_sql += (
                        " AND arrival_date = '%s' " % options["cdate"]
                    )
                if date == "MTD":
                    occupied_guest_du_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    occupied_guest_du_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )
                self.env.cr.execute(occupied_guest_du_sql)
                results = self.env.cr.fetchall()
                occupied_guest_du = 0
                for result in results:
                    occupied_guest_du = result[0] + result[1]

                # occupancy
                occupied_sql = """
                                    select count(id) from hms_registration
                                    where "Rsv_Type" = 'registration' 
                                   """
                if date == "Today":
                    occupied_sql += " AND arrival_date = '%s' " % options["cdate"]
                if date == "MTD":
                    occupied_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    occupied_sql += (
                        " and create_date >= '%s' and create_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )
                self.env.cr.execute(occupied_sql)
                results = self.env.cr.fetchall()
                occupied = 0
                for result in results:
                    occupied = result[0]

                total_rooms_sql = """
                                    select count(id) from hms_room_setup
                                        """
                self.env.cr.execute(total_rooms_sql)
                results = self.env.cr.fetchall()
                total_rooms = 0
                for result in results:
                    total_rooms = result[0]

                out_sql = """
                        select count(id) from hms_room_setup where room_status = 'ooo' or room_status= 'oos'
                                       """
                if date == "Today":
                    out_sql += " AND write_date = '%s' " % options["cdate"]
                if date == "MTD":
                    out_sql += " and write_date >= '%s' and write_date <= '%s' " % (
                        mtd_start_date,
                        mtd_end_date,
                    )
                if date == "YTD":
                    out_sql += " and write_date >= '%s' and write_date <= '%s' " % (
                        ytd_start_date,
                        ytd_end_date,
                    )
                self.env.cr.execute(out_sql)
                results = self.env.cr.fetchall()
                oo_romms = 0
                for result in results:
                    oo_romms = result[0]
                available_room = total_rooms - oo_romms
                occrm = occupied * 100
                occupancy = occrm / available_room
                occupancy = round(occupancy, 2)

                # bed_Occupancy
                bed_sql = """
                                        select SUM(CAST(hr.reg_extra_bed AS integer)),SUM(CAST(hrs.no_of_bed AS integer)) from hms_registration hr 
                                        join hms_room_setup hrs on hr.reg_room_no = hrs.id where reg_extra_bed != 'null' 
                                        and hr."Rsv_Type" = 'registration' """
                if date == "Today":
                    bed_sql += " AND hr.arrival_date = '%s' " % options["cdate"]
                if date == "MTD":
                    bed_sql += (
                        " and hr.create_date >= '%s' and hr.create_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    bed_sql += (
                        " and hr.create_date >= '%s' and hr.create_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )
                self.env.cr.execute(bed_sql)
                results = self.env.cr.fetchall()
                beds = 0
                for result in results:
                    extra_bed = result[0] or 0
                    no_of_bed = result[1] or 0
                    beds = extra_bed + no_of_bed
                if occupied_guest and beds:
                    bed_occupancy = occupied_guest * 100 / beds
                    bed_occupancy = round(bed_occupancy, 2)
                else:
                    bed_occupancy = 0

                # Average Rate/Rm. ($US)
                total_rr_us = """
                                        SELECT sum(room_rate) FROM HMS_ROOM_rate hr
                                        join res_currency c on hr.currency = c.id where c.name = 'USD'
                                       """
                self.env.cr.execute(total_rr_us)
                results = self.env.cr.fetchall()
                total_rr_us = 0
                for result in results:
                    if result:
                        total_rr_us = result[0] or 0

                sum_room_amount = """select sum(payment_amount) from hotel_bill hb
                                                        join res_currency c on hb.currency = c.id
                                                        where c.name = 'USD'
                                                        """
                if date == "Today":
                    sum_room_amount += " AND hb.bill_date = '%s' " % options["cdate"]
                if date == "MTD":
                    sum_room_amount += (
                        " and hb.bill_date >= '%s' and hb.bill_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    sum_room_amount += (
                        " and hb.bill_date >= '%s' and hb.bill_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )
                self.env.cr.execute(sum_room_amount)
                r = self.env.cr.fetchall()
                for record in r:
                    sum_room_amount = record[0] or 0
                if total_rr_us and sum_room_amount:
                    ar_room_us = total_rr_us / sum_room_amount
                    ar_room_us = round(ar_room_us, 2)
                else:
                    ar_room_us = 0

                # Average Rate/Rm. (MMK)
                total_rr_mmk = """
                            SELECT sum(room_rate) FROM HMS_ROOM_rate hr
                            join res_currency c on hr.currency = c.id 
                            where c.name = 'MMK'
                            """
                self.env.cr.execute(total_rr_mmk)
                results = self.env.cr.fetchall()
                total_rr_mmk = 0
                for result in results:
                    if result:
                        total_rr_mmk = result[0] or 0

                sum_room_amount_mmk = """ select sum(payment_amount) from hotel_bill hb
                                                                    join res_currency c on hb.currency = c.id
                                                                    where c.name = 'MMK'
                                                                    """
                if date == "Today":
                    sum_room_amount_mmk += (
                        " AND hb.bill_date = '%s' " % options["cdate"]
                    )
                if date == "MTD":
                    sum_room_amount_mmk += (
                        " and hb.bill_date >= '%s' and hb.bill_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    sum_room_amount_mmk += (
                        " and hb.bill_date >= '%s' and hb.bill_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )

                self.env.cr.execute(sum_room_amount_mmk)
                r = self.env.cr.fetchall()
                for record in r:
                    sum_room_amount_mmk = record[0] or 0
                if total_rr_mmk and sum_room_amount_mmk:
                    ar_room_mmk = total_rr_mmk / sum_room_amount_mmk
                    ar_room_mmk = round(ar_room_mmk, 2)
                else:
                    ar_room_mmk = 0

                # Average Rate/Guest. ($US)
                sum_guest_amount = """select COALESCE(SUM(hr.reg_adult), 0),COALESCE(SUM(hr.reg_child), 0) from hotel_bill hb join res_currency c on hb.currency = c.id
                                       join hms_registration hr on  hr.id = hb.reg_ids 
                                       where c.name = 'USD'	
                                            """
                if date == "Today":
                    sum_guest_amount += " AND hb.bill_date = '%s' " % options["cdate"]
                if date == "MTD":
                    sum_guest_amount += (
                        " and hb.bill_date >= '%s' and hb.bill_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    sum_guest_amount += (
                        " and hb.bill_date >= '%s' and hb.bill_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )
                self.env.cr.execute(sum_guest_amount)
                r = self.env.cr.fetchall()
                for record in r:
                    sum_guest_amount = record[0] or 0
                if total_rr_us and sum_guest_amount:
                    ar_guest_us = total_rr_us / sum_guest_amount
                    ar_guest_us = round(ar_guest_us, 2)
                else:
                    ar_guest_us = 0

                # Average Rate/Guest. (MMK)
                sum_guest_amount_mmk = """select COALESCE(SUM(hr.reg_adult), 0),COALESCE(SUM(hr.reg_child), 0) 
                                        from hotel_bill hb join res_currency c on hb.currency = c.id
                                       join hms_registration hr on  hr.id = hb.reg_ids 
                                       where c.name = 'MMK'	
                                       """
                if date == "Today":
                    sum_guest_amount_mmk += (
                        " AND hb.bill_date = '%s' " % options["cdate"]
                    )
                if date == "MTD":
                    sum_guest_amount_mmk += (
                        " and hb.bill_date >= '%s' and hb.bill_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    sum_guest_amount_mmk += (
                        " and hb.bill_date >= '%s' and hb.bill_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )
                self.env.cr.execute(sum_guest_amount_mmk)
                r = self.env.cr.fetchall()
                for record in r:
                    sum_guest_amount_mmk = record[0] or 0
                if total_rr_mmk and sum_guest_amount_mmk:
                    ar_guest_mmk = total_rr_mmk / sum_guest_amount_mmk
                    ar_guest_mmk = round(ar_guest_mmk, 2)
                else:
                    ar_guest_mmk = 0

                # Total Revenue (base Currency) (MMK)
                total_revenue_mmk = """select sum(hb.payment_amount)from hotel_bill hb join res_currency c on hb.currency = c.id
                                                               join hms_registration hr on  hr.id = hb.reg_ids 
                                                               where hotelia_base_currency = true 
                                                               and function_id = '2' 
                                                               and hr."Rsv_Type" != 'transfer'
                                       """
                if date == "Today":
                    total_revenue_mmk += " AND hb.bill_date = '%s' " % options["cdate"]
                if date == "MTD":
                    total_revenue_mmk += (
                        " and hb.bill_date >= '%s' and hb.bill_date <= '%s' "
                        % (mtd_start_date, mtd_end_date)
                    )
                if date == "YTD":
                    total_revenue_mmk += (
                        " and hb.bill_date >= '%s' and hb.bill_date <= '%s' "
                        % (ytd_start_date, ytd_end_date)
                    )
                self.env.cr.execute(total_revenue_mmk)
                results = self.env.cr.fetchall()
                for record in results:
                    total_revenue_mmk = record[0] or 0

                # Revenue Per Room (base Currency)
                tr_sql = """
                        select count(id) from hms_room_setup
                            """
                self.env.cr.execute(tr_sql)
                results = self.env.cr.fetchall()
                tr = 0
                for result in results:
                    if result:
                        tr = result[0]
                available_room = tr - oo_romms
                if total_revenue_mmk and available_room:
                    revenue_room_mmk = total_revenue_mmk / available_room
                    revenue_room_mmk = round(revenue_room_mmk, 2)
                else:
                    revenue_room_mmk = 0

                groups["day_body_arr"].append(
                    {
                        "day_header": date,
                        "work_in_count": work_in_count,
                        "room_with_reserve": room_with_reserve,
                        "arr_room": arr_room,
                        "com_room": com_room,
                        "house_use": house_use,
                        "day_use": day_use,
                        "agent_room": agent_room,
                        "departure_room": departure_room,
                        "occupied_room": occupied_room,
                        "arrival_guest": arrival_guest,
                        "departure_guest": departure_guest,
                        "occupied_guest": occupied_guest,
                        "occupied_guest_du": occupied_guest_du,
                        "occupancy": occupancy,
                        "bed_Occupancy": bed_occupancy,
                        "ar_room_us": ar_room_us,
                        "ar_room_mmk": ar_room_mmk,
                        "cancellation_room": cancellation_room,
                        "noshow_room": noshow_room,
                        "ar_guest_us": ar_guest_us,
                        "ar_guest_mmk": ar_guest_mmk,
                        "revenue_room_mmk": revenue_room_mmk,
                        "total_revenue_mmk": total_revenue_mmk,
                    }
                )
        return groups
