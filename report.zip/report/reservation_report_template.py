# -*- coding: utf-8 -*-
from datetime import time
from odoo import models, api, _
from odoo.exceptions import UserError
from datetime import time, datetime, timedelta


class ReportRes(models.AbstractModel):
    _name = "report.hotelia.report_reservation_details"
    _description = "Reservation Report"

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get("form"):
            raise UserError(
                _("Form content is missing, this report cannot be printed.")
            )
        return {
            "data": data["form"],
            "lines": self.get_lines(data.get("form")),
        }

    @api.model
    def get_lines(self, options):
        groups = dict((tp, []) for tp in ["reservation", "registration"])
        moves = {}

        sql = """
        select res.id, res.name,res.guest_name,res.arrival_date,res.departure_date,rt.name,res."Rsv_Type",rs.name ,res.rsv_date
        from hotel_reservation  res 
        join hms_room_type rt on res.room_type = rt.id
        left join hms_room_setup rs on res.room_no = rs.id
        where res.id is not null and res.name != 'room'  and res."Rsv_Type" <> 'registration'
         """
        if options["date_to"]:
            string_date = options["date_to"]
            date_obj = datetime.strptime(str(string_date), "%Y-%m-%d").date()
            new_date_obj_dep = date_obj + timedelta(days=1)

        if options["roomtype_ids"]:
            sql = sql + """ and res.room_type = %s """ % options["roomtype_ids"][0]

        if options["date_filter"] == "arrdate":
            if options["date_from"]:
                sql = sql + """and res.arrival_date >= '%s'  """ % options["date_from"]
        if options["date_filter"] == "arrdate":
            if options["date_to"]:
                sql = sql + """and res.arrival_date <='%s'  """ % options["date_to"]

        if options["rsv_type"] and options["rsv_type"] != "no_show":
            sql = sql + """and res."Rsv_Type" = '%s' """ % options["rsv_type"]

        if options["date_filter"] == "rsvdate":
            if options["date_from"]:
                sql = sql + """and rsv_date >= '%s'  """ % options["date_from"]

        if options["date_filter"] == "rsvdate":
            if options["date_to"]:
                sql = sql + """and rsv_date <= '%s'  """ % options["date_to"]

        if (
            not options["roomtype_ids"]
            and not options["date_from"]
            and not options["date_to"]
            and not options["rsv_type"]
        ):
            sql = """
                select res.id, res.name,res.guest_name,res.arrival_date,res.departure_date,rt.name,res."Rsv_Type",rs.name,res.rsv_date
                from hotel_reservation  res 
                join hms_room_type rt on res.room_type = rt.id
                left join hms_room_setup rs on res.room_no = rs.id
                where res.name != 'room'
            """
        self.env.cr.execute(sql)
        results = self.env.cr.fetchall()
        if results:
            for result in results:
                moves = {
                    "rsv_date": result[8],
                    "id": result[0],
                    "name": result[1],
                    "guest_name": result[2],
                    "arrival": result[3],
                    "departure": result[4],
                    "room_type": result[5],
                    "Rsv_Type": result[6],
                    "room_no": result[7],
                }
                groups["reservation"].append(moves)
        return groups
