# -*- coding: utf-8 -*-
from datetime import datetime
from datetime import timedelta

from odoo import models, api, _, fields
from odoo.exceptions import UserError
import logging

_logger = logging.getLogger(__name__)


class EDPreport(models.AbstractModel):
    _name = "report.hotelia.report_edeparture"
    _description = "Expected Departure List Report"

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get("form"):
            raise UserError(
                _("Form content is missing, this report cannot be printed.")
            )
        return {
            "data": data["form"],
            "lines": self.get_lines(data.get("form")),
        }

    @api.model
    def get_lines(self, options):
        groups = dict((tp, []) for tp in ["dp"])
        moves = {}
        where_clause = ""
        sql = """select rs.name,res.name,res.guest_name,ag.name,
                res.arrival_date,res.departure_date,cast(res.reg_adult as int),cast(res.reg_child as int), hct.name,hm.name,res.remark,
                    res.reg_arrival,res.reg_departure
                    from hms_registration res 
                    join hms_room_type rt on res.reg_room_type = rt.id
                    left join hms_room_setup rs on res.reg_room_no = rs.id
                    left join hms_customer_type hct on res.reg_customer_type = hct.id
                    join hms_room_rate rr on res.reg_room_type = rr.room_type
                    left join hmslite_agentsetup ag on res.reg_agent_id=ag.id
                    left join hms_national hm on res.national=hm.id
                    where res.id is not null and res.function_id = '2' and res."Rsv_Type" = 'registration' %s
                    group by res.departure_date,res.reg_room_no,res.name,res.guest_name,ag.name,
                    res.arrival_date,cast(res.reg_adult as int),cast(res.reg_child as int), hct.name,hm.name,res.remark,
                    res.reg_arrival,res.reg_departure,rs.name
             """
        if options["date_from"]:
            where_clause += """and res.departure_date = '%s'  """ % options["date_from"]
        sql_transaction = sql % where_clause
        self.env.cr.execute(sql_transaction)
        results = self.env.cr.fetchall()
        if results:
            for result in results:
                if result[4] and result[5]:
                    sp = (result[5] - result[4]).days
                else:
                    sp = 0
                if result[10] == "<p><br></p>":
                    remark = " "
                else:
                    remark = result[10]
                moves = {
                    "room_no": result[0],
                    "regno": result[1],
                    "guest_name": result[2],
                    "agent": result[3],
                    "arrival": result[4],
                    "departure": result[5],
                    "Adult": result[6],
                    "Child": result[7],
                    "ratetype": result[8],
                    "Nationality": result[9],
                    "remark": remark,
                    "RoomNight": sp,
                }
                groups["dp"].append(moves)
        return groups
