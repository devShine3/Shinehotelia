# -*- coding: utf-8 -*-
from datetime import time
from odoo import models, api, _
from odoo.exceptions import UserError
from datetime import time, datetime, timedelta


class ReportReg(models.AbstractModel):
    _name = "report.hotelia.report_registration_details"
    _description = "Reservation Report"

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get("form"):
            raise UserError(
                _("Form content is missing, this report cannot be printed.")
            )
        return {
            "data": data["form"],
            "lines": self.get_lines(data.get("form")),
        }

    @api.model
    def get_lines(self, options):
        groups = dict((tp, []) for tp in ["registration"])
        moves = {}

        sql = """
        select res.name,res.guest_name,res.arrival_date,res.departure_date,rt.name,res."Rsv_Type",rs.name ,res.reg_date
        from hms_registration  res 
        join hms_room_type rt on res.reg_room_type = rt.id
        left join hms_room_setup rs on res.reg_room_no = rs.id
        where res.id is not null and res.name != 'room'  and function_id = '2'
         """
        if options["roomtype_ids"]:
            sql = sql + """ and res.reg_room_type = %s """ % options["roomtype_ids"][0]

        if options["date_filter"] == "arrdate":
            if options["date_from"]:
                sql = sql + """and res.arrival_date >= '%s'  """ % options["date_from"]
        if options["date_filter"] == "arrdate":
            if options["date_to"]:
                sql = sql + """and res.arrival_date <= '%s'  """ % options["date_to"]

        if options["rsv_type"] == "registration":
            sql = sql + """and res."Rsv_Type" != 'cancel' """

        if options["rsv_type"] == "cancel":
            sql = sql + """and res."Rsv_Type" = 'cancel' """

        if options["date_filter"] == "rsvdate":
            if options["date_from"]:
                sql = sql + """and reg_date >= '%s'  """ % options["date_from"]
        if options["date_filter"] == "rsvdate":
            if options["date_to"]:
                sql = sql + """and reg_date <= '%s'  """ % options["date_to"]
                # sql = sql + '''and reg_date <= '%s'  ''' % new_date_obj_dep

        if (
            not options["roomtype_ids"]
            and not options["date_from"]
            and not options["date_from"]
            and not options["rsv_type"]
        ):
            sql = """
                select res.name,res.guest_name,res.arrival_date,res.departure_date,rt.name,res."Rsv_Type",rs.name ,res.reg_date
                from hms_registration  res 
                join hms_room_type rt on res.reg_room_type = rt.id
                left join hms_room_setup rs on res.reg_room_no = rs.id
                where res.name != 'room'
            """
        self.env.cr.execute(sql)
        results = self.env.cr.fetchall()
        if results:
            for result in results:
                moves = {
                    "rsv_date": result[7],
                    "name": result[0],
                    "guest_name": result[1],
                    "reg_arrival": result[2],
                    "reg_departure": result[3],
                    "reg_room_type": result[4],
                    "Rsv_Type": result[5],
                    "reg_room_no": result[6],
                }
                groups["registration"].append(moves)
        return groups
