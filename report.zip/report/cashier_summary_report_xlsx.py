# -*- coding: utf-8 -*-
from datetime import time
from odoo import models, api, _
from odoo.exceptions import UserError
from datetime import datetime, timedelta
import logging
from collections import namedtuple

_logger = logging.getLogger(__name__)


class ReportCS(models.AbstractModel):
    _name = "report.hotelia.report_cashier_summary_xlsx"
    _description = "Cashier Summary Report"
    _inherit = "report.report_xlsx.abstract"

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get("form"):
            raise UserError(
                _("Form content is missing, this report cannot be printed.")
            )
        return {
            "data": data["form"],
            "lines": self.get_lines(data.get("form")),
        }

    def generate_xlsx_report(self, workbook, data, lines):
        groups_sample = (
            {
                "summary_lines": [
                    {
                        "cashier": "cashier",
                        "lines": [],
                        "total": {},
                    }
                ],
                "detail_lines": [
                    {
                        "group": "date",
                        "currency": "currency_name",
                        "lines": [],
                        "total": {},
                        "net": 0.0,
                        "difference": 0.0,
                    }
                ],
            },
        )
        groups = {
            "summary_lines": [],
            "detail_lines": [],
            "payment_types": [],
            "grand_total": 0.0,
        }

        moves = {}
        select_clause = ""
        where_clause = ""
        advance_receipt_where_clause = ""
        total_pay = 0.0
        company = (
            self.env["res.company"].browse(self._context.get("company_id"))
            or self.env.company
        )
        company_name = company.name
        currency_symbol = str(company.currency_id.symbol)
        currency_format = workbook.add_format(
            {"num_format": "##0.00", "font_size": 12, "align": "vcenter", "bold": True}
        )

        format1 = workbook.add_format(
            {"font_size": 14, "align": "vcenter", "bold": True}
        )
        format2 = workbook.add_format(
            {"font_size": 13, "align": "vcenter", "bold": True}
        )
        format3 = workbook.add_format(
            {
                "font_size": 12,
                "align": "vcenter",
            }
        )
        format4 = workbook.add_format(
            {"font_size": 12, "align": "vcenter", "bold": True}
        )
        report_type = ""
        if data["form"]["report_type"] == "alls":
            report_type = "All - Summary"
        elif data["form"]["report_type"] == "alldetail":
            report_type = "All - Detail"
        sheet = workbook.add_worksheet("Cashier Summary Excel")
        sheet.write(0, 3, "Cashier Summary Report : " + str(report_type), format1)
        sheet.write(2, 0, "From:" + str(data["form"]["date_from"] or ""), format2)
        sheet.write(2, 2, "To:" + str(data["form"]["date_to"] or ""), format2)
        sheet.write(2, 4, "Report Date:" + str(data["form"]["report_date"]), format2)

        detail_sql = """
                          select b.bill_date,reg.reg_room_no,reg.guest_name,b.name,reg.reg_agent_id,p.name,
						    sum(p.amount),c.id,c.name
                                 from hotel_payment_line p
                                 join hotel_payment hp on p.payment_code = hp.id
                                 join hotel_bill b on p.bill_id = b.id
                                 Join hms_registration reg on b.reg_ids = reg.id
                                 join res_currency c on hp.currency = c.id
                                 where p.id is not null %s
                                 group by b.bill_date,b.name,reg.reg_room_no,reg.guest_name,reg.reg_agent_id,
						         p.name,p.amount,c.id,c.name ORDER BY b.bill_date
                      """
        detail_advance_sql = """
                                  select tl.trans_date,reg.reg_room_no,reg.guest_name,reg.reg_agent_id,
        						    sum(tl.trans_price),c.id,c.name,tl.id
                                         from hms_trans_line tl
                                         join hms_transaction t on t.id = tl.trans_lines_id
                                         join hms_registration reg on tl.reg_id = reg.id
                                         join res_currency c on tl.trans_currency = c.id
                                         where t.name='Advance Receipt' %s
                                         group by tl.trans_date,reg.reg_room_no,reg.guest_name,reg.reg_agent_id,
        						         tl.trans_price,c.id,c.name,tl.id ORDER BY tl.trans_date
                              """

        if data["form"]["date_from"]:
            where_clause += " and b.bill_date >= '%s' " % data["form"]["date_from"]
            advance_receipt_where_clause += (
                " and tl.trans_date >= '%s' " % data["form"]["date_from"]
            )

        if data["form"]["date_to"]:
            string_date = data["form"]["date_to"]
            date_obj = datetime.strptime(string_date, "%Y-%m-%d").date()
            new_date_obj = date_obj + timedelta(days=1)
            date_to = new_date_obj.strftime("%Y-%m-%d")
            where_clause += " and b.bill_date < '%s' " % date_to
            advance_receipt_where_clause += " and tl.trans_date < '%s' " % date_to

        sql_detail = detail_sql % where_clause
        sql_detail_advance = detail_advance_sql % advance_receipt_where_clause

        # //summary
        payment = self.env["hotel.payment"].search([])
        for p in payment:
            groups["payment_types"].append(
                {"name": p.name, "key": p.name.replace(" ", "").lower()}
            )
        _logger.info(f"{groups['payment_types']} --PPPPPPP")

        if data["form"]["report_type"] == "alldetail":
            self.env.cr.execute(sql_detail)
            results = self.env.cr.fetchall()
            if results:
                for result in results:
                    company_obj = self.env.user.sudo().company_id
                    base_currency = self.env["res.currency"].search(
                        [("hotelia_base_currency", "=", True)], limit=1
                    )
                    trans_currency = self.env["res.currency"].search(
                        [("id", "=", result[7])], limit=1
                    )
                    rate = base_currency._get_conversion_rate(
                        trans_currency,
                        base_currency,
                        company_obj,
                        datetime.now().date(),
                    )
                    base_amount = result[6] * rate
                    groups["grand_total"] += base_amount
                    total_pay += base_amount
                    moves = {
                        "date": result[0],
                        "room": self.env["hms_room_setup"]
                        .search([("id", "=", result[1])])
                        .name,
                        "guest": result[2],
                        "bill": result[3],
                        "agent": result[4],
                        "PaymentType": result[5],
                        "TransactionType": "Received Amount",
                        "amount": result[6],
                        "baseamount": base_amount,
                        "currency": result[8],
                    }
                    found = False
                    for item in groups["detail_lines"]:
                        if item["group"]["date"] == result[0]:
                            if item["currency"] == result[8]:
                                found = True
                                break
                    if found == True:
                        item["lines"].append(moves)
                        item["total"]["amount"] += result[6]
                    else:
                        group = {"date": result[0]}
                        detail_group = {
                            "group": group,
                            "currency": result[8],
                            "lines": [moves],
                            "total": {
                                "amount": result[6],
                            },
                            "net": base_amount,
                        }
                        groups["detail_lines"].append(detail_group)
            self.env.cr.execute(sql_detail_advance)
            results = self.env.cr.fetchall()
            if results:
                for result in results:
                    transaction = self.env["hms.trans.line"].search(
                        [("id", "=", result[7])]
                    )
                    bill_no = ""
                    payment_type = ""
                    if transaction.bill_id:
                        bill_no = transaction.bill_id.name
                        payment_line = self.env["hotel.payment.line"].search(
                            [("bill_id", "=", transaction.bill_id.id)], limit=1
                        )
                        payment_type = payment_line.payment_code.name

                    company_obj = self.env.user.sudo().company_id
                    base_currency = self.env["res.currency"].search(
                        [("hotelia_base_currency", "=", True)], limit=1
                    )
                    trans_currency = self.env["res.currency"].search(
                        [("id", "=", result[5])], limit=1
                    )
                    rate = base_currency._get_conversion_rate(
                        trans_currency,
                        base_currency,
                        company_obj,
                        datetime.now().date(),
                    )
                    base_amount = result[4] * rate * (-1)
                    groups["grand_total"] += base_amount
                    total_pay += base_amount
                    moves = {
                        "date": result[0],
                        "room": self.env["hms_room_setup"]
                        .search([("id", "=", result[1])])
                        .name,
                        "guest": result[2],
                        "bill": bill_no,
                        "agent": result[3],
                        "PaymentType": transaction.payment_type.name,
                        "TransactionType": "Advance Receipt",
                        "amount": (-1) * result[4],
                        "baseamount": base_amount,
                        "currency": result[6],
                    }
                    found = False
                    for item in groups["detail_lines"]:
                        if item["group"]["date"] == result[0]:
                            if item["currency"] == result[6]:
                                found = True
                                break
                    if found == True:
                        item["lines"].append(moves)
                        item["total"]["amount"] += result[4] * (-1)

                    else:
                        group = {"date": result[0]}
                        detail_group = {
                            "group": group,
                            "currency": result[6],
                            "lines": [moves],
                            "total": {
                                "amount": (-1) * result[4],
                            },
                            "net": base_amount,
                        }
                        groups["detail_lines"].append(detail_group)

            headers = [
                "Date",
                "Room No.",
                "Guest Name",
                "Agent Name",
                "Payment Type",
                "Transaction Type",
                "Amount",
                "Base Amount",
            ]
            for col, header in enumerate(headers):
                sheet.write(4, col, header, format4)
            sheet.set_column(4, 0, 18)
            sheet.set_column(4, 1, 18)
            sheet.set_column(4, 2, 18)
            sheet.set_column(4, 3, 18)
            sheet.set_column(4, 4, 18)
            sheet.set_column(4, 5, 18)
            sheet.set_column(4, 6, 18)
            sheet.set_column(4, 7, 18)
            sheet.set_column(4, 8, 18)
            sheet.set_column(4, 9, 18)
            row = 5
            for group in groups["detail_lines"]:
                for line in group["lines"]:
                    sheet.write(row, 0, line["date"], format3)
                    sheet.write(row, 1, line["room"], format3)
                    sheet.write(row, 2, line["guest"], format3)
                    sheet.write(row, 3, line["bill"], format3)
                    sheet.write(row, 4, line["agent"], format3)
                    sheet.write(row, 5, line["PaymentType"], format3)
                    sheet.write(row, 6, line["TransactionType"], format3)
                    sheet.write(row, 7, line["amount"], currency_format)
                    sheet.write(row, 8, line["baseamount"], currency_format)
                    row += 1
                total_dict = group["total"]
                sheet.write(row, 6, "Sub Total", format4)
                sheet.write(row, 7, group["currency"], format4)
                sheet.write(row, 8, total_dict["amount"], currency_format)
                row += 1
                sheet.write(row, 7, "Grand Total", format4)
                sheet.write(row, 8, groups["grand_total"], currency_format)
                row += 1
        if data["form"]["report_type"] == "alls":
            select_clause = ", ".join(
                [
                    f"SUM(COALESCE(CASE WHEN p.name = '{p.name}' THEN \"amount\" ELSE 0.00 END, 0.00)) as {p.name.replace(' ', '').lower()}"
                    for p in payment
                ]
            )

            summary_sql = """SELECT rp.name as cashier,
                                    %s
                                FROM hotel_payment_line p 

                                JOIN hotel_bill b on p.bill_id = b.id
                                JOIN res_users ru on ru.id = b.create_uid
                                JOIN res_partner rp on rp.id = ru.partner_id
                                WHERE p.id is not null %s
                                GROUP BY rp.name
                                ORDER BY rp.name"""
            advance_receipt_sql = """SELECT rp.name as cashier,p.name as paymenttype,
                                               sum(tl.trans_price)
                                            FROM hms_trans_line tl
                                            JOIN res_users ru on ru.id = tl.create_uid
                                            JOIN res_partner rp on rp.id = ru.partner_id
                                            JOIN hms_transaction t on tl.trans_lines_id = t.id
                                            JOIN hotel_payment p on p.id = tl.payment_type
                                            WHERE t.name='Advance Receipt' %s
                                            GROUP BY rp.name,p.name
                                            ORDER BY rp.name"""
            sql_summary = summary_sql % (select_clause, where_clause)
            sql_advance_receipt = advance_receipt_sql % advance_receipt_where_clause
            _logger.info(f"{sql_summary} --sql_summary")

            self.env.cr.execute(sql_summary)
            results = self.env.cr.fetchall()

            columns = [column[0] for column in self.env.cr.description]
            NamedTupleClass = namedtuple("Record", columns)
            named_results = [NamedTupleClass(*row) for row in results]
            results_dict = []
            for record in named_results:
                results_dict.append(record._asdict())

            _logger.info(f"{results_dict} --named_results")
            _logger.info(f"{results} --results")
            advance_new_user = []
            self.env.cr.execute(sql_advance_receipt)
            advance_results = self.env.cr.fetchall()
            for advance_result in advance_results:
                found = False
                for result_dict in results_dict:
                    advance_positive = (-1) * advance_result[2]
                    if result_dict["cashier"] == advance_result[0]:
                        result_dict[
                            advance_result[1].replace(" ", "").lower()
                        ] += advance_positive
                        found = True
                if found == False:
                    new_user = {"cashier": advance_result[0]}
                    for p_key in groups["payment_types"]:
                        if (
                            p_key.get("key")
                            == advance_result[1].replace(" ", "").lower()
                        ):
                            new_user.update(
                                {
                                    advance_result[1].replace(" ", "").lower(): (-1)
                                    * advance_result[2]
                                }
                            )
                        else:
                            new_user.update({p_key.get("key"): 0.00})

                    advance_new_user.append(new_user)
            if advance_new_user != []:
                for advance_user in advance_new_user:
                    results_dict.append(advance_user)
            cashier_key = "cashier"
            for result_dict in results_dict:
                _logger.info(f"{result_dict} --named_result_only")
                total = 0
                for key, value in result_dict.items():
                    if key != cashier_key:
                        total = total + value
                result_dict.update({"total": total})

                groups["summary_lines"].append(result_dict)
            total_row = {"cashier": "Total"}
            for payment_key in groups["payment_types"]:
                total = 0.0
                for r_dict in results_dict:
                    total += r_dict[payment_key.get("key")]
                total_row.update({payment_key.get("key"): total})
            g_total = 0.0
            for r_dict in results_dict:
                g_total += r_dict["total"]
            total_row.update({"total": g_total})
            groups["summary_lines"].append(total_row)

            headers = [
                "Cashier Name",
            ]  # Add payment types to this list dynamically
            for payment_type in groups["payment_types"]:
                headers.append(payment_type["name"])
            headers.append("Total")  # Add 'Total' column header
            # Write headers to the Excel sheet
            for col, header in enumerate(headers):
                sheet.write(4, col, header, format4)
            sheet.set_column(4, 0, 18)
            for col in range(1, len(headers)):
                sheet.set_column(4, col, 18)
            row = 5
            for group in groups["summary_lines"]:
                sheet.write(row, 0, group["cashier"], format3)
                for col, payment_type in enumerate(groups["payment_types"]):
                    sheet.write(
                        row, col + 1, group[payment_type["key"]], currency_format
                    )
                sheet.write(row, len(headers) - 1, group["total"], currency_format)
                row += 1
            # grand_total = 0.0
            # for group in groups['summary_lines']:
            #     grand_total += group['total']
            # sheet.write(row, 0, 'Grand Total', format4)
            # sheet.write(row, len(headers) - 1, grand_total, currency_format)
