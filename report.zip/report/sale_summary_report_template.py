# -*- coding: utf-8 -*-
from datetime import time
from odoo import models, api, _
from odoo.exceptions import UserError
from datetime import datetime, timedelta


class ReportTrans(models.AbstractModel):
    _name = "report.hotelia.report_sale_summary_details"
    _description = "Sale Summary Report"

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get("form"):
            raise UserError(
                _("Form content is missing, this report cannot be printed.")
            )
        return {
            "data": data["form"],
            "lines": self.get_lines(data.get("form")),
        }

    @api.model
    def _group_by(self):
        return """
            group by t.name, c.name
        """

    @api.model
    def get_lines(self, options):
        groups = {"transaction_lines": [], "sales": 0.0, "receipt": 0.0}
        where_clause = ""
        where_clause_payment = ""
        transaction_sql = """
        select t.name,sum(tl.trans_price),sum(tl.tax),
        sum(tl.service), sum(tl.discount),0, c.name,
        CASE
        WHEN tl.bill_name is null THEN 'unpaid'
        ELSE 'paid'
        END AS status,
        rg.name AS room_name, rg."Rsv_Type" AS rsv_type

        from hms_trans_line tl
        left join hotel_bill b on tl.bill_id = b.id
        join hms_transaction t on tl.trans_lines_id = t.id
        join res_currency c on tl.trans_currency = c.id
        JOIN hms_registration rg ON rg.id = tl.reg_id

        where tl.id is not null
        AND rg."Rsv_Type" NOT ILIKE 'transfer'
        and (tl.non_master_id is null or tl.non_master_id=0) %s
        group by t.name, c.name, status, rg.name, rg."Rsv_Type";
        """
        transaction_sql2 = """
            select p.name,0,0,0,0, sum(p.amount),c.name,
            CASE
            WHEN p.bill_id is null THEN 'unpaid'
            ELSE 'paid'
            END AS status

            from hotel_payment_line p
            join hotel_payment hp on p.payment_code = hp.id
            join hotel_bill b on p.bill_id = b.id
            join res_currency c on hp.currency = c.id

            where p.id is not null %s
            group by p.name,c.name,status 
        """
        user_sql = """
        select t.name,tl.trans_price,tl.tax,
        tl.service, tl.discount,0, c.name, CASE
        WHEN tl.bill_name is null THEN 'unpaid'
        ELSE 'paid'
        END AS status,rp.name

        from hms_trans_line tl
        left join hotel_bill b on tl.bill_id = b.id
        join hms_transaction t on tl.trans_lines_id = t.id
        join res_currency c on tl.trans_currency = c.id
        join res_users u on t.create_uid = u.id
        join res_partner rp on u.partner_id = rp.id

        where tl.id is not null and (tl.non_master_id is null or tl.non_master_id=0) %s order by rp.id
        """
        user_sql2 = """
        select p.name,0,0,0,0, p.amount,c.name,CASE
        WHEN p.bill_id is null THEN 'unpaid'
        ELSE 'paid'
        END AS status,rp.name

        from hotel_payment_line p
        join hotel_payment hp on p.payment_code = hp.id
        join hotel_bill b on p.bill_id = b.id
        join res_currency c on hp.currency = c.id
        join res_users u on p.create_uid = u.id
        join res_partner rp on u.partner_id = rp.id

        where p.id is not null %s order by rp.id
        """
        if options["date_from"]:
            where_clause += " and tl.trans_date >= '%s' " % options["date_from"]
            where_clause_payment += " and b.bill_date >= '%s' " % options["date_from"]
        if options["date_to"]:
            string_date = options["date_to"]

            # Convert the string to a date object
            date_obj = datetime.strptime(str(string_date), "%Y-%m-%d").date()

            # Add one day to the date
            new_date_obj = date_obj + timedelta(days=1)

            # Convert the new date object back to a string in the same format as the original string
            date_to = new_date_obj.strftime("%Y-%m-%d")
            where_clause += " and tl.trans_date < '%s' " % date_to
            where_clause_payment += " and b.bill_date < '%s' " % date_to
        if options["trans_type"] and options["all_or_trans"] == "transaction":
            where_clause += " and t.id= %s " % options["trans_type"][0]
            # where_clause_payment += " and b.bill_date >= '%s' " % options['date_from']
        if options["payment_status"] == "paid":
            where_clause += " and tl.bill_id is not null "
            where_clause_payment += " and p.bill_id is not null "
        if options["payment_status"] == "unpaid":
            where_clause += " and tl.bill_id is null "
            where_clause_payment += " and p.bill_id is null "

        sql_transaction = transaction_sql % where_clause
        sql_transaction2 = transaction_sql2 % where_clause_payment
        sql_user = user_sql % where_clause
        sql_user2 = user_sql2 % where_clause_payment
        base_currency = self.env["res.currency"].search(
            [("hotelia_base_currency", "=", True)], limit=1
        )
        company_obj = self.env.user.sudo().company_id

        if options["report_type"] == "type":
            self.env.cr.execute(sql_transaction)
            results = self.env.cr.fetchall()
            if results:
                for result in results:
                    currency_name = base_currency.name
                    if result[6]:
                        currency_name = result[6]
                    trans_currency = self.env["res.currency"].search(
                        [("name", "=", currency_name)], limit=1
                    )
                    rate = base_currency._get_conversion_rate(
                        trans_currency,
                        base_currency,
                        company_obj,
                        datetime.now().date(),
                    )
                    base_amount = (
                        result[1]
                        or 0.0 + result[2]
                        or 0.0 + result[3]
                        or 0.0 - result[4]
                        or 0.0
                    ) * rate

                    moves = {
                        "transaction": result[0],
                        "trans_price": result[1],
                        "tax": result[2],
                        "service": result[3],
                        "discount": result[4],
                        "amount": result[5],
                        "trans_currency": result[6],
                        "status": result[7],
                        "base_amount": base_amount,
                    }

                    groups["transaction_lines"].append(moves)
                    groups["sales"] += base_amount
            if options["all_or_trans"] == "all":
                self.env.cr.execute(sql_transaction2)
                results = self.env.cr.fetchall()
                if results:
                    for result in results:
                        currency_name = base_currency.name
                        if result[6]:
                            currency_name = result[6]
                        trans_currency = self.env["res.currency"].search(
                            [("name", "=", currency_name)], limit=1
                        )
                        rate = base_currency._get_conversion_rate(
                            trans_currency,
                            base_currency,
                            company_obj,
                            datetime.now().date(),
                        )
                        base_amount = result[5] or 0 * rate
                        moves = {
                            "transaction": result[0],
                            "trans_price": result[5],
                            "tax": result[2],
                            "service": result[3],
                            "discount": result[4],
                            "amount": result[5],
                            "trans_currency": result[6],
                            "status": result[7],
                            "base_amount": base_amount,
                        }
                        groups["transaction_lines"].append(moves)
                        groups["receipt"] += base_amount

        if options["report_type"] != "type":
            self.env.cr.execute(sql_user)
            results = self.env.cr.fetchall()
            if results:
                for result in results:
                    currency_name = base_currency.name
                    if result[6]:
                        currency_name = result[6]
                    trans_currency = self.env["res.currency"].search(
                        [("name", "=", currency_name)], limit=1
                    )
                    rate = base_currency._get_conversion_rate(
                        trans_currency,
                        base_currency,
                        company_obj,
                        datetime.now().date(),
                    )
                    base_amount = (
                        result[1]
                        or 0 + result[2]
                        or 0 + result[3]
                        or 0 - result[4]
                        or 0
                    ) * rate

                    moves = {
                        "transaction": result[0],
                        "trans_price": result[1],
                        "tax": result[2],
                        "service": result[3],
                        "discount": result[4],
                        "amount": result[5],
                        "trans_currency": result[6],
                        "status": result[7],
                        "base_amount": base_amount,
                        "user": result[8],
                    }

                    groups["transaction_lines"].append(moves)
                    groups["sales"] += base_amount
            if options["all_or_trans"] == "all":
                self.env.cr.execute(sql_user2)
                results = self.env.cr.fetchall()
                if results:
                    for result in results:
                        currency_name = base_currency.name
                        if result[6]:
                            currency_name = result[6]
                        trans_currency = self.env["res.currency"].search(
                            [("name", "=", currency_name)], limit=1
                        )
                        rate = base_currency._get_conversion_rate(
                            trans_currency,
                            base_currency,
                            company_obj,
                            datetime.now().date(),
                        )
                        base_amount = result[5] * rate
                        moves = {
                            "transaction": result[0],
                            "trans_price": result[5],
                            "tax": result[2],
                            "service": result[3],
                            "discount": result[4],
                            "amount": result[5],
                            "trans_currency": result[6],
                            "status": result[7],
                            "base_amount": base_amount,
                            "user": result[8],
                        }
                        groups["transaction_lines"].append(moves)
                        groups["receipt"] += base_amount

        return groups
