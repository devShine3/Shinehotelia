# -*- coding: utf-8 -*-
from datetime import datetime
from datetime import timedelta

from odoo import models, api, _, fields
from odoo.exceptions import UserError
import logging

_logger = logging.getLogger(__name__)


class RVreport(models.AbstractModel):
    _name = "report.hotelia.report_rate_variance"
    _description = "RATE VARIANCE REPORT"

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get("form"):
            raise UserError(
                _("Form content is missing, this report cannot be printed.")
            )
        return {
            "data": data["form"],
            "lines": self.get_lines(data.get("form")),
        }

    @api.model
    def get_lines(self, options):
        groups = dict((tp, []) for tp in ["rv"])
        moves = {}
        where_clause = ""
        sql = """
            select rs.name,cast(r.reg_adult as int),cast(r.reg_child as int),r.guest_name,
            hm.name,r.arrival_date,r.departure_date, rt.name,ag.name,ct.name,r.reg_amount,c.name
            from hms_registration r 
            left join hms_room_type rt on r.reg_room_type = rt.id
            left join hms_room_setup rs on r.reg_room_no = rs.id
            left join hms_customer_type ct on r.reg_customer_type = ct.id
			left join hms_national hm on r.national=hm.id
			left join hmslite_agentsetup ag on r.reg_agent_id=ag.id
			left join res_currency c on r.reg_currency = c.id
            where r.id is not null and r.name != 'room' %s
            and r."Rsv_Type" in ('registration','transfer','check_out') 
             """
        if options["date_from"]:
            where_clause += """and r.arrival_date >= '%s'  """ % options["date_from"]
        if options["date_to"]:
            where_clause += """and r.departure_date <= '%s'  """ % options["date_to"]
        sql_transaction = sql % where_clause
        self.env.cr.execute(sql_transaction)
        results = self.env.cr.fetchall()
        if results:
            for result in results:
                if result[1] or result[2]:
                    adult = result[1] or 0
                    child = result[2] or 0
                    pax = adult + child
                else:
                    pax = 0
                moves = {
                    "room_no": result[0],
                    "pax": pax,
                    "guest_name": result[3],
                    "national": result[4],
                    "arrival": result[5],
                    "departure": result[6],
                    "room_type": result[7],
                    "agent": result[8],
                    "rate_type": result[9],
                    "roomrate": result[10],
                    "currency": result[11],
                }
                groups["rv"].append(moves)
        return groups
