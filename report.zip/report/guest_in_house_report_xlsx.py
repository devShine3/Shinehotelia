# -*- coding: utf-8 -*-
import time
from datetime import timedelta, datetime

from odoo import models, api, _, fields
from odoo.exceptions import UserError
from io import BytesIO
import io
import xlsxwriter


class GIHreport(models.AbstractModel):
    _name = "report.hotelia.report_gih_xlsx"
    _description = "Guest Inhouse Report"
    _inherit = "report.report_xlsx.abstract"

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get("form"):
            raise UserError(
                _("Form content is missing, this report cannot be printed.")
            )
        return {
            "data": data["form"],
            "lines": self.get_lines(data.get("form")),
        }

    def generate_xlsx_report(self, workbook, data, lines):
        groups = {"reservation": [], "registration": [], "total": 0.0}

        moves = {}
        total_count = 0

        company = (
            self.env["res.company"].browse(self._context.get("company_id"))
            or self.env.company
        )
        company_name = company.name
        currency_symbol = str(company.currency_id.symbol)
        currency_format = workbook.add_format(
            {"num_format": "##0.00", "font_size": 12, "align": "vcenter", "bold": True}
        )
        format1 = workbook.add_format(
            {"font_size": 14, "align": "vcenter", "bold": True}
        )
        format2 = workbook.add_format(
            {"font_size": 13, "align": "vcenter", "bold": True}
        )
        format3 = workbook.add_format(
            {
                "font_size": 12,
                "align": "vcenter",
            }
        )
        format4 = workbook.add_format(
            {"font_size": 12, "align": "vcenter", "bold": True}
        )
        format5 = workbook.add_format(
            {
                "num_format": "dd/mm/yy",
                "font_size": 13,
                "align": "vcenter",
                "bold": True,
            }
        )
        sheet = workbook.add_worksheet("Guest In House Report Excel")

        if data["form"]["report_type"] == "byroom":
            report_type = "By Room"
            sheet.write(
                0, 3, "Guest In House Report By Room : " + str(report_type), format1
            )

        elif data["form"]["report_type"] == "police":
            report_type = "Police"
            if data["form"]["national"] == "local":
                national = "Local"
            elif data["form"]["national"] == "foreigner":
                national = "Foreigner"
            sheet.write(0, 3, "Police Report: " + str(national), format1)

        elif data["form"]["report_type"] == "iall":
            report_type = "Immigration for All"
            sheet.write(0, 3, "Immigration for All Report", format1)

        elif data["form"]["report_type"] == "immigration":
            report_type = "Immigration"
            national = "Local"
            if data["form"]["national"] == "local":
                national = "Local"
            elif data["form"]["national"] == "foreigner":
                national = "Foreigner"
            sheet.write(0, 3, "Immigration Report: " + str(national), format1)
        agent = ""
        group = ""
        company = ""
        if data["form"]["agent"]:
            agent = (
                self.env["hmslite.agentsetup"]
                .search([("id", "=", data["form"]["agent"][0])])
                .name
            )
        if data["form"]["group"]:
            group = (
                self.env["hms.groupreserve"]
                .search([("id", "=", data["form"]["group"][0])])
                .name
            )
        if data["form"]["company"]:
            company = (
                self.env["hmslite.companysetup"]
                .search([("id", "=", data["form"]["company"][0])])
                .name
            )
        if data["form"]["type_reservation"] != "all":
            sheet.write(2, 0, "Agent:" + str(agent or "All"), format2)
            sheet.write(2, 2, "Group:" + str(group or "All"), format2)
            sheet.write(2, 4, "Company:" + str(company or "All"), format2)
        sheet.write(3, 6, "Choose Date:" + str(data["form"]["choose_date"]), format5)
        sheet.write(3, 4, "Report Date:" + str(data["form"]["report_date"]), format5)
        sql = """ select res.name,gl.name,res.arrival_date,res.departure_date,
                     rt.name,res."Rsv_Type",rs.name ,res.reg_date,rs.name,
                     ag.name,res.reg_room_type,res.reg_group_id,hc.name,
                     hm.name,cast(res.reg_adult as int),cast(res.reg_child as int),gl.date_of_birth,
                     gl.gender,res.contact_person,
                     gl.nrc,gl.passport_no,'',res.reg_arrival,res.reg_departure,hg.citizen
                     from hms_registration res
                     join hms_guestline gl on res.id = gl.registration_id
                     join hms_room_type rt on res.reg_room_type = rt.id
                     join hotel_guest hg on hg.id=gl.guest_id
                     left join hms_room_setup rs on res.reg_room_no = rs.id
                     left join hmslite_agentsetup ag on res.reg_agent_id=ag.id
                     left join hmslite_companysetup hc on res.reg_company_id=hc.id
                     left join hms_national hm on gl.nationality=hm.id
                     where res.id is not null and res.function_id = '2' and res."Rsv_Type" = 'registration' and
                     rt.name <>'Dummy Room'
                      """
        sql_count = """ select count(distinct res.name)
                     from hms_registration res
                     join hms_guestline gl on res.id = gl.registration_id
                     join hms_room_type rt on res.reg_room_type = rt.id
                     join hotel_guest hg on hg.id=gl.guest_id
                     left join hms_room_setup rs on res.reg_room_no = rs.id
                     left join hmslite_agentsetup ag on res.reg_agent_id=ag.id
                     left join hmslite_companysetup hc on res.reg_company_id=hc.id
                     left join hms_national hm on gl.nationality=hm.id
                     where res.id is not null and res.function_id = '2' and res."Rsv_Type" = 'registration' and
                     rt.name <>'Dummy Room'
                         """

        string_date = ""
        if isinstance(data["form"]["choose_date"], str):
            string_date = data["form"]["choose_date"]
        else:
            string_date = data["form"]["choose_date"].strftime("%Y-%m-%d")

        # Convert the string to a date object
        date_obj = datetime.strptime(str(string_date), "%Y-%m-%d").date()
        # Add one day to the date
        new_date_obj_dep = date_obj - timedelta(days=1)
        new_date_obj_arriv = date_obj + timedelta(days=1)

        # Convert the new date object back to a string in the same format as the original string
        date_arrival = new_date_obj_arriv.strftime("%Y-%m-%d")
        if data["form"]["agent"]:
            sql = sql + """ and res.reg_agent_id=%s""" % data["form"]["agent"][0]
            sql_count = (
                sql_count + """ and res.reg_agent_id=%s""" % data["form"]["agent"][0]
            )
        if data["form"]["group"]:
            sql = sql + """ and res.reg_group_id='%s' """ % data["form"]["group"][1]
            sql_count = (
                sql_count + """ and res.reg_group_id='%s' """ % data["form"]["group"][1]
            )
        if data["form"]["company"]:
            sql = sql + """ and res.reg_company_id=%s""" % data["form"]["company"][0]
            sql_count = (
                sql_count
                + """ and res.reg_company_id=%s""" % data["form"]["company"][0]
            )
        if data["form"]["national"] == "local":
            sql = sql + """ and  hg.citizen = 'local' """
            sql_count = sql_count + """ and  hg.citizen = 'local' """
        if data["form"]["national"] == "foreigner":
            sql = sql + """ and  hg.citizen = 'foreign' """
            sql_count = sql_count + """ and  hg.citizen = 'foreign' """
        if data["form"]["choose_date"]:
            current_date = fields.Date.context_today(self)
            if data["form"]["choose_date"] == current_date and isinstance(
                data["form"]["choose_date"], str
            ):
                sql = (
                    sql
                    + """ and res.arrival_date <= '%s' and res.departure_date >= '%s' """
                    % (data["form"]["choose_date"], data["form"]["choose_date"])
                )
                sql_count = (
                    sql_count
                    + """ and res.arrival_date <= '%s' and res.departure_date >= '%s' """
                    % (data["form"]["choose_date"], data["form"]["choose_date"])
                )

        self.env.cr.execute(sql_count)
        results_count = self.env.cr.fetchall()
        for c in results_count:
            total_count = c[0]
        groups["total"] = total_count
        self.env.cr.execute(sql)
        results = self.env.cr.fetchall()
        if results:
            for result in results:
                age = ""
                date_of_birth = ""
                visa = ""
                if result[20] and result[20] != "False":
                    visa = result[20]
                if result[16]:
                    date_of_birth = result[16].strftime("%d-%m-%Y")
                    dob = result[16] or 0
                    current_date = datetime.now()
                    if date_of_birth:
                        age = current_date.year - dob.year
                        if current_date.month < dob.month or (
                            current_date.month == dob.month
                            and current_date.day < dob.day
                        ):
                            age -= 1
                if result[2] and result[3]:
                    sp = (result[3] - result[2]).days
                else:
                    sp = 0

                moves = {
                    "rsv_date": result[7],
                    "total_room": result[0],
                    "room_type": result[4],
                    "Rsv_Type": result[5],
                    "room_no": result[6],
                    "agent_id": result[9],
                    "group_id": result[11],
                    "company_id": result[12],
                    "guest_name": result[1],
                    "dob": date_of_birth,
                    "age": age,
                    "sex": result[17],
                    "father": result[18],
                    "id": result[19],
                    "Visa": visa,
                    "national": result[13],
                    "address": result[21],
                    "arrival": result[2],
                    "departure": result[3],
                    "sp": sp,
                    "adult": result[14],
                    "child": result[15],
                }
                groups["reservation"].append(moves)

            if data["form"]["report_type"] == "byroom":
                # Add headers
                headers = [
                    "Room No.",
                    "Guest Name",
                    "Arrival",
                    "Departure",
                    "Agent",
                    "Group",
                    "Company",
                    "Nationality",
                ]
                for col, header in enumerate(headers):
                    sheet.write(5, col, header, format4)

                sheet.set_column(5, 0, 18)
                sheet.set_column(5, 1, 18)
                sheet.set_column(5, 2, 18)
                sheet.set_column(5, 3, 18)
                sheet.set_column(5, 4, 18)
                sheet.set_column(5, 5, 18)
                sheet.set_column(5, 6, 18)
                sheet.set_column(5, 7, 18)

                row = 6
                for line in groups["reservation"]:
                    sheet.write(row, 0, line["room_no"], format3)
                    sheet.write(row, 1, line["guest_name"], format3)
                    sheet.write(row, 2, line["arrival"].strftime("%d-%m-%Y"), format3)
                    sheet.write(row, 3, line["departure"].strftime("%d-%m-%Y"), format3)
                    sheet.write(row, 4, line["agent_id"], format3)
                    sheet.write(row, 5, line["group_id"], format3)
                    sheet.write(row, 6, line["company_id"], format3)
                    sheet.write(row, 7, line["national"], format3)
                    row += 1

            if data["form"]["report_type"] == "immigration":
                # Add headers
                headers = [
                    "Room No.",
                    "Guest Name",
                    "Date Of Birth",
                    "Age",
                    "Sex",
                    "Father",
                    "ID/ Passport",
                    "Visa No.",
                    "Nationality",
                    "Address",
                    "Arrival",
                    "Departure",
                    "Stay Periods",
                ]
                for col, header in enumerate(headers):
                    sheet.write(5, col, header, format4)
                sheet.set_column(5, 0, 18)
                sheet.set_column(5, 1, 18)
                sheet.set_column(5, 2, 18)
                sheet.set_column(5, 3, 18)
                sheet.set_column(5, 4, 18)
                sheet.set_column(5, 5, 18)
                sheet.set_column(5, 6, 18)
                sheet.set_column(5, 7, 18)
                sheet.set_column(5, 8, 18)
                sheet.set_column(5, 9, 18)
                sheet.set_column(5, 10, 18)
                sheet.set_column(5, 11, 18)
                sheet.set_column(5, 12, 18)
                sheet.set_column(5, 13, 18)
                row = 6
                for line in groups["reservation"]:
                    sheet.write(row, 0, line["room_no"], format3)
                    sheet.write(row, 1, line["guest_name"], format3)
                    sheet.write(row, 2, line["dob"], format3)
                    sheet.write(row, 3, line["age"], format3)
                    sheet.write(row, 4, line["sex"], format3)
                    sheet.write(row, 5, line["father"], format3)
                    sheet.write(row, 6, line["id"], format3)
                    sheet.write(row, 7, line["Visa"], format3)
                    sheet.write(row, 8, line["national"], format3)
                    sheet.write(row, 9, line["address"], format3)
                    sheet.write(row, 10, line["arrival"].strftime("%d-%m-%Y"), format3)
                    sheet.write(
                        row, 11, line["departure"].strftime("%d-%m-%Y"), format3
                    )
                    sheet.write(row, 12, line["sp"], format3)
                    row += 1

            if data["form"]["report_type"] == "iall":
                # Add headers
                headers = [
                    "Room No.",
                    "Guest Name",
                    "Date Of Birth",
                    "Age",
                    "Sex",
                    "Father",
                    "ID/ Passport",
                    "Visa No.",
                    "Nationality",
                    "Address",
                    "Arrival",
                    "Departure",
                    "Stay Periods",
                ]
                for col, header in enumerate(headers):
                    sheet.write(5, col, header, format4)
                sheet.set_column(5, 0, 18)
                sheet.set_column(5, 1, 18)
                sheet.set_column(5, 2, 18)
                sheet.set_column(5, 3, 18)
                sheet.set_column(5, 4, 18)
                sheet.set_column(5, 5, 18)
                sheet.set_column(5, 6, 18)
                sheet.set_column(5, 7, 18)
                sheet.set_column(5, 8, 18)
                sheet.set_column(5, 9, 18)
                sheet.set_column(5, 10, 18)
                sheet.set_column(5, 11, 18)
                sheet.set_column(5, 12, 18)
                sheet.set_column(5, 13, 18)
                row = 6
                for line in groups["reservation"]:
                    sheet.write(row, 0, line["room_no"], format3)
                    sheet.write(row, 1, line["guest_name"], format3)
                    sheet.write(row, 2, line["dob"], format3)
                    sheet.write(row, 3, line["age"], format3)
                    sheet.write(row, 4, line["sex"], format3)
                    sheet.write(row, 5, line["father"], format3)
                    sheet.write(row, 6, line["id"], format3)
                    sheet.write(row, 7, line["Visa"], format3)
                    sheet.write(row, 8, line["national"], format3)
                    sheet.write(row, 9, line["address"], format3)
                    sheet.write(row, 10, line["arrival"].strftime("%d-%m-%Y"), format3)
                    sheet.write(
                        row, 11, line["departure"].strftime("%d-%m-%Y"), format3
                    )
                    sheet.write(row, 12, line["sp"], format3)
                    row += 1

            if data["form"]["report_type"] == "police":
                # Add headers
                headers = [
                    "Room No.",
                    "Guest Name",
                    "Date Of Birth",
                    "Age",
                    "Sex",
                    "Father",
                    "ID/ Passport",
                    "Visa No.",
                    "Nationality",
                    "Address",
                    "Arrival",
                    "Departure",
                    "Stay Periods",
                ]
                for col, header in enumerate(headers):
                    sheet.write(5, col, header, format4)
                sheet.set_column(5, 0, 18)
                sheet.set_column(5, 1, 18)
                sheet.set_column(5, 2, 18)
                sheet.set_column(5, 3, 18)
                sheet.set_column(5, 4, 18)
                sheet.set_column(5, 5, 18)
                sheet.set_column(5, 6, 18)
                sheet.set_column(5, 7, 18)
                sheet.set_column(5, 8, 18)
                sheet.set_column(5, 9, 18)
                sheet.set_column(5, 10, 18)
                sheet.set_column(5, 11, 18)
                sheet.set_column(5, 12, 18)
                sheet.set_column(5, 13, 18)
                row = 6
                for line in groups["reservation"]:
                    sheet.write(row, 0, line["room_no"], format3)
                    sheet.write(row, 1, line["guest_name"], format3)
                    sheet.write(row, 2, line["dob"], format3)
                    sheet.write(row, 3, line["age"], format3)
                    sheet.write(row, 4, line["sex"], format3)
                    sheet.write(row, 5, line["father"], format3)
                    sheet.write(row, 6, line["id"], format3)
                    sheet.write(row, 7, line["Visa"], format3)
                    sheet.write(row, 8, line["national"], format3)
                    sheet.write(row, 9, line["address"], format3)
                    sheet.write(row, 10, line["arrival"].strftime("%d-%m-%Y"), format3)
                    sheet.write(
                        row, 11, line["departure"].strftime("%d-%m-%Y"), format3
                    )
                    sheet.write(row, 12, line["sp"], format3)
                    row += 1
        sheet.write(3, 2, "Pax:" + str(len(groups["reservation"])), format2)
        sheet.write(3, 0, "Total Room:" + str(groups["total"]), format2)
