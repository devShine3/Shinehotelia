# -*- coding: utf-8 -*-
from datetime import date as dt
from datetime import datetime, timedelta
from datetime import time
import calendar
from calendar import monthrange
import datetime
from odoo import models, api, _
from odoo.exceptions import UserError
from odoo import models, fields, api
from dateutil import parser
import logging
from datetime import datetime, date

_logger = logging.getLogger(__name__)


class ReportYP(models.AbstractModel):
    _name = "report.hotelia.report_year_plan"
    _description = "Year Plan Report"

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get("form"):
            raise UserError(
                _("Form content is missing, this report cannot be printed.")
            )
        return {
            "data": data["form"],
            "lines": self.get_lines(data.get("form")),
        }

    @api.model
    def get_lines(self, options):
        groups = {
            "day": [
                {
                    "header": "header",
                    "month": [],
                    "total": [],
                    "MinD": 0,
                    "MinDT": 0,
                    "Def": 0,
                    "DplusT": 0,
                }
            ],
            "total": [],
        }
        months = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
        
        for day in range(1, 32):
                day_arr = {}
                month_arr = []
                for month in months:
                    dt_sql = """
                                WITH date_series AS (
                                    SELECT generate_series(
                                        (SELECT MIN(arrival_date) FROM hms_registration),
                                        (SELECT MAX(departure_date) FROM hms_registration),
                                    interval '1 day'
                                    )::date AS date
                                )
                                SELECT
                                    COALESCE(COUNT(DISTINCT CASE WHEN hr."Rsv_Type" = 'check_out' AND ds.date = hr.departure_date THEN NULL ELSE hr.reg_room_no END), 0) AS record_count
                                FROM
                                    date_series ds
                                LEFT JOIN
                                    hms_registration hr
                                ON ds.date >= hr.arrival_date AND ds.date <= hr.departure_date
                                    AND ((ds.date < NOW()::date AND "Rsv_Type" NOT IN ('cancel', 'noshow'))
                                        OR
                                         (ds.date = NOW()::date AND "Rsv_Type" NOT IN ('cancel', 'noshow', 'check_out'))
                                        )
                                    AND "reg_room_type" != 7
                                WHERE EXTRACT(MONTH FROM ds.date) = %s
                                    AND EXTRACT(Year FROM ds.date) = %s
                                    AND EXTRACT(DAY FROM ds.date) = %s
                                    AND ds.date <= NOW()::date
                                GROUP BY
                                    ds.date
                                ORDER BY
                                    ds.date
                    """ % (
                        month,
                        options["year"],
                        day,
                    )
                    self.env.cr.execute(dt_sql)
                    results = self.env.cr.fetchall()
                    definite = 0
                    for result in results:
                        definite = result[0]
                        # total_definite += definite
                    tt_sql = """
                            WITH date_series AS (
                                SELECT generate_series(
                                    (SELECT MIN(departure_date) FROM hotel_reservation),
                                    (SELECT MAX(departure_date) FROM hotel_reservation),
                                    interval '1 day'
                                )::date AS date
                            )
                            SELECT
                                COALESCE(COUNT(hr.id), 0) AS cancellation_count
                            FROM
                                date_series ds
                            LEFT JOIN
                                hotel_reservation hr
                            ON ds.date = hr.departure_date AND "Rsv_Type" IN ('cancel', 'noshow')
                            WHERE EXTRACT(MONTH FROM departure_date) = %s 
	                            AND EXTRACT(YEAR FROM departure_date) = %s
                                AND EXTRACT(DAY FROM ds.date) = %s
                            GROUP BY
                                ds.date
                            ORDER BY
                                ds.date;
                    """ % (
                        month,
                        options["year"],
                        day
                    )
                    self.env.cr.execute(tt_sql)
                    results = self.env.cr.fetchall()
                    tentative = 0
                    for result in results:
                        tentative = result[0]
                        # total_tentative += tentative

                    month_arr.append(
                        {
                            "definite": definite,
                            "tentative": tentative,
                        }
                    )
                if month_arr:
                    day_arr = {
                        "header": day,
                        "month": month_arr,
                    }
                    groups["day"].append(day_arr)

        for month in months:
                total_tentative = 0
                total_definite = 0
                for day in range(1, 32):
                    dt_sql = """
                                WITH date_series AS (
                                    SELECT generate_series(
                                        (SELECT MIN(arrival_date) FROM hms_registration),
                                        (SELECT MAX(departure_date) FROM hms_registration),
                                    interval '1 day'
                                    )::date AS date
                                )
                                SELECT
                                    COALESCE(COUNT(DISTINCT CASE WHEN hr."Rsv_Type" = 'check_out' AND ds.date = hr.departure_date THEN NULL ELSE hr.reg_room_no END), 0) AS record_count
                                FROM
                                    date_series ds
                                LEFT JOIN
                                    hms_registration hr
                                ON ds.date >= hr.arrival_date AND ds.date <= hr.departure_date
                                    AND ((ds.date < NOW()::date AND "Rsv_Type" NOT IN ('cancel', 'noshow'))
                                        OR
                                         (ds.date = NOW()::date AND "Rsv_Type" NOT IN ('cancel', 'noshow', 'check_out'))
                                        )
                                    AND "reg_room_type" != 7
                                WHERE EXTRACT(MONTH FROM ds.date) = %s
                                    AND EXTRACT(Year FROM ds.date) = %s
                                    AND EXTRACT(DAY FROM ds.date) = %s
                                    AND ds.date <= NOW()::date
                                GROUP BY
                                    ds.date
                                ORDER BY
                                    ds.date
                    """ % (
                        month,
                        options["year"],
                        day,
                    )
                    self.env.cr.execute(dt_sql)
                    results = self.env.cr.fetchall()
                    for result in results:
                        definite = result[0]
                        total_definite += definite
                    tt_sql = """
                            WITH date_series AS (
                                SELECT generate_series(
                                    (SELECT MIN(departure_date) FROM hotel_reservation),
                                    (SELECT MAX(departure_date) FROM hotel_reservation),
                                    interval '1 day'
                                )::date AS date
                            )
                            SELECT
                                COALESCE(COUNT(hr.id), 0) AS cancellation_count
                            FROM
                                date_series ds
                            LEFT JOIN
                                hotel_reservation hr
                            ON ds.date = hr.departure_date AND "Rsv_Type" IN ('cancel', 'noshow')
                            WHERE EXTRACT(MONTH FROM departure_date) = %s 
	                            AND EXTRACT(YEAR FROM departure_date) = %s
                                AND EXTRACT(DAY FROM ds.date) = %s
                            GROUP BY
                                ds.date
                            ORDER BY
                                ds.date;
                    """ % (
                        month,
                        options["year"],
                        day,
                    )
                    self.env.cr.execute(tt_sql)
                    results = self.env.cr.fetchall()
                    for result in results:
                        tentative = result[0]
                        total_tentative += tentative
                year = int(options["year"])
                days_in_month = calendar.monthrange(year, month)[1]
                _logger.info(f"{days_in_month} --days_in_month")
                total_rooms = (
                    self.env["hms_room_setup"]
                    .sudo()
                    .search_count([("function", "=", False)])
                )
                MinDT = total_definite + total_tentative
                tm = total_rooms * int(days_in_month)
                Def = (total_definite / tm) * 100
                DplusT = (MinDT / tm) * 100
                groups["total"].append(
                    {
                        "total_definite": total_definite,
                        "total_tentative": total_tentative,
                        "MinD": total_definite,
                        "MinDT": MinDT,
                        "Def": Def,
                        "DplusT": DplusT,
                    }
                )

        return groups
