# -*- coding: utf-8 -*-
import time
from datetime import timedelta, datetime

from odoo import models, api, _
from odoo.exceptions import UserError


class SIreport(models.AbstractModel):
    _name = "report.hotelia.report_si_xlsx"
    _description = "Summary Income Report"
    _inherit = "report.report_xlsx.abstract"

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get("form"):
            raise UserError(
                _("Form content is missing, this report cannot be printed.")
            )
        return {
            "data": data["form"],
            "lines": self.get_lines(data.get("form")),
        }

    def generate_xlsx_report(self, workbook, data, lines):
        groups_sample = {
            "transaction_lines": [
                {
                    "group": "currency_name",
                    "sub_group": [
                        {"header": {}, "payment_type": {}, "sub_lines": [{}, {}]},
                    ],
                    "total": {},
                    "net": 0.0,
                    "difference": 0.0,
                }
            ],
            "summary_lines": [
                {
                    "group": "currency_name",
                    "lines": [],
                    "total": {},
                    "net": 0.0,
                    "difference": 0.0,
                }
            ],
        }
        groups = {"summary_lines": [], "transaction_lines": [], "bill_lines": []}

        moves = {}
        receipt = {}
        where_clause = ""
        where_clause_payment = ""
        where_advance_clause = ""
        company = (
            self.env["res.company"].browse(self._context.get("company_id"))
            or self.env.company
        )
        company_name = company.name
        currency_symbol = str(company.currency_id.symbol)
        currency_format = workbook.add_format(
            {"num_format": "##0.00", "font_size": 12, "align": "vcenter", "bold": True}
        )

        format1 = workbook.add_format(
            {"font_size": 14, "align": "vcenter", "bold": True}
        )
        format2 = workbook.add_format(
            {"font_size": 13, "align": "vcenter", "bold": True}
        )
        format3 = workbook.add_format(
            {
                "font_size": 12,
                "align": "vcenter",
            }
        )
        format4 = workbook.add_format(
            {"font_size": 12, "align": "vcenter", "bold": True}
        )

        if data["form"]["report_type"] == "summary":
            report_type = "Summary"
        elif data["form"]["report_type"] == "transaction":
            report_type = "Detail By Transaction Type"
        elif data["form"]["report_type"] == "bill":
            report_type = "Detail by Bill No"

        sheet = workbook.add_worksheet("Summary Income Excel")
        sheet.write(0, 3, "Summary Income Report : " + str(report_type), format1)
        sheet.write(2, 0, "From:" + str(data["form"]["date_from"]), format2)
        sheet.write(2, 2, "To:" + str(data["form"]["date_to"]), format2)
        sheet.write(2, 4, "Report Date:" + str(data["form"]["report_date"]), format2)

        summary_sql = """ 
            select t.name,sum(tl.trans_price),sum(tl.tax),
                        sum(tl.service), sum(tl.discount),0, c.name
                        from hms_trans_line tl
                        join hotel_bill b on tl.bill_id = b.id
                        join hms_transaction t on tl.trans_lines_id = t.id
                        join res_currency c on tl.trans_currency = c.id
                        where tl.id is not null  
                        and t.name != 'Advance Receipt'
                        %s
                        group by t.name, c.name 
                        UNION
                        %s

        """

        summary_advance_sql = """select t.name,0,sum(tl.tax),
                   sum(tl.service), sum(tl.discount),sum(tl.trans_price) * -1, c.name
                   from hms_trans_line tl
                   join hms_transaction t on tl.trans_lines_id = t.id
                   join res_currency c on tl.trans_currency = c.id

                   where t.name='Advance Receipt' and  tl.id is not null 
                    %s
                   group by t.name, c.name   """

        summary_sql2 = """
            select 'Received Amount',0,0,0,0, sum(p.amount),c.name
            from hotel_payment_line p
            join hotel_payment hp on p.payment_code = hp.id
            join hotel_bill b on p.bill_id = b.id
            join res_currency c on hp.currency = c.id
            where p.id is not null %s
            group by p.name,c.name
        """

        transaction_sql = """
            select t.name,sum(tl.trans_price),sum(tl.tax),
                    sum(tl.service), sum(tl.discount),0,c.name,
                    reg.name,tl.id,reg.reg_room_no,reg.guest_name,b.name,
                    b.bill_date,tl.trans_date,tl.payment_type from hms_trans_line tl
                         join hms_transaction t on tl.trans_lines_id = t.id
                         Join hms_registration reg on tl.reg_id = reg.id
                         join hotel_bill b on tl.bill_id = b.id
                         join res_currency c on tl.trans_currency = c.id
                         where t.name != 'Advance Receipt' %s
                         group by reg.name,tl.id,reg.reg_room_no,reg.guest_name,
                         b.name,b.bill_date,tl.trans_date,t.name, c.name,tl.payment_type
                         UNION
                         %s
        """
        advance_transaction_sql = """select t.name,0,sum(tl.tax),
        sum(tl.service), sum(tl.discount),sum(tl.trans_price) * -1,c.name,
        reg.name,tl.id,reg.reg_room_no,reg.guest_name,'',
        tl.trans_date,tl.trans_date,tl.payment_type
        from hms_trans_line tl
        join hms_transaction t on tl.trans_lines_id = t.id
        Join hms_registration reg on tl.reg_id = reg.id
        join res_currency c on tl.trans_currency = c.id
        where t.name='Advance Receipt' %s
        group by reg.name,tl.id,reg.reg_room_no,reg.guest_name,
        tl.trans_date,t.name, c.name,tl.trans_date,tl.payment_type """

        transaction_sql2 = """
                    select p.name,0,0,
                            0, 0,sum(p.amount),c.name,
                            reg.name,p.id,reg.reg_room_no,reg.guest_name,b.name,
                            b.bill_date
                                 from hotel_payment_line p
                                 join hotel_payment hp on p.payment_code = hp.id
                                 join hotel_bill b on p.bill_id = b.id
                                 Join hms_registration reg on b.reg_ids = reg.id
                                 join res_currency c on hp.currency = c.id
                                 where p.id is not null %s
                                 group by reg.name,p.id,reg.reg_room_no,reg.guest_name,
                                 b.name,b.bill_date,p.name, c.name
                """

        if data["form"]["date_from"]:
            where_clause += " and b.bill_date >= '%s' " % data["form"]["date_from"]
            where_advance_clause += (
                " and tl.trans_date >= '%s' " % data["form"]["date_from"]
            )
            where_clause_payment += (
                " and b.bill_date >= '%s' " % data["form"]["date_from"]
            )

        if data["form"]["date_to"]:
            string_date = data["form"]["date_to"]
            date_obj = datetime.strptime(string_date, "%Y-%m-%d").date()
            new_date_obj = date_obj + timedelta(days=1)
            date_to = new_date_obj.strftime("%Y-%m-%d")
            where_clause += " and b.bill_date < '%s' " % date_to
            where_advance_clause += " and tl.trans_date < '%s' " % date_to
            where_clause_payment += " and b.bill_date < '%s' " % date_to

        summary_advance_sql = summary_advance_sql % where_advance_clause
        sql_summary = summary_sql % (where_clause, summary_advance_sql)
        sql_summary2 = summary_sql2 % where_clause_payment

        advance_transaction_sql = advance_transaction_sql % where_advance_clause
        sql_transaction = transaction_sql % (where_clause, advance_transaction_sql)
        sql_transaction2 = transaction_sql2 % where_clause_payment

        if data["form"]["report_type"] == "summary":
            self.env.cr.execute(sql_summary)
            results = self.env.cr.fetchall()
            if results:
                for result in results:
                    moves = {
                        "name": result[0],
                        "trans_price": result[1],
                        "tax": result[2],
                        "service": result[3],
                        "discount": result[4],
                        "amount": result[5],
                        "trans_currency": result[6],
                    }
                    found = False
                    for item in groups["summary_lines"]:
                        if item.get("group") == result[6]:
                            found = True
                            break

                    if found == True:
                        item["lines"].append(moves)
                        item["total"]["price"] += result[1]
                        item["total"]["tax"] += result[2]
                        item["total"]["service"] += result[3]
                        item["total"]["discount"] += result[4]
                        item["total"]["amount"] += result[5]
                        item["net"] += result[1] + result[2] + result[3] - result[4]
                        item["difference"] += result[5] - (
                            result[1] + result[2] + result[3] - result[4]
                        )
                    else:
                        detail_group = {
                            "group": result[6],
                            "lines": [moves],
                            "total": {
                                "price": result[1],
                                "tax": result[2],
                                "service": result[3],
                                "discount": result[4],
                                "amount": result[5],
                            },
                            "net": result[1] + result[2] + result[3] - result[4],
                            "difference": result[5]
                            - (result[1] + result[2] + result[3] - result[4]),
                        }
                        groups["summary_lines"].append(detail_group)
            self.env.cr.execute(sql_summary2)
            results = self.env.cr.fetchall()
            if results:
                for result in results:
                    moves = {
                        "name": result[0],
                        "trans_price": result[1],
                        "tax": result[2],
                        "service": result[3],
                        "discount": result[4],
                        "amount": result[5],
                        "trans_currency": result[6],
                    }
                    found = False

                    for item in groups["summary_lines"]:
                        if item.get("group") == result[6]:
                            found = True
                            break

                    if found == True:
                        item["lines"].append(moves)
                        item["total"]["price"] += result[1]
                        item["total"]["tax"] += result[2]
                        item["total"]["service"] += result[3]
                        item["total"]["discount"] += result[4]
                        item["total"]["amount"] += result[5]
                        item["net"] += result[1] + result[2] + result[3] - result[4]

                        # item ['gt'] +=
                        item["difference"] += result[5] - (
                            result[1] + result[2] + result[3] - result[4]
                        )
                    else:
                        detail_group = {
                            "group": result[6],
                            "lines": [moves],
                            "total": {
                                "price": result[1],
                                "tax": result[2],
                                "service": result[3],
                                "discount": result[4],
                                "amount": result[5],
                            },
                            "net": result[1] + result[2] + result[3] - result[4],
                            "difference": result[5]
                            - (result[1] + result[2] + result[3] - result[4]),
                        }
                        groups["summary_lines"].append(detail_group)

            # Add headers
            headers = [
                "Description",
                "Sales",
                "Tax",
                "Service",
                "Discount",
                "Received Amount",
            ]
            for col, header in enumerate(headers):
                sheet.write(4, col, header, format4)

            sheet.set_column(4, 0, 18)
            sheet.set_column(4, 1, 18)
            sheet.set_column(4, 2, 18)
            sheet.set_column(4, 3, 18)
            sheet.set_column(4, 4, 18)
            sheet.set_column(4, 5, 18)
            sheet.set_column(4, 6, 18)
            sheet.set_column(4, 7, 18)
            sheet.set_column(4, 8, 18)
            sheet.set_column(4, 9, 18)
            row = 5
            for group in groups["summary_lines"]:
                for line in group["lines"]:
                    sheet.write(row, 0, line["name"], format3)
                    sheet.write(row, 1, line["trans_price"], currency_format)
                    sheet.write(row, 2, line["tax"], currency_format)
                    sheet.write(row, 3, line["service"], currency_format)
                    sheet.write(row, 4, line["discount"], currency_format)
                    sheet.write(row, 5, line["amount"], currency_format)
                    row += 1
                total_dict = group["total"]
                sheet.write(row, 0, group["group"], format4)
                sheet.write(row, 1, total_dict["price"], currency_format)
                sheet.write(row, 2, total_dict["tax"], currency_format)
                sheet.write(row, 3, total_dict["service"], currency_format)
                sheet.write(row, 4, total_dict["discount"], currency_format)
                sheet.write(row, 5, total_dict["amount"], currency_format)
                row += 1
                sheet.write(row, 0, "Net Amount", format4)
                sheet.write(row, 5, group["net"], currency_format)
                row += 1
                sheet.write(row, 0, " ", format4)
                sheet.write(row, 5, group["difference"], currency_format)
                row += 1

        if data["form"]["report_type"] == "transaction":
            self.env.cr.execute(sql_transaction)
            results = self.env.cr.fetchall()
            if data["form"]["report_type"] == "transaction":
                group = 0
            if data["form"]["report_type"] == "bill":
                group = 11

            if results:
                for result in results:
                    transaction_room_no = ""
                    if result[9]:
                        transaction_room_no = (
                            self.env["hms_room_setup"]
                            .search([("id", "=", result[9])])
                            .name
                        )
                    if result[14]:
                        PaymentType = (
                            self.env["hotel.payment"]
                            .search([("id", "=", result[14])])
                            .name
                        )
                    else:
                        PaymentType = ""
                    moves = {
                        "name": result[0],
                        "trans_price": result[1],
                        "tax": result[2],
                        "service": result[3],
                        "discount": result[4],
                        "amount": result[5],
                        "trans_currency": result[6],
                        "RegNo": result[7],
                        "TransNo": result[8],
                        "RoomNo": transaction_room_no,
                        "Guest": result[10],
                        "BillNo": result[11],
                        "BillDate": result[12],
                        "TransDate": result[13],
                        "PaymentType": PaymentType,
                    }
                    header = {"name": ""}
                    payment_type = {"name": ""}
                    if data["form"]["report_type"] == "transaction":
                        header = {"name": result[group]}
                        payment_type = {"name": ""}
                    if data["form"]["report_type"] == "bill":
                        header = {
                            "name": result[group],
                            "date": result[12],
                            "reg": result[7],
                        }
                    sub_group = {
                        "header": header,
                        "payment_type": payment_type,
                        "sub_lines": [moves],
                    }
                    found_currency = False
                    for item in groups["transaction_lines"]:
                        if item.get("group") == result[6]:
                            found_currency = True
                            break

                    if found_currency == True:
                        found_group = False
                        for line in item["sub_group"]:
                            if line["header"]["name"] == result[group]:
                                found_group = True
                                break
                        if found_group == True:
                            line["sub_lines"].append(moves)
                            item["total"]["price"] += result[1]
                            item["total"]["tax"] += result[2]
                            item["total"]["service"] += result[3]
                            item["total"]["discount"] += result[4]
                            item["total"]["amount"] += result[5]
                            item["net"] += result[1] + result[2] + result[3] - result[4]
                            item["difference"] += result[5] - (
                                result[1] + result[2] + result[3] - result[4]
                            )
                        else:
                            item["sub_group"].append(sub_group)
                            item["total"]["price"] += result[1]
                            item["total"]["tax"] += result[2]
                            item["total"]["service"] += result[3]
                            item["total"]["discount"] += result[4]
                            item["total"]["amount"] += result[5]
                            item["net"] += result[1] + result[2] + result[3] - result[4]
                            item["difference"] += result[5] - (
                                result[1] + result[2] + result[3] - result[4]
                            )

                    else:
                        detail_group = {
                            "group": result[6],
                            "sub_group": [sub_group],
                            "total": {
                                "price": result[1],
                                "tax": result[2],
                                "service": result[3],
                                "discount": result[4],
                                "amount": result[5],
                            },
                            "net": result[1] + result[2] + result[3] - result[4],
                            "difference": result[5]
                            - (result[1] + result[2] + result[3] - result[4]),
                        }
                        groups["transaction_lines"].append(detail_group)

            self.env.cr.execute(sql_transaction2)
            results = self.env.cr.fetchall()
            if data["form"]["report_type"] == "transaction":
                group = 0
            if data["form"]["report_type"] == "bill":
                group = 11
            if results:
                for result in results:
                    transaction_room_no = ""
                    if result[9]:
                        transaction_room_no = self.env["hms_room_setup"].search(
                            [("id", "=", result[9])]
                        )
                    moves = {
                        "name": "Receipt Amount",
                        "trans_price": result[1],
                        "tax": result[2],
                        "service": result[3],
                        "discount": result[4],
                        "amount": result[5],
                        "trans_currency": result[6],
                        "RegNo": result[7],
                        "TransNo": result[8],
                        "RoomNo": transaction_room_no.name,
                        "Guest": result[10],
                        "BillNo": result[11],
                        "BillDate": result[12],
                        "TransDate": result[12],
                        "PaymentType": result[0],
                    }
                    if data["form"]["report_type"] == "transaction":
                        header = {"name": result[group]}
                        payment_type = {"name": result[0]}
                    if data["form"]["report_type"] == "bill":
                        header = {
                            "name": result[group],
                            "date": result[12],
                            "reg": result[7],
                        }
                    sub_group = {
                        "header": header,
                        "payment_type": payment_type,
                        "sub_lines": [moves],
                    }
                    found_currency = False
                    for item in groups["transaction_lines"]:
                        if item.get("group") == result[6]:
                            found_currency = True
                            break

                    if found_currency == True:
                        found_group = False
                        for line in item["sub_group"]:
                            if line["header"]["name"] == result[group]:
                                found_group = True
                                break
                        if found_group == True:
                            line["sub_lines"].append(moves)
                            item["total"]["price"] += result[1]
                            item["total"]["tax"] += result[2]
                            item["total"]["service"] += result[3]
                            item["total"]["discount"] += result[4]
                            item["total"]["amount"] += result[5]
                            item["net"] += result[1] + result[2] + result[3] - result[4]
                            item["difference"] += result[5] - (
                                result[1] + result[2] + result[3] - result[4]
                            )
                        else:
                            item["sub_group"].append(sub_group)
                            item["total"]["price"] += result[1]
                            item["total"]["tax"] += result[2]
                            item["total"]["service"] += result[3]
                            item["total"]["discount"] += result[4]
                            item["total"]["amount"] += result[5]
                            item["net"] += result[1] + result[2] + result[3] - result[4]
                            item["difference"] += result[5] - (
                                result[1] + result[2] + result[3] - result[4]
                            )

                    else:
                        detail_group = {
                            "group": result[6],
                            "sub_group": [sub_group],
                            "total": {
                                "price": result[1],
                                "tax": result[2],
                                "service": result[3],
                                "discount": result[4],
                                "amount": result[5],
                            },
                            "net": result[1] + result[2] + result[3] - result[4],
                            "difference": result[5]
                            - (result[1] + result[2] + result[3] - result[4]),
                        }
                        groups["transaction_lines"].append(detail_group)
            # Add headers
            headers = [
                "Registration No.",
                "Room",
                "Guest",
                "Bill",
                "Bill Date",
                "Trans Date",
                "Payment Type",
                "Sales",
                "Tax",
                "Service",
                "Discount",
                "Received Amount",
            ]
            for col, header in enumerate(headers):
                sheet.write(4, col, header, format4)

            sheet.set_column(4, 0, 18)
            sheet.set_column(4, 1, 18)
            sheet.set_column(4, 2, 18)
            sheet.set_column(4, 3, 18)
            sheet.set_column(4, 4, 18)
            sheet.set_column(4, 5, 18)
            sheet.set_column(4, 6, 18)
            sheet.set_column(4, 7, 18)
            sheet.set_column(4, 8, 18)
            sheet.set_column(4, 9, 18)
            row = 5
            for group in groups["transaction_lines"]:
                for sub_group in group["sub_group"]:
                    if sub_group["payment_type"]["name"]:
                        sheet.write(row, 0, "Received Amount", format3)
                    if not sub_group["payment_type"]["name"]:
                        sheet.write(row, 0, sub_group["header"]["name"], format3)
                    row += 1
                    for line in sub_group["sub_lines"]:
                        sheet.write(row, 0, line["RegNo"], format3)
                        sheet.write(row, 1, line["RoomNo"], format3)
                        sheet.write(row, 2, line["Guest"], format3)
                        sheet.write(row, 3, line["BillNo"], format3)
                        if line["BillDate"]:
                            bd = line["BillDate"].strftime("%Y-%m-%d")
                        if not line["BillDate"]:
                            bd = " "

                        if line["TransDate"]:
                            td = line["TransDate"].strftime("%Y-%m-%d")
                        if not line["TransDate"]:
                            td = " "
                        sheet.write(row, 4, bd, format3)
                        sheet.write(row, 5, td, format3)
                        sheet.write(row, 6, line["PaymentType"], format3)
                        sheet.write(row, 7, line["trans_price"], currency_format)
                        sheet.write(row, 8, line["tax"], currency_format)
                        sheet.write(row, 9, line["service"], currency_format)
                        sheet.write(row, 10, line["discount"], currency_format)
                        sheet.write(row, 11, line["amount"], currency_format)
                        row += 1
                sheet.write(row, 0, group["group"], format4)
                sheet.write(row, 7, group["total"]["price"], currency_format)
                sheet.write(row, 8, group["total"]["tax"], currency_format)
                sheet.write(row, 9, group["total"]["service"], currency_format)
                sheet.write(row, 10, group["total"]["discount"], currency_format)
                sheet.write(row, 11, group["total"]["amount"], currency_format)
                row += 1
                sheet.write(row, 0, "Net Amount", format4)
                sheet.write(row, 11, group["net"], currency_format)
                row += 1
                sheet.write(row, 0, " ", format4)
                sheet.write(row, 11, group["difference"], currency_format)
                row += 1

        # bill report type
        if data["form"]["report_type"] == "bill":
            self.env.cr.execute(sql_transaction)
            results = self.env.cr.fetchall()
            if results:
                for result in results:
                    if result[14]:
                        PaymentType = (
                            self.env["hotel.payment"]
                            .search([("id", "=", result[14])])
                            .name
                        )
                    else:
                        PaymentType = ""
                    moves = {
                        "name": result[0],
                        "trans_price": result[1],
                        "tax": result[2],
                        "service": result[3],
                        "discount": result[4],
                        "amount": result[5],
                        "trans_currency": result[6],
                        "RegNo": result[7],
                        "TransNo": result[8],
                        "RoomNo": result[9],
                        "Guest": result[10],
                        "BillNo": result[11],
                        "BillDate": result[12],
                        "TransDate": result[13],
                        "PaymentType": PaymentType,
                    }
                    found = False

                    for item in groups["bill_lines"]:
                        if item["group"]["name"] == result[11]:
                            found = True
                            break
                    if found == True:
                        item["lines"].append(moves)

                    else:
                        group = {
                            "name": result[11],
                            "date": result[12],
                            "reg_no": result[7],
                        }
                        detail_group = {
                            "group": group,
                            "lines": [moves],
                        }
                        groups["bill_lines"].append(detail_group)
            self.env.cr.execute(sql_transaction2)
            results = self.env.cr.fetchall()
            if results:
                for result in results:
                    moves = {
                        "name": "Receipt Amount",
                        "trans_price": result[1],
                        "tax": result[2],
                        "service": result[3],
                        "discount": result[4],
                        "amount": result[5],
                        "trans_currency": result[6],
                        "RegNo": result[7],
                        "TransNo": result[8],
                        "RoomNo": result[9],
                        "Guest": result[10],
                        "BillNo": result[11],
                        "BillDate": result[12],
                        "TransDate": result[12],
                        "PaymentType": result[0],
                    }
                    found = False

                    for item in groups["bill_lines"]:
                        if item["group"]["name"] == result[11]:
                            found = True
                            break
                    if found == True:
                        item["lines"].append(moves)
                    else:
                        group = {
                            "name": result[11],
                            "date": result[12],
                            "reg_no": result[7],
                        }
                        detail_group = {
                            "group": group,
                            "lines": [moves],
                        }
                        groups["bill_lines"].append(detail_group)

            # Add headers
            headers = [
                "Transaction No.",
                "Room",
                "Guest",
                "Transaction",
                "Date",
                "Payment",
                "Amount",
                "Received Amount",
            ]
            for col, header in enumerate(headers):
                sheet.write(4, col, header, format4)

            sheet.set_column(4, 0, 18)
            sheet.set_column(4, 1, 18)
            sheet.set_column(4, 2, 18)
            sheet.set_column(4, 3, 18)
            sheet.set_column(4, 4, 18)
            sheet.set_column(4, 5, 18)
            sheet.set_column(4, 6, 18)
            sheet.set_column(4, 7, 18)
            sheet.set_column(4, 8, 18)
            sheet.set_column(4, 9, 18)
            row = 5
            for group in groups["bill_lines"]:
                sheet.write(row, 0, "Bill No: " + str(group["group"]["name"]), format3)
                sheet.write(
                    row, 1, "Bill Date: " + str(group["group"]["date"]), format3
                )
                sheet.write(row, 2, "Reg No: " + str(group["group"]["reg_no"]), format3)
                row += 1
                for line in group["lines"]:
                    sheet.write(row, 0, line["TransNo"], format3)
                    sheet.write(row, 1, line["RoomNo"], format3)
                    sheet.write(row, 2, line["Guest"], format3)
                    sheet.write(row, 3, line["name"], format3)
                    sheet.write(row, 4, line["TransDate"].strftime("%Y-%m-%d"), format3)
                    sheet.write(row, 5, line["PaymentType"], format3)
                    sheet.write(row, 6, line["trans_price"], currency_format)
                    sheet.write(row, 7, line["amount"], currency_format)
                    row += 1
