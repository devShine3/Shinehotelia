# -*- coding: utf-8 -*-
from datetime import datetime, date
from datetime import timedelta

from odoo import models, api, _, fields
from odoo.exceptions import UserError
import logging

_logger = logging.getLogger(__name__)


class inforeport(models.AbstractModel):
    _name = "report.hotelia.report_print_info_bill"

    @api.model
    def _get_report_values(self, docids, data=None):
        if data is None or "form" not in data or "reg_ids" not in data["form"]:
            return {}
        reg_ids = self.env["hms.registration"].search(
            [("id", "=", data["form"]["reg_ids"])]
        )
        print_date = fields.Date.today()
        data["form"].update(
            {
                "guest_name": reg_ids.guest_name,
                "agent_name": reg_ids.reg_agent_id.name,
                "arrival_date": reg_ids.arrival_date,
                "departure_date": reg_ids.departure_date,
                "room_no": reg_ids.reg_room_no.name,
                "reg_ids_name": reg_ids.name,
                "print_date": print_date,
            }
        )
        return {
            "data": data["form"],
            "lines": self.get_lines(data.get("form")),
        }

    @api.model
    def get_lines(self, options):
        groups_sample = {
            "summary_lines": [
                {
                    "group": "currency_name",
                    "lines": [],
                    "total": {},
                    "net": 0.0,
                    "difference": 0.0,
                }
            ]
        }
        groups = {
            "summary_lines": [],
        }
        moves = {}
        sql = (
            """  select tl.trans_date,t.name,tl.reference,tl.trans_type,c.name,tl.trans_price,tl.tax,
                            tl.service, tl.discount,reg.name,tl.id,reg.reg_room_no,reg.guest_name
                                 from hms_trans_line tl
                                 join hms_transaction t on tl.trans_lines_id = t.id
                                 Join hms_registration reg on tl.reg_id = reg.id
                                 join res_currency c on tl.trans_currency = c.id
                                                                 where tl.id in (%s)
                     """
            % options["tran_string"]
        )
        _logger.info(f"{sql} --SQL TRANString")
        self.env.cr.execute(sql)
        results = self.env.cr.fetchall()
        if results:
            for result in results:
                moves = {
                    "tdate": result[0],
                    "tname": result[1],
                    "refno": result[2],
                    "transtype": result[3],
                    "ccode": result[4],
                    "tamt": result[5],
                    "samt": result[6],
                    "taxamt": result[7],
                    "discoamt": result[8],
                    "total_amt": result[5] + result[6] + result[7] - result[8],
                }
                found = False
                for item in groups["summary_lines"]:
                    if item.get("group") == result[4]:
                        found = True
                        break

                if found == True:
                    item["lines"].append(moves)
                    item["total"]["tamt"] += result[5]
                    item["total"]["samt"] += result[6]
                    item["total"]["taxamt"] += result[7]
                    item["total"]["discoamt"] += result[8]
                    item["net"] += result[5] + result[6] + result[7] - result[8]
                else:
                    detail_group = {
                        "group": result[4],
                        "lines": [moves],
                        "total": {
                            "tamt": result[5],
                            "samt": result[6],
                            "taxamt": result[7],
                            "discoamt": result[8],
                            "total_amt": result[5] + result[6] + result[7] - result[8],
                        },
                        "net": result[5] + result[6] + result[7] - result[8],
                    }
                    groups["summary_lines"].append(detail_group)
        return groups
