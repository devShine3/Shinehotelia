# -*- coding: utf-8 -*-
from datetime import datetime
from datetime import timedelta

from odoo import models, api, _, fields
from odoo.exceptions import UserError
import logging

_logger = logging.getLogger(__name__)


class inforeport(models.AbstractModel):
    _name = "report.hotelia.report_print_bill"

    @api.model
    def _get_report_values(self, docids, data=None):
        # import pdb; pdb.set_trace()
        # _logger.debug("Data received in _get_report_values: %s", data)
        if not data.get("form"):
            raise UserError(
                _("Form content is missing, this report cannot be printed.")
            )
        return {
            "data": data["form"],
            "lines": self.get_lines(data.get("form")),
        }

    @api.model
    def get_lines(self, options):
        groups = {
            "transaction_lines": [],
            "total_trans": 0.0,
            "total_service": 0.0,
            "total_tax": 0.0,
            "total_discount": 0.0,
            "grand_total_bill": 0.0,
            "payment_lines": [],
            "difference": 0.0,
        }

        bill = self.env["hotel.bill"].search([("id", "=", options["bill_id"])])
        company_obj = self.env.user.sudo().company_id
        for transaction in bill.transaction_lines:
            trans_obj = {
                "tdate": transaction.trans_date,
                "tname": transaction.trans_lines_id.name,
                "refno": transaction.reference,
                "transtype": transaction.trans_type,
                "ccode": transaction.trans_currency.name,
                "tamt": transaction.trans_price,
            }
            groups["transaction_lines"].append(trans_obj)
            groups["total_trans"] += transaction.trans_price
            groups["total_service"] += transaction.service
            groups["total_tax"] += transaction.tax
            groups["total_discount"] += transaction.discount
            groups["grand_total_bill"] += (
                transaction.trans_price
                + transaction.service
                + transaction.tax
                - transaction.discount
            )
        total_pay = 0.0
        base_currency = self.env["res.currency"].search(
            [("hotelia_base_currency", "=", True)], limit=1
        )
        # for payment in bill.payment_lines:
        #     trans_currency = self.env["res.currency"].search(
        #         [("name", "=", payment.currency.name)], limit=1
        #     )
        #     rate = base_currency._get_conversion_rate(
        #         trans_currency, base_currency, company_obj, datetime.now().date()
        #     )
        #     base_amount = payment.amount * rate
        #     payment_obj = {
        #         "payment_code": payment.payment_code.name,
        #         "pay_amount": payment.amount,
        #     }
        #     groups["payment_lines"].append(payment_obj)
        #     total_pay += base_amount
        # groups["difference"] = groups["grand_total_bill"] - total_pay

        # return groups
        for payment in bill.payment_lines:
            trans_currency = self.env["res.currency"].search(
                [("name", "=", payment.currency.name)], limit=1
            )
            if trans_currency:
                rate = base_currency._get_conversion_rate(
                    trans_currency, base_currency, company_obj, datetime.now().date()
                )
                if rate is not None:
                    base_amount = payment.amount * rate
                    payment_obj = {
                        "payment_code": payment.payment_code.name,
                        "pay_amount": payment.amount,
                    }
                    groups["payment_lines"].append(payment_obj)
                    total_pay += base_amount
                else:
                    _logger.warning("Conversion rate not available for currencies: %s to %s",
                                    trans_currency.name, base_currency.name)
            else:
                _logger.warning("Transaction currency not found for payment: %s", payment.currency.name)

        groups["difference"] = groups["grand_total_bill"] - total_pay

        return groups
