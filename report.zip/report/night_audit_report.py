# -*- coding: utf-8 -*-
from datetime import datetime
from datetime import timedelta

from odoo import models, api, _, fields
from odoo.exceptions import UserError
import logging

_logger = logging.getLogger(__name__)


class DPreport(models.AbstractModel):
    _name = "report.hotelia.report_nab"
    _description = "Night Audit Bill Report"

    @api.model
    def _get_report_values(self, docids, data=None):
        print_date = fields.Date.today()
        data["form"].update(
            {
                "report_date": print_date,
            }
        )
        return {
            "data": data["form"],
            "lines": self.get_lines(data.get("form")),
        }

    @api.model
    def get_lines(self, options):
        groups_sample = {
            "na_line": [
                {"group": "currency_name", "lines": [], "net": 0.0, "difference": 0.0}
            ]
        }
        groups = {
            "na_line": [],
        }

        moves = {}
        receipt = {}
        where_clause = ""
        sql = """
            select res.name,res.guest_name,res.departure_date,rs.name,
            sum(tl.trans_price),sum(tl.tax),sum(tl.service), sum(tl.discount) ,c.name
            from hms_registration res
            left join hms_room_setup rs on res.reg_room_no = rs.id
                join hms_trans_line tl on res.id = tl.reg_id
                join res_currency c on tl.trans_currency = c.id
                where  res."Rsv_Type" = 'registration' and res.function_id = '2' and (tl.bill_id IS NULL OR tl.bill_name IS NULL)
                Group by res.name,res.guest_name,res.departure_date,rs.name,c.name
             """
        # if options['date_from']:
        #     where_clause += '''and res.departure_date >= '%s'  ''' % options['date_from']
        # if options['date_to']:
        #     where_clause += '''and res.departure_date <= '%s'  ''' % options['date_to']
        sql_transaction = sql
        self.env.cr.execute(sql_transaction)
        results = self.env.cr.fetchall()
        if results:
            for result in results:
                moves = {
                    "reg_no": result[0],
                    "guest_name": result[1],
                    "departure": result[2],
                    "room_no": result[3],
                    "trans_price": result[4],
                    "tax": result[5],
                    "service": result[6],
                    "discount": result[7],
                    "total_amt": result[4] + result[5] + result[6] - result[7],
                    "trans_currency": result[8],
                }
                found = False
                for item in groups["na_line"]:
                    if item.get("group") == result[8]:
                        found = True
                        break
                if found == True:
                    item["lines"].append(moves)
                    item["net"] += result[4] + result[5] + result[6] - result[7]
                else:
                    detail_group = {
                        "group": result[8],
                        "lines": [moves],
                        "net": result[4] + result[5] + result[6] - result[7],
                    }
                    groups["na_line"].append(detail_group)
        return groups
