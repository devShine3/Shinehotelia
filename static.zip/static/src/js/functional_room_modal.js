odoo.define('hotelia.functional_room_modal', function (require) {
  "use strict";

  var AbstractField = require('web.AbstractField');
  var FieldRegistry = require('web.field_registry');
  var field_utils = require('web.field_utils');
  var view_dialogs = require('web.view_dialogs');

  var core = require('web.core');
  var qweb = core.qweb;

  var WidgetFunctionalRoom = AbstractField.extend({
    template: 'WidgetSearchTemplate',
    events: {
      'click .btn-search': 'btn_search_action',
    },
    init: function () {
      this._super.apply(this, arguments);
    },

    btn_search_action: function () {
      var self = this;

      new view_dialogs.SelectCreateDialog(this, {
        res_model: 'hms.functional.rooms.setup',
        title: "Functional Rooms",
        context: { hasSelectors: false },
        no_create: true,

        on_selected: function (records) {
          var record_ids = records.map(function (item) {
            return item['id'];
          });
          
          self._rpc({
            model: self.attrs.relatedModel,
            method: self.attrs.modifiers.relatedAction,
            args: [record_ids],
          }).then(function (result) {
            self._setValue(result.toString());
          });
        }
      }).open();
    },
    _render: function () {
      var formated_value = field_utils.format[this.formatType](this.value);
      this.$el.html($(qweb.render(this.template, { 'widget': this, 'formated_value': formated_value })));
    },
  });

  FieldRegistry.add('widget_functional_room_modal', WidgetFunctionalRoom);

  return WidgetFunctionalRoom;
});

// Ref: Message Reg Modal js