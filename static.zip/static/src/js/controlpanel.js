odoo.define('hotelia.ControlPanel', function (require) {
    'use strict';
    var ControlPanel = require('web.ControlPanel');
    ControlPanel.include({
        _update_search_view: function(searchview, is_hidden) {
            this._super.apply(this, arguments);
            if(searchview){
                this._rpc({
                        model: 'hotel.reservation',
                        method: 'get_fields_to_ignore_in_search',
                        args: [""]
                }).then(function (result) {
                    for(var i=0;i<result.length;i++){
                        searchview.$buttons.find('option[data-name="' + result[i] + '"]').hide();
                    }
                    })
            }
            },
        });
});