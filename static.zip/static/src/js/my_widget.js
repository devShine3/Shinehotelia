odoo.define('my_module.my_model', function (require) {
  'use strict';

  var ListRenderer = require('web.ListRenderer');

  ListRenderer.include({
    _renderRow: function (record, index) {
      var $row = this._super.apply(this, arguments);
      var fieldName = 'bill_name'; // Replace with the desired field name
      var fieldValue = record.data[fieldName] ? record.data[fieldName].value : null;

      if (record.model ==='hms.trans.line' && fieldValue !== null) {
        $row.find('.o_list_record_remove').hide();
      }

      return $row;
    },
  });
});
