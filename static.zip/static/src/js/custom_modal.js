odoo.define('hotelia.custom_modal', function (require) {
  'use strict';

  var core = require('web.core');
  var Dialog = require('web.Dialog');

  var _t = core._t;

  function openCustomModal(title, message) {
      var dialog = new Dialog(null, {
          title: title,
          size: 'medium',
          $content: $('<div>', {
              html: message,
          }),
          buttons: [
              {
                  text: _t('OK'),
                  classes: 'btn-primary',
                  close: true,
              },
          ],
      });
      dialog.open();
  }

  return {
      openCustomModal: openCustomModal
  };
});
