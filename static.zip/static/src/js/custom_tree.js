odoo.define('hotelia.ListViewWithoutControlPanel', function (require) {
  "use strict";
 
  var viewRegistry = require('web.view_registry')
  // we use **<tree />** view but it's actually extended from list view
  var ListView = require('web.ListView')

  // Extend Renderer Start -------------------------------
  var core = require('web.core');
  var ListRenderer = require('web.ListRenderer');
  var Qweb = core.qweb;

  var MyListRenderer = ListRenderer.extend({
    _render: function(){
      console.log('inside render function');
      var self = this;
      return this._super.apply(this,arguments).then(function (){
        var listHeader = Qweb.render('ListViewWithoutControlPanel', { // render my custom template from src/xml view
            // widget: self,
        });
        self.$el.prepend(listHeader);
      });
    },

  });
  console.log('after first function');
  // Extend Renderer End -------------------------------
 
  // Extend View Start -------------------------------
  var ListViewWithoutControlPanel = ListView.extend({
  // template: 'ListViewWithoutControlPanel',
  config: _.extend({}, ListView.prototype.config, {
    Renderer: MyListRenderer, // Config custom renderer
  }),
  withControlPanel: false, // Remove header control panel

  // can overwrite whatever you want

  });
  // Extend View End -------------------------------
 
  viewRegistry.add('tree_without_control_panel', ListViewWithoutControlPanel) 
  return {
    Renderer: MyListRenderer,
  }
 });


/*  **Usage in Tree View**
    <tree js_class="tree_without_control_panel" >
      --> all your **<field />** here <---
    </tree>
*/

/* **Get Reference from**

***************************************************************************************
| https://stackoverflow.com/questions/64766237/how-to-customize-kanban-viwe-in-odoo14 |
***************************************************************************************

*/
