odoo.define('hotelia.tree_widget', function (require) {
  'use strict';

  var AbstractField = require('web.AbstractField');
  var fieldRegistry = require('web.field_registry');

  var TwoFields = AbstractField.extend({
    _render: function () {
      this.$el.empty();

      var $field_one = $('<span>', {
        text: this.recordData.full_name,
        class: 'mr-2',
      });

      var $field_two = $('<span>', {
        text: `+${this.recordData.total_pax_count - 1}`,
        class: 'badge badge-pill o_field_badge o_field_widget',
      });

      //$field_one.appendTo(this.$el);
      if (this.recordData.full_name) {
        $field_one.appendTo(this.$el);
      }
      if (this.recordData.total_pax_count > 1) {
        $field_two.appendTo(this.$el);
      }
    },
  });

  fieldRegistry.add('two_fields', TwoFields);

  return {
    TwoFields: TwoFields,
  };
});
