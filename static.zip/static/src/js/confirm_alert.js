odoo.define('hotelia.confirm_alert', function (require) {
  'use strict';
  // import odoo original form_controller
  var FormController = require('web.FormController');
  // import odoo original dialog, to show the error message
  var Dialog = require('web.Dialog');
  var view_dialogs = require('web.view_dialogs');
  var rpc = require('web.rpc');
  const core = require('web.core');
  const _t = core._t;
  // let's override it
  FormController.include({
    _onSave: async function (ev) {
      var self = this;
      var room_no, confirm, message, message2;
      function saveAndExecuteAction() {
        ev.stopPropagation(); // Prevent x2m lines to be auto-saved
        self._disableButtons();
        self
          .saveRecord()
          .then((res) => {
            self.displayNotification({
              title: _t('Success'),
              message: _t('Saved Successfully.'),
              type: _t('success'),
            });
          })
          .guardedCatch((res) => {})
          .finally(self._enableButtons.bind(self));
      }
      const record = this.model.get(this.handle, { raw: true });
      console.log(record);

      if (this.modelName == 'hms_room_setup') {
        let resId = record.res_id; // 3
        let newName = record.data.name; // "1020"
        if (!resId) {
          // check condition
          this.roomsArray = await this._rpc({
            model: 'hms_room_setup',
            method: 'name_search',
            args: [''],
            kwargs: {
              args: [['name', '=', newName]],
              limit: 1,
            },
            context: this.getSession().user_context,
          });
          if (this.roomsArray.length > 0) {
            return this.displayNotification({
              title: _t('Error'),
              message: _t('Room no. already exist!!.'),
              type: 'danger',
            });
          }
        }
      }


      if (this.modelName == 'hms.registration') {

        if (record.data.reg_arrival.isAfter(record.data.reg_departure)) {
          return this.displayNotification({
            title: _t('Error'),
            message: _t('Departure date must greater than Arrival date.'),
            type: 'danger',
          });
        }
        var message = 'Do you want to make group check-in?';
        var message2 = ' ';
        if (record.data.guest_name) {
          message2 = `Use Guest (${record.data.guest_name}) for all rooms?`;
        } else {
          message2 = 'Guest Name is invalid.';
        }

        var confirm_string = 'Are you sure want to confirm with ';
        confirm = confirm_string.concat(
          record.data.reg_room_type_name,
          ' ',
          record.data.reg_room_name,
          ' from ',
          new Date(record.data.reg_arrival).toLocaleDateString('en-GB'),
          ' to ',
          new Date(record.data.reg_departure).toLocaleDateString('en-GB'),
          '?'
        );
        var recordId = this.model.get(this.handle, { raw: true }).res_id;

        if (!recordId) {
          if (record.data.master_room) {
            Dialog.confirm(this, message, {
              onForceClose: function () {},
              confirm_callback: function () {
                Dialog.confirm(self, message2, {
                  onForceClose: function () {},

                  confirm_callback: function () {
                    Dialog.confirm(self, confirm, {
                      onForceClose: function () {
                        console.log(
                          'The user closes the dialog forcibly, by clicking on the button with the close icon'
                        );
                      },
                      confirm_callback: function () {
                        console.log('The user clicks on the OK button');
                        saveAndExecuteAction();
                      },
                      cancel_callback: function () {},
                    });
                  },
                  cancel_callback: function () {
                    var changes = { namebind: 'True' };
                    var value = {
                      dataPointID:
                        self.renderer.allFieldWidgets[self.renderer.state.id][0]
                          .dataPointID,
                      viewType: self.renderer.viewType,
                      changes: changes,
                    };
                    self.renderer.allFieldWidgets[
                      self.renderer.state.id
                    ][0].trigger_up('field_changed', value);
                    saveAndExecuteAction();
                  },
                });
              },
              cancel_callback: function () {
                var changes = { gp_checkin: 'True' };
                //                                    var changes = {guest_name : new Date().toString()};
                var value = {
                  dataPointID:
                    self.renderer.allFieldWidgets[self.renderer.state.id][0]
                      .dataPointID,
                  viewType: self.renderer.viewType,
                  changes: changes,
                };
                self.renderer.allFieldWidgets[
                  self.renderer.state.id
                ][0].trigger_up('field_changed', value);
                saveAndExecuteAction();
              },
            });
          } else {
            Dialog.confirm(self, confirm, {
              onForceClose: function () {
                console.log(
                  'The user closes the dialog forcibly, by clicking on the button with the close icon'
                );
              },
              confirm_callback: function () {
                console.log('The user clicks on the OK button');
                saveAndExecuteAction();
              },
              cancel_callback: function () {
                console.log('The user clicks on the Cancel button');
              },
            });
          }
        }
        else {
                console.log('The user clicks on the Cancel button');
          saveAndExecuteAction();
        }
        }

      else if (this.modelName == 'hotel.bill') {
        let resId = record.res_id; // 3
        var message = 'Do you want to make payment?';
            if (!resId) {
                 Dialog.confirm(self, message, {
                  onForceClose: function () {
                    console.log(
                      'The user closes the dialog forcibly, by clicking on the button with the close icon'
                    );
                  },
                  confirm_callback: function () {
                    console.log('The user clicks on the OK button');
                    saveAndExecuteAction();
                  },
                  cancel_callback: function () {
                    console.log('The user clicks on the Cancel button');
                  },
                });
              }
//              else{
//              }
          }
         else {
        saveAndExecuteAction();
      }
    },
  });
});
