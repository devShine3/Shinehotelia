odoo.define('hotelia.dashboard_action', function (require){
    "use strict";
    var AbstractAction = require('web.AbstractAction');
    var core = require('web.core');
    var QWeb = core.qweb;
    var rpc = require('web.rpc');
    var ajax = require('web.ajax');
    var CalendarChart = AbstractAction.extend({
       template:'CalendarChart',
});
    



    core.action_registry.add('calendar_chart_tag', CalendarChart);
    return CalendarChart;
    })