odoo.define('hotelia.widget_guest', function (require) {
"use strict";
    // import the required object to create a widget
    var AbstractField = require('web.AbstractField');
    var FieldRegistry = require('web.field_registry');
    var field_utils = require('web.field_utils');
    var session = require('web.session');
    var Dialog = require('web.Dialog');
    var view_dialogs = require('web.view_dialogs');

    // import qweb to render a view
    var core = require('web.core');
    var qweb = core.qweb;

    // create an object with any name
    // don't forget to extend to the web.AbstractField object or its child
    var WidgetGuest = AbstractField.extend({
        template: 'WidgetSearchTemplate', // fill with the template name that will be rendered by odoo
        events: {
            'click .btn-search': 'btn_search_action', // additional in tutorial part four
        },
        init: function () {
            // the 'init' method is called first
            this._super.apply(this, arguments);

        },

        btn_search_action: function() {
            var self = this;
            self._setValue(String(0));
            var guest_name = $('[name=guest_name]').val();
            new view_dialogs.SelectCreateDialog(this, {
                res_model: 'hotel.guest', // the model name
                title: "Guest", // dialog title, optional
                context: {hasSelectors: false}, // context to remove select box
                no_create: true, // an option to make sure that user can not create a new record, optional
                on_selected: function (records) {
                    var record_ids = records.map(function(item){
                        return item['id'];
                    });
                    self._rpc({
                        model: self.attrs.relatedModel,
                        method: self.attrs.modifiers.relatedAction,
                        args: [record_ids],
                    }).then(function(result){
                        self._setValue(result.toString());
                    });
                }
            }).open();
        },
        _render: function () {
            // re-render the view if the field value is changed
            // format the value to include the thousand separator
            var formated_value = field_utils.format[this.formatType](this.value);
            this.$el.html($(qweb.render(this.template, {'widget': this, 'formated_value': formated_value})));
        },
    });

    FieldRegistry.add('widget_guest', WidgetGuest);
    return WidgetGuest;

});
