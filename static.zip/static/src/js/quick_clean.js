odoo.define('hotelia.quick_clean', function (require){
    "use strict";

    var ajax = require('web.ajax');
    var ListController = require('web.ListController');

    var rpc = require('web.rpc')
    ListController.include({
        renderButtons: function($node) {
            this._super.apply(this, arguments);
            var self = this;
            if (this.$buttons) {
                $(this.$buttons).find('.quick_clean_action').on('click', function() {
                self.do_action({
                    name: "Room Quick Clean",
                    type: "ir.actions.act_window",
                    name: "Quick Clean",
                    res_model: "hms.quick.clean",
                    views: [[false, "form"]],
                    target: "new",
//                    context: {
//                                default_room_no: parseInt($(this).attr("data")),
//                                default_from_date: $(this).attr("date"),
//                                default_name: $(this).attr("resvname"),
//                                default_resv_id: parseInt($(this).attr("resv")),
//
//                            },
                });

//                    rpc.query({
//                        model: 'gl_mapping',
//                        method: 'get_gl_data',
//                        args: [""],
//                    }).then(function(){
//                             self.trigger_up('reload')
//
//                    })
                });
            }
        },
    });
});