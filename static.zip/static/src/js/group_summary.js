odoo.define("hotelia.group_summary", function (require) {
    "use strict";

    var core = require("web.core");
    var registry = require("web.field_registry");
    var basicFields = require("web.basic_fields");
    var FieldText = basicFields.FieldText;
    var QWeb = core.qweb;
    var FormView = require("web.FormView");
    var py = window.py;

    var MyWidget = FieldText.extend({
    events: _.extend({}, FieldText.prototype.events, {
      change: "_onFieldChanged",
    }),
        init: function () {
            this._super.apply(this, arguments);
            this.tagName = "span";
            this.set({
                group_summary: py.eval(this.recordData.group_summary),
            });
            this.set({
                group_summary_ids: py.eval(this.recordData.group_summary_ids),
            });
        },
        start: function () {
            var self = this;
            if (self.setting) {
                return;
            }
            if (!this.get("group_summary") || !this.get("group_summary_ids")) {
                return;
            }
            this.renderElement();
            this.view_loading();
        },
      initialize_field: function () {
      FormView.ReinitializeWidgetMixin.initialize_field.call(this);
      var self = this;
      self.on("change:group_summary", self, self.start);
      self.on("change:group_summary_ids", self, self.start);
    },
        view_loading: function (r) {
            return this.load_form(r);
        },


        load_form: function () {
            var self = this;
        },
        renderElement: function () {
            this._super();
            this.$el.html(
                QWeb.render("GroupSummary", {
                    widget: this,
                })
            );
        },
        _onFieldChanged: function (event) {
            this._super();
            this.lastChangeEvent = event;
            this.set({
                group_summary: py.eval(this.recordData.group_summary),
            });
            this.set({
                group_summary_ids: py.eval(this.recordData.group_summary_ids),
            });
            this.renderElement();
            this.view_loading();
        },
    });

    registry.add("Group_Summary", MyWidget);
    return MyWidget;
});
