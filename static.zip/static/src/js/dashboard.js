odoo.define('hotelia.dashboard_action', function (require) {
  'use strict';

  var AbstractAction = require('web.AbstractAction');
  var core = require('web.core');
  var QWeb = core.qweb;
  var ajax = require('web.ajax');

  var Dashboard = AbstractAction.extend({
    template: 'Dashboard',
    jsLibs: ['https://cdn.jsdelivr.net/npm/chart.js'],

    init: function (parent, context) {
      this._super(parent, context);
      this.dashboards_template = ['Dashboard'];
      this.roomData = [];
      this.roomSummaryData = [];
      this.totalReservationsCount = 0;
      this.earningChartData = {};
      this.totalCheckInsCount = 0;
      this.totalCheckoutsCount = 0;
      this.currentMonth = new Date().getMonth() + 1;
      this.roomStatus = [];
      this.totalReservation_CancelCount = 0;
    },

    willStart: function () {
      const self = this;
      return (
        $.when(ajax.loadLibs(this), this._super())
          // .then(() => self.fetchRoomData())
          // .then(() => self.fetchRoomSummaryData(self.currentMonth))
          .then(() => self.fetch_data(self.currentMonth))
      );
    },

    start: function () {
      var self = this;

      this.set('title', 'Dashboard');
      return this._super().then(function () {
        self.render_line_chart();
        self.render_doughnut_chart();
        self.render_dashboards();
        self.render_4_cards();
        self.$('#dashboard-date-filter').val(self.currentMonth);
        var monthFilter = self.$('#dashboard-date-filter');
        monthFilter.on('change', async function () {
          var selectedMonth = monthFilter.val();
          self.currentMonth = Number(selectedMonth);
          await self.fetch_data(self.currentMonth);
          self.earningChartData = await self.earningChartData;
          await self.update_line_chart(self.earningChartData);
          // await self.update_doughnut_chart(
          //   self.totalCheckInsCount,
          //   self.totalCheckoutsCount
          // );
          self
            .$('.current_month_total')
            .text(self.earningChartData.current_month_total);
          self
            .$('.prev_month_total')
            .text(self.earningChartData.prev_month_total);
          self.$('.total_check_ins').text(self.totalCheckInsCount);
          self
            .$('.total_reservation_count')
            .text(self.totalReservationsCount[0]);
          self
            .$('.total_reservation_cancel_count')
            .text(self.totalReservation_CancelCount);
          self
            .$('.total_income')
            .text(self.earningChartData.current_month_total);
          // progress bar
          self.render_4_cards();
          // percent text
        });
      });
    },

    render_line_chart: function () {
      var self = this;
      var ctx = self.$('#earning_line_chart');
      var chartOptions = {
        plugins: {
          legend: {
            display: false,
            position: 'top',
            align: 'start',
            labels: {
              color: 'rgb(255, 99, 132)',
            },
          },
        },
        maintainAspectRatio: false,
        scales: {
          x: {
            ticks: {
              align: 'inner',
            },
          },
          y: {
            suggestedMin: 0,
            ticks: {
              maxTicksLimit: 5,
              callback: function (value, index, values) {
                if (value >= 100000) {
                  return value / 100000 + 'Lakh';
                }
                return value;
              },
              stepSize: 10,
            },
          },
        },
      };
      self.lineChart = new Chart(ctx, {
        type: 'line',
        options: chartOptions,
        data: {
          labels: ['First Week', 'Second Week', 'Third Week', 'Fourth Week'],
          datasets: [
            {
              label: 'Current Month',
              data: self.earningChartData.total_income.current_month,
              backgroundColor: '#4579EE85',
              borderColor: '#4579EE',
              borderWidth: 1,
              pointBackgroundColor: '#4579EE85',
              pointStyle: 'circle',
              pointRadius: 10,
              pointHoverRadius: 15,
            },
            {
              label: 'Previous Month',
              data: self.earningChartData.total_income.prev_month,
              backgroundColor: '#ADB5BD85',
              borderColor: '#ADB5BD',
              borderWidth: 1,
              borderDash: [5, 5],
              pointBackgroundColor: '#ADB5BD85',
              pointStyle: 'circle',
              pointRadius: 10,
              pointHoverRadius: 15,
            },
          ],
        },
      });
    },

    update_line_chart: function (earningChartData) {
      var self = this;
      self.lineChart.data.datasets[0].data =
        earningChartData.total_income.current_month;
      self.lineChart.data.datasets[1].data =
        earningChartData.total_income.prev_month;
      self.lineChart.update();
    },

    render_doughnut_chart: function () {
      var self = this;
      var ctx = self.$('#reservation_status_doughnut_chart');
      const plugin = {
        id: 'emptyDoughnut',
        afterDraw(chart, args, options) {
          const { datasets } = chart.data;
          const { color, width, radiusDecrease } = options;
          let hasData = false;

          for (let i = 0; i < datasets.length; i += 1) {
            const dataset = datasets[i];
            hasData |= JSON.stringify(dataset.data) !== JSON.stringify([0, 0]);
          }

          if (!hasData) {
            const {
              chartArea: { left, top, right, bottom },
              ctx,
            } = chart;
            const centerX = (left + right) / 2;
            const centerY = (top + bottom) / 2;
            const r = Math.min(right - left, bottom - top) / 2;

            ctx.beginPath();
            ctx.lineWidth = width || 2;
            ctx.strokeStyle = color || 'rgba(255, 128, 0, 0.5)';
            ctx.arc(centerX, centerY, r - radiusDecrease || 0, 0, 2 * Math.PI);
            ctx.stroke();
          }
        },
      };
      var chartOptions = {
        plugins: {
          emptyDoughnut: {
            color: '#4579EE85',
            width: 2,
            radiusDecrease: 20,
          },
          legend: {
            display: true,
            position: 'bottom',
            align: 'center',
            labels: {
              pointStyle: 'rect',
              boxWidth: 16,
              boxHeight: 16,
            },
          },
        },
        maintainAspectRatio: false,
      };
      self.doughnutChart = new Chart(ctx, {
        type: 'doughnut',
        options: chartOptions,

        data: {
          labels: ['Check Ins', 'Check Outs'],
          datasets: [
            {
              data: [self.today_checkin_count, self.today_checkout_count],
              backgroundColor: ['#4579EE', '#DEE2E6'],
            },
          ],
        },
        plugins: [plugin],
      });
    },

    update_doughnut_chart: function (
      today_checkin_count,
      today_checkout_count
    ) {
      var self = this;
      self.doughnutChart.data.datasets[0].data = [
        today_checkin_count,
        today_checkout_count,
      ];
      self.doughnutChart.update();
    },

    async fetch_data(month = this.currentMonth) {
      await Promise.all([
        this.fetchTotalReservationsCount(month),
        this.fetchTotalReservation_CancelCount(month),
        this.fetchEarningChartData(month),
        this.fetchTotalRegistrationsCount(month),
        this.fetchTotalCheckoutCount(month),
        this.fetchAvaliableTableData(month),
        this.fetchChart__DoughnutData(),
      ]);
      this.cancel_percentage = (
        this.totalReservation_CancelCount * 100 > 0
          ? (this.totalReservation_CancelCount * 100) /
              this.totalReservationsCount[0]
          : 0
      ).toFixed(2);;

      this.check_in_percentage = (
        this.totalCheckInsCount * 100 > 0
          ? (this.totalCheckInsCount * 100) / this.totalReservationsCount[0]
          : 0
      ).toFixed(2);;

      this.reservation_percentage = (
        this.totalReservationsCount[0] * 100 > 0 ? (this.totalReservationsCount[0] * 100) / (this.avaliableTableData.total_rooms *
                new Date(new Date().getFullYear(), month + 1, 0).getDate())
          : 0
      ).toFixed(2);
    },

    async fetchTotalReservationsCount(month) {
      this.totalReservationsCount = await this._rpc({
        model: 'hotel.dashboard',
        method: 'total_reservation',
        args: [''],
        kwargs: { current_month: month },
        context: this.getSession().user_context,
      });
    },

    async fetchAvaliableTableData(month) {
      this.avaliableTableData = await this._rpc({
        model: 'hotel.dashboard',
        method: 'avaliable_table__body',
        args: [''],
        kwargs: { current_month: month },
        context: this.getSession().user_context,
      });
      console.log(this.avaliableTableData, 'this.avaliableTableData');
    },

    async fetchTotalReservation_CancelCount(month) {
      this.totalReservation_CancelCount = await this._rpc({
        model: 'hotel.dashboard',
        method: 'total_cancel',
        args: [''],
        kwargs: { current_month: month },
        context: this.getSession().user_context,
      });
    },

    async fetchEarningChartData(month) {
      this.earningChartData = await this._rpc({
        model: 'hotel.payment.line',
        method: 'total_income',
        args: [''],
        kwargs: { current_month: month },
        context: this.getSession().user_context,
      });
      this.earningChartData.current_month_total = new Intl.NumberFormat(
        'en-US',
        {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        }
      ).format(
        this.earningChartData.total_income.current_month.reduce(
          (sum, cur) => sum + cur,
          0
        )
      );
      this.earningChartData.prev_month_total = new Intl.NumberFormat('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      }).format(
        this.earningChartData.total_income.prev_month.reduce(
          (sum, cur) => sum + cur,
          0
        )
      );
    },

    async fetchTotalRegistrationsCount(month) {
      this.totalCheckInsCount = await this._rpc({
        model: 'hms.registration',
        method: 'total_registration',
        args: [''],
        kwargs: { current_month: month },
        context: this.getSession().user_context,
      });
    },

    async fetchTotalCheckoutCount(month) {
      this.totalCheckoutsCount = await this._rpc({
        model: 'hms.registration',
        method: 'total_checkout',
        args: [''],
        kwargs: { current_month: month },
        context: this.getSession().user_context,
      });
    },

    async fetchChart__DoughnutData() {
      this.chart__DoughnutData = await this._rpc({
        model: 'hotel.dashboard',
        method: 'chart__doughnut_data',
        args: [''],
        kwargs: {},
        context: this.getSession().user_context,
      });
      [this.today_checkin_count, this.today_checkout_count] =
        this.chart__DoughnutData;
      console.log(
        this.today_checkin_count,
        this.today_checkout_count,
        'fetchChart__DoughnutData'
      );
    },

    render_4_cards: async function () {
      var self = await this;
      self.$('.text__reservation-percent').text(self.reservation_percentage);
      self.$('.text__cancel-percent').text(self.cancel_percentage);
      self.$('.text__checkin-percent').text(self.check_in_percentage);
      self
        .$('progress.total__reservation-percentage')
        .val(self.reservation_percentage);
      self.$('progress.total__cancel-percentage').val(self.cancel_percentage);
      self
        .$('progress.total__check-in-percentage')
        .val(self.check_in_percentage);
    },

    render_dashboards: function () {
      var self = this;
      _.each(this.dashboards_templates, function (template) {
        QWeb.render(template, { widget: self });
      });
    },
  });

  core.action_registry.add('dashboard_tag', Dashboard);
  return Dashboard;
});
