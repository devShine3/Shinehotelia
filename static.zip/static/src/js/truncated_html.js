odoo.define('hotelia.truncate_html_widget', function (require) {
  "use strict";

  var field_registry = require('web.field_registry');
  var AbstractField = require('web.AbstractField');

  var TruncateHtmlField = AbstractField.extend({
      _render: function () {
          var content = this.value;
          var maxLength = this.nodeOptions.length || 15;
          if (content && content.length > maxLength) {
              content = content.substr(0, maxLength) + '...';
              this.$el.attr('title', this.value);
          }
          this.$el.html(content);
      },
  });

  field_registry.add('truncate_html', TruncateHtmlField);

  return {
      TruncateHtmlField: TruncateHtmlField,
  };
});
