odoo.define("hotelia.tree_view_gutton", function (require) {
    "use strict";

    var ListRenderer = require("web.ListRenderer");
    var rpc = require('web.rpc');
    ListRenderer.include({
    init: function (parent, state, params) {
        this._super(parent, state, params);
        if ('hasSelectors' in state.context && !state.context.hasSelectors)
            this.hasSelectors = false;
    },

//        _renderRow: function (record) {
//            let row = this._super(record);
//            var self = this;
//            if (record.model == "hotel.guest" && record.context["default_id"]) {
//                row.addClass('o_list_no_open');
//                // add click event
//                row.bind({
//                    click: function (ev) {
//                        ev.preventDefault();
//                        ev.stopPropagation();
//                        rpc.query({
//                        model: 'hotel.reservation',
//                        method: 'overwrite_name',
//                        args: [record.context["default_id"],{"name": record.data.name}],
//                    }).then(function(){
//                        self.do_action({
//                            type: "ir.actions.act_window",
//                            res_model: "hotel.reservation",
//                            res_id: record.context["default_id"],
//                            views: [[false, "form"]],
//                            flags: {mode: 'edit'},
//                        });
//                    })
//
//
//
//                    }
//                });
//            }
//            return row
//        },
    });
});