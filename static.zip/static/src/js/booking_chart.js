odoo.define("hotelia.booking_chart", function (require) {
  "use strict";

  var core = require("web.core");
  var registry = require("web.field_registry");
  var basicFields = require("web.basic_fields");
  var FieldText = basicFields.FieldText;
  var QWeb = core.qweb;
  var FormView = require("web.FormView");
  var py = window.py;
  var Dialog = require("web.Dialog");
  var dialogs = require("web.view_dialogs");
  var MyWidget = FieldText.extend({
    events: _.extend({}, FieldText.prototype.events, {
      change: "_onFieldChanged",
    }),
    init: function () {
      this._super.apply(this, arguments);
      if (this.mode === "edit") {
        this.tagName = "span";
      }
      this.set({
        date_to: false,
        date_from: false,
        summary_header: false,
        room_summary: false,
      });
      this.set({
        summary_header: py.eval(this.recordData.summary_header),
      });
      this.set({
        room_summary: py.eval(this.recordData.room_summary),
      });
    },
    start: function () {
      var self = this;
      if (self.setting) {
        return;
      }
      if (!this.get("summary_header") || !this.get("room_summary")) {
        return;
      }
      this.renderElement();
      this.view_loading();
    },
    initialize_field: function () {
      FormView.ReinitializeWidgetMixin.initialize_field.call(this);
      var self = this;
      self.on("change:summary_header", self, self.start);
      self.on("change:room_summary", self, self.start);
    },
    view_loading: function (r) {
      return this.load_form(r);
    },

    load_form: function () {
      var self = this;
      var selected = [];
      var selected_rooms = [];
      var date_from,
        date_to,
        room_from,
        room_to,
        room_type,
        isMouseDown = false,
        rightClick = false;
      var $selected = $(".table-area-selected");

      var $cells = $("table").find(".table-free");
      var colSpan = $selected.attr("col");
      var $currentCell = $($cells[0]);
      var cellWidth = $currentCell.outerWidth();

      $selected.css("width", cellWidth * colSpan);
      this.$el.find(".table-area-selected").bind("click", function () {
        self.do_action({
          name: "Reservation",
          type: "ir.actions.act_window",
          name: "Reservation",
          res_model: "hotel.reservation.popup",
          views: [[false, "form"]],
          target: "new",
          context: {
            default_room_no: parseInt($(this).attr("data")),
            default_from_date: $(this).attr("date"),
            default_name: $(this).attr("resvname"),
            default_resv_id: parseInt($(this).attr("resv")),
            booking_chart: "booking_chart",
          },
        });
      });
      this.$el
        .find(".table_free")
        .mousedown(function (e) {
          selected_rooms = [];
          rightClick = true;
          console.log(e);
          if (e.which != 3) {
            isMouseDown = true;
            rightClick = false;
            this.style.backgroundColor = "blue";
            selected.push(this);
            date_from = $(this).attr("date");
            room_from = $(this).attr("data");
            selected_rooms.push(room_from);
          }
        })
        .mousemove(function () {
          if (isMouseDown) {
            this.style.backgroundColor = "blue";
            selected.push(this);
            if (!selected_rooms.includes($(this).attr("data"))) {
              selected_rooms.push($(this).attr("data"));
            }
          }
        })
        .mouseup(function () {
          for (const selectdays of selected) {
            if ($(selectdays).attr("weekend") === "true") {
              selectdays.style.backgroundColor = "#ffafaf99";
            }
            if ($(selectdays).attr("weekend") === "false") {
              selectdays.style.backgroundColor = "white";
            }
          }
          if (!rightClick) {
            isMouseDown = false;
            date_to = $(this).attr("date");
            room_to = $(this).attr("data");
            room_type = $(this).attr("roomtype");
            var d1 = new Date(date_from);
            var d2 = new Date(date_to);
            if (selected_rooms.length != 1) {
              Dialog.alert(this, "Improper behavior!!", {
                onForceClose: function () {
                  console.log("Click Close");
                },
                confirm_callback: function () {
                  console.log("Click Ok");
                },
              });
            }
            else if (d1 >= d2) {
              Dialog.alert(
                this,
                "Departure Date must be greater than Arrival Date",
                {
                  onForceClose: function () {
                    console.log("Click Close");
                  },
                  confirm_callback: function () {
                    console.log("Click Ok");
                  },
                }
              );
            }
            else {
              self.do_action({
                type: "ir.actions.act_window",
                name: "Reservation",
                res_model: "hotel.reservation",
                views: [[false, "form"]],
                target: "new",
                context: {
                  default_room_no: parseInt(room_no),
                  default_room_type: parseInt(room_type),
                  default_arrival: date_from,
                  default_departure: date_to,
                  default_form_type: "reservation",
                  booking_chart: "booking_chart",
                },
              });
            }
            // alert("date from and date to must not equal.")
          }
          rightClick = true;
        });
    },
    renderElement: function () {
      this._super();
      this.$el.html(
        QWeb.render("BookingChart", {
          widget: this,
        })
      );
    },
    _onFieldChanged: function (event) {
      this._super();
      this.lastChangeEvent = event;
      this.set({
        summary_header: py.eval(this.recordData.summary_header),
      });
      this.set({
        room_summary: py.eval(this.recordData.room_summary),
      });
      this.renderElement();
      this.view_loading();
    },
  });

  registry.add("Booking_Chart", MyWidget);
  return MyWidget;
});
