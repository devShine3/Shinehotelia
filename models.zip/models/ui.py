from odoo import api, fields, models


class Reservation(models.Model):
    _inherit = "hotel.reservation"
    start_date = fields.Date(String="Stare Date")
    end_date = fields.Date

    @api.model
    def get_listreservation_data(self):
        rev_list = self.env["hotel.reservation"].search([])
        return {
            "reservation_list": len(rev_list),
        }
