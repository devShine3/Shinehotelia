from odoo import api, fields, models


class RoomStatus(models.Model):
    _name = "hmslite.room.status"
    _description = "hmslite room status"

    name = fields.Char(string="Room No.", search=True)
    room_key = fields.Integer("Room ID")
    room_type = fields.Many2one(
        "hms.room.type", string="Room Type", ondelete="set null"
    )
    from_date = fields.Date(string="From Date")
    to_date = fields.Date(string="To Date")
    status = fields.Selection(
        [
            ("v_clean", "Vacant Clean"),
            ("v_dirty", "Vacant Dirty"),
            ("o_clean", "Occupied Clean"),
            ("o_dirty", "Occupied Dirty"),
            ("oos", "Out of Service"),
            ("ooo", "Out of Order"),
        ],
        string="Status",
        tracking=True,
        translate=True,
    )
    status_after_return = fields.Selection(
        [
            ("v_clean", "Vacant Clean"),
            ("v_dirty", "Vacant Dirty"),
            ("o_clean", "Occupied Clean"),
            ("o_dirty", "Occupied Dirty"),
            ("oos", "Out of Service"),
            ("ooo", "Out of Order"),
        ],
        string="Status After Return",
        default="v_clean",
        tracking=True,
        translate=True,
    )

    reason = fields.Char(string="Reason")

    @api.onchange("room_key")
    def _onchange_room_name(self):
        for rec in self:
            if rec.room_key:
                room_data = self.env["hms_room_setup"].search(
                    [("id", "=", rec.room_key)], order="id desc", limit=1
                )
                if room_data:
                    rec.name = room_data.name
                    rec.room_type = room_data.room_type
                    rec.status = room_data.room_status

    @api.onchange("status")
    def _onchange_status(self):
        for rec in self:
            if rec.room_key:
                room_data = self.env["hms_room_setup"].search(
                    [("id", "=", rec.room_key)], order="id desc", limit=1
                )
                if room_data:
                    room_data.write({"room_status": rec.status})

    # @api.model
    # def create(self, vals):
    #     roomstatus = super(RoomStatus, self).create(vals)
    #     room_data = self.env["hms_room_setup"].search([("id", "=", roomstatus.room_key)],order="id desc", limit=1)
    #     if room_data:
    #         room_data.write({"room_status": roomstatus.status})
    # def write(self, vals):
    #     if "room_key" in vals:
    #         room_key = vals["room_key"]
    #     roomstatus = super(RoomStatus, self).write(vals)
    #     room_data = self.env["hms_room_setup"].search([("id", "=", roomstatus.room_key)],order="id desc", limit=1)
    #     if room_data:
    #         room_data.write({"room_status": roomstatus.status})
