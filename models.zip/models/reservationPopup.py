from odoo import api, fields, models, _
import re


class ResvPopup(models.Model):
    _name = "hotel.reservation.popup"
    _description = "Reservation"
    name = fields.Char("Rsv No.")
    room_no = fields.Many2one("hms_room_setup", string="Room No.")
    from_date = fields.Datetime("From Date")
    to_date = fields.Datetime("To Date")
    resv_id = fields.Integer("Resv_Id")
    rate = fields.Float("Currency Rate")
    adult = fields.Char("Adult")
    child = fields.Char("Child")
    room_amount = fields.Float("Room Amount")
    guest_name = fields.Char("Guest Name")
    nric = fields.Char("Nric")
    group_id = fields.Char(string="Group")
    agent_id = fields.Many2one("hmslite.agentsetup", "Agent")
    reg_id = fields.Many2one("hms.registration", "Agent")
    special_request = fields.Char("Special Request")
    email = fields.Char("Email")
    phone = fields.Char("Phone No.")
    nationality = fields.Many2one("hms.national", string="Nationality")
    # rsv_type = fields.Selection(
    #     [
    #         ("open", "Open"),
    #         ("confirmed", "Confirmed"),
    #         ("waitlist", "Waitlist"),
    #         ("registration", "Registered"),
    #         ("check_out", "Check Out"),
    #         ("cancel", "Cancel"),
    #         ("transfer", "Room Transferred"),
    #     ], compute="_compute_rsv_type"
    # )

    # @api.depends("reg_id")
    # def _compute_rsv_type(self):
    #     for rec in self:
    #         rec.rsv_type = rec.reg_id.Rsv_Type

    @api.model
    def default_get(self, fields):
        res = super(ResvPopup, self).default_get(fields)
        if self._context["default_resv_id"]:
            regsv_no = self.env["hotel.reservation"].search(
                [("id", "=", self._context["default_resv_id"])]
            )
            reg = self.env["hms.registration"].search(
                [("reservation_id", "=", self._context["default_resv_id"])], limit=1
            )
            if reg:
                res["reg_id"] = reg.id
            res["from_date"] = regsv_no.arrival
            res["room_no"] = regsv_no.room_no.id
            res["name"] = regsv_no.name
            res["to_date"] = regsv_no.departure
            res["guest_name"] = regsv_no.guest_name
            res["adult"] = regsv_no.adult
            res["email"] = regsv_no.email
            res["phone"] = regsv_no.phone
            res["special_request"] = (
                re.sub("<[^<]+?>", "\n", regsv_no.special_request)
                if regsv_no.special_request
                else ""
            )
            res["child"] = regsv_no.child
            res["nric"] = regsv_no.nric
            res["room_amount"] = regsv_no.amount
            res["group_id"] = regsv_no.group_id
            res["agent_id"] = regsv_no.agent_id.id
            res["nationality"] = regsv_no.national.id

        return res

    def show_reservation(self):
        reg = self.env["hms.registration"].search(
            [("reservation_id", "=", self.resv_id)]
        )
        if reg:
            return {
                "name": "Reservations",
                "type": "ir.actions.act_window",
                "view_type": "form",
                "view_mode": "form",
                "res_model": "hms.registration",
                "target": "self",
                "context": "booking_chart",
                # 'view_id': self.env.ref('hotelia.view_hmslite_hotel_reservation_form').id,
                "res_id": reg.id,
            }
        else:
            return {
                "name": "Reservations",
                "type": "ir.actions.act_window",
                "view_type": "form",
                "view_mode": "form",
                "res_model": "hotel.reservation",
                "target": "self",
                "context": "booking_chart",
                # 'view_id': self.env.ref('hotelia.view_hmslite_hotel_reservation_form').id,
                "res_id": self.resv_id,
            }

    def go_check_in(self):
        guest_info_list = []
        regsv_no = self.env["hotel.reservation"].search([("id", "=", self.resv_id)])
        for g_data in regsv_no.guest_ids:
            guest_info = (
                0,
                0,
                {
                    "name": g_data.name,
                    "nationality": g_data.nationality.id,
                    "nrc": g_data.nrc,
                    "passport_no": g_data.passport_no,
                    "email": g_data.email,
                    "phone": g_data.phone,
                },
            )
            guest_info_list.append(guest_info)
        return {
            "name": _("Registration"),
            "type": "ir.actions.act_window",
            "view_type": "form",
            "view_mode": "form",
            "target": "self",
            "context": "booking_chart",
            "res_model": "hms.registration",
            "context": {
                "default_reg_amount": regsv_no.amount,
                "default_reg_departure": regsv_no.departure,
                "default_reg_room_rate": regsv_no.room_rate,
                "default_reg_room_type": regsv_no.room_type.id,
                "default_reg_room_no": regsv_no.room_no.id,
                "default_reg_amount": regsv_no.amount,
                "default_reg_currency": regsv_no.currency.id,
                "default_reg_extra_bed": regsv_no.extra_bed,
                "default_reg_breakfast": regsv_no.breakfast,
                "default_reg_adult": regsv_no.adult,
                "default_reg_child": regsv_no.child,
                "default_reg_group_id": regsv_no.group_id,
                "default_reg_agent_id": regsv_no.agent_id.id,
                "default_reg_company_id": regsv_no.company_id.id,
                "default_group_key": regsv_no.group_key,
                "default_reg_group_flag": regsv_no.group_flag,
                "default_Rsv_Type": "registration",
                "default_guest_name": regsv_no.guest_name,
                "default_title": regsv_no.title.id,
                "default_phone": regsv_no.phone,
                "default_email": regsv_no.email,
                "default_nric": regsv_no.nric,
                "default_passport_no": regsv_no.passport_no,
                "default_national": regsv_no.national.id,
                "default-contact_person": regsv_no.contact_person,
                "default_phone": regsv_no.phone,
                "default_guest_key": regsv_no.guest_key,
                "default_deposit": regsv_no.deposit,
                "default_payment_status": regsv_no.payment_status,
                "default_payment_ref": regsv_no.payment_ref,
                "default_remark": regsv_no.remark,
                "default_special_request": regsv_no.special_request,
                "default_reservation_id": regsv_no.id,
                "default_guest_ids": guest_info_list,
            },
        }


class RegPopup(models.Model):
    _name = "hotel.registration.popup"
    _description = "Registration"
    name = fields.Char("Reg No.")
    room_no = fields.Many2one("hms_room_setup", string="Room No.")
    from_date = fields.Date("From Date")
    to_date = fields.Date("To Date")
    resv_id = fields.Integer("Resv_Id")
    rate = fields.Float("Currency Rate")
    adult = fields.Char("Adult")
    guest_name = fields.Char("Guest Name")
    group_id = fields.Char(string="Group")
    agent_id = fields.Many2one("hmslite.agentsetup", "Agent")
    reg_id = fields.Many2one("hms.registration", "Agent")

    @api.model
    def default_get(self, fields):
        res = super(ResvPopup, self).default_get(fields)
        if self._context["default_resv_id"]:
            regsv_no = self.env["hms.registration"].search(
                [("id", "=", self._context["default_resv_id"])]
            )
            # reg = self.env['hms.registration'].search([('reservation_id', '=', self._context["default_resv_id"])],limit = 1)
            # if reg:
            #     res['reg_id'] = reg.id
            res["from_date"] = regsv_no.arrival
            res["room_no"] = regsv_no.room_no.id
            res["name"] = regsv_no.name
            res["to_date"] = regsv_no.departure
            res["guest_name"] = regsv_no.guest_name
            res["adult"] = regsv_no.adult
            res["group_id"] = regsv_no.group_id
            res["agent_id"] = regsv_no.agent_id.id

        return res
