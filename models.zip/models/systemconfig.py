# -*- coding: utf-8 -*-
import requests
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class SystemConfig(models.Model):
    _name = "hotelia_system_config"
    _description = "System Config"

    name = fields.Char(string="Name")
    auto_post = fields.Boolean(string="Auto Post")
    by_guest = fields.Boolean(string="By Guest")
    by_hotel = fields.Boolean(string="By Hotel")
    hoteliaMMK = fields.Many2one(
        "res.partner", String="Hotelia MMK", ondelete="cascade", index=True
    )
    hoteliaUSD = fields.Many2one(
        "res.partner", String="Hotelia USD", ondelete="cascade", index=True
    )
