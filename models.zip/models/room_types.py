from odoo import http
from odoo.http import request
import string
from tokenize import String
from urllib import request
from odoo import api, fields, models
from odoo.exceptions import ValidationError
from odoo.osv import expression


class RoomTypes(models.Model):
    _name = "hms.room.type"
    _description = "hotel room types"
    _order = "id DESC"
    category = fields.Char(String="Room Type")
    name = fields.Char(String="Room Name")
    date = fields.Date(String="Date")
    function = fields.Boolean("Function Room Type")
