from odoo import api, models, fields
from odoo.tools import html_escape

product_category_id = None

class Product(models.Model):
    _name = "hotel.product"
    # _inherit = "product.template"

    product = fields.Many2one("product.product", string="Name", domain="[('categ_id','=',product_category_key)]")
    default_code = fields.Char(string="Code")
    description = fields.Html(string="Description")
    list_price = fields.Float(string="Price")
    quantity = fields.Integer(string="Quantity", default=1)
    amount = fields.Float(string="Amount")
    service = fields.Float(string="Service", default=0.00)
    tax = fields.Float(string="Tax", default=0.00)
    net_amount = fields.Float(string="Net Amount")
    product_category_key = fields.Integer(string="Product Category", compute="_compute_product_category")

    minibar_transaction = fields.Many2one(
        "hotel.minibar_transaction", string="Minibar Transaction"
    )
    transaction_line = fields.Many2one("hms.trans.line", string="Transaction Line")

    @api.onchange("product")
    def _on_change_product(self):
        for record in self:
            if record.product:
                record.default_code = record.product.default_code
                record.description = record.product.description
                record.list_price = record.product.list_price

    @api.onchange("list_price", "quantity", "service", "tax")
    def _on_change_list_price(self):
        for record in self:
            if record.list_price:
                record.net_amount = (
                    record.list_price * record.quantity
                ) + record.service
                record.amount = record.net_amount + record.tax

    @api.onchange("minibar_transaction")
    def unlink(self):
        for record in self:
            product_id = record.product.id
            booking_key = record.minibar_transaction.booking_key

            transaction_to_remove = self.env["hms.transaction"].search(
                [("product_id", "=", product_id)]
            )

            if transaction_to_remove:
                transaction_id = transaction_to_remove.id

                line_to_remove = self.env["hms.trans.line"].search(
                    [
                        ("trans_lines_id", "=", transaction_id),
                        ("reg_id", "=", booking_key),
                    ]
                )
                if line_to_remove:
                    line_to_remove.unlink()

            hotel_product_obj = super(Product, self).unlink()

    def _compute_product_category(self):
        global product_category_id
        product_category_id = self.env['ir.config_parameter'].get_param("minibar_product_category", default=False)
        product_category_id = int(product_category_id)
        self.product_category_key = product_category_id