from odoo import api, fields, models, _
from datetime import datetime, timedelta, date
from datetime import datetime, timedelta, time


class CancelTransaction(models.TransientModel):
    _name = "cancel.transaction"
    _description = "colors setup"
    _order = "id DESC"
    message = fields.Char()

    resv_id = fields.Many2one("hotel.reservation")

    # bread crumbs
    def action_ok(self):
        if self.resv_id:
            transaction = self.env["hms.transaction"].search(
                [("name", "ilike", "cancel")], limit=1
            )

            return {
                "name": _("Cancellation Fee"),
                "type": "ir.actions.act_window",
                "view_mode": "form",
                "res_model": "hms.trans.line",
                # pass the id
                "target": "new",
                "context": {
                    "default_resv_id": self.resv_id.id,
                    "default_trans_lines_id": transaction.id,
                    "default_trans_currency": self.resv_id.currency.id,
                },
            }

    def action_cancel(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=1)
        reservation = self.env["hotel.reservation"].search(
            [("id", "=", self.resv_id.id)]
        )
        reservation.write(
            {
                "Rsv_Type": "cancel",
                "departure": new_date,
                "departure_date": fields.Date.today(),
            }
        )
        return {
            "name": _("Cancelled"),
            "type": "ir.actions.act_window",
            "view_mode": "form",
            "res_model": "hotel.reservation",
            # pass the id
            "res_id": reservation.id,
            "target": "main",
        }
