from odoo import api, fields, models
from odoo.exceptions import ValidationError


class RoomNational(models.Model):
    _name = "hms.national"
    _description = "hotel room types"
    name = fields.Char(String="Country")
