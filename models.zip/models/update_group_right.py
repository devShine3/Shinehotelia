# Import necessary modules
from odoo import api, models


class UpdateGroupReadonly(models.AbstractModel):
    _name = "update.group.readonly"

    # @api.model
    # def update_group_readonly(self):
    #     user = self.env['res.users'].has_group('hotelia.group_hms_billing_master')
    #     if user:
    #         trans_lines = self.env['hms.trans.line'].search([])
    #         trans_lines.write({'group_readonly': True})
    #     else:
    #         trans_lines = self.env['hms.trans.line'].search([])
    #         trans_lines.write({'group_readonly': False})
