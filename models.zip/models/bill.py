from lxml import etree
from datetime import date, datetime, timedelta
from odoo import api, fields, models, _
from odoo.exceptions import (
    AccessError,
    UserError,
    RedirectWarning,
    ValidationError,
    Warning,
)
import logging

_logger = logging.getLogger(__name__)


class Bill(models.Model):
    _name = "hotel.bill"
    _description = "Hotelia Bill"

    # def _today_date(self):
    #     # current_date = datetime.now()
    #     new_date = fields.Date.today()
    #     return new_date

    def _today_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(hours=6, minutes=30, days=0)
        return new_date

    name = fields.Char(
        "Bill No.", copy=False, readonly=True, default=lambda self: _("TBA")
    )
    reg_ids = fields.Many2one("hms.registration", string="Reg Id")
    resv_id = fields.Many2one("hotel.reservation",string="Resv Id", compute="_compute_resv_id", index=True, ondelete="set null")

    def _compute_resv_id(self):
        for record in self:
            trans_line = self.env["hms.trans.line"].search([("bill_id", "=", record.id)], limit=1)
            if trans_line:
                record.resv_id = trans_line.resv_id.id
            else:
                record.resv_id = False
    room_no = fields.Many2one("hms_room_setup", compute="_compute_room_no")
    currency = fields.Many2one("res.currency", compute="_compute_room_no", store=True)
    transaction_lines = fields.One2many("hms.trans.line", "bill_id")
    payment_lines = fields.One2many("hotel.payment.line", "bill_id")
    bill_amount = fields.Float("Bill Amount")
    payment_amount = fields.Float("Payment Amount")
    remark = fields.Text("Remark", required=False)
    # for Total amount
    lst_price = fields.Float("Total:", compute="_compute_lst_price")
    invoice_id = fields.Many2one("account.move")
    invoice_count = fields.Integer("count", compute="_compute_invoice_count")
    bill_date = fields.Date("Bill Date", default=_today_date)
    sequence = fields.Integer("Sequence")
    # Filter Fields
    all_or_transactions = fields.Selection(
        [
            ("all", "All"),
            ("transaction_type", "Transaction Type"),
        ],
        String="Criteria",
    )
    transaction_type = fields.Many2one("hms.transaction", "Transaction Type")
    date = fields.Boolean("Date")
    from_date = fields.Date("From Date", default=_today_date)
    to_date = fields.Date("To Date", default=_today_date)
    trigger_field_search = fields.Char("Trigger Search")
    trigger_field_add = fields.Char("Trigger Add")
    trigger_field_ip = fields.Char()
    payment_delete = fields.Boolean("payment delete", default=True)
    # New field to store the selected transaction IDs temporarily
    selected_transaction_ids = fields.Many2many(
        "hms.trans.line",
        string="Selected Transactions",
        compute="_compute_selected_transaction_ids",
    )

    @api.depends("transaction_lines.select")
    def _compute_selected_transaction_ids(self):
        for bill in self:
            selected_transactions = bill.transaction_lines.filtered(
                lambda line: line.select
            )
            bill.selected_transaction_ids = [(6, 0, selected_transactions.ids)]

    @api.depends("transaction_lines")
    def _compute_lst_price(self):
        price = 0.0
        for record in self:
            for line in record.transaction_lines:
                currency_rate = 1
                if line.trans_currency:
                    currency_rate = line.trans_currency_rate
                if line.select == True:
                    price += (
                        line.trans_price + line.tax + line.service - line.discount
                    ) * currency_rate
            record.lst_price = price

    @api.model
    def create(self, vals):
        if vals.get("name", _("TBA")) == _("TBA"):
            sql = "select coalesce(max(sequence),0)+1 from hotel_bill"
            self.env.cr.execute(sql)
            result = self.env.cr.fetchall()
            vals["sequence"] = result[0][0]
            sequence_number = str(result[0][0])
            if len(str(result[0][0])) == 1:
                sequence_number = "00" + str(result[0][0])
            if len(str(result[0][0])) == 2:
                sequence_number = "0" + str(result[0][0])
            if len(str(result[0][0])) > 2:
                sequence_number = str(result[0][0])
            vals["name"] = sequence_number

        bill = super(Bill, self).create(vals)
        bill_amount = 0
        payment_amount = 0
        transaction_ids = []
        payment_ids = []
        for transaction in bill.transaction_lines:
            if transaction.select == True:
                transaction.bill_name = bill.name
                # to add transactions to master folio
                if transaction.non_master_id:
                    trans_line = self.env["hms.trans.line"].search(
                        [("id", "=", transaction.non_master_id)]
                    )
                    trans_line.write(
                        {
                            "bill_name": bill.name,
                            "reference": "Bill by Master "
                            + bill.reg_ids.reg_room_no.name,
                        }
                    )
                # to add reference andbill name in master when non master create bill
                if bill.reg_ids.group_key and not bill.reg_ids.master_bill:
                    trans_line = self.env["hms.trans.line"].search(
                        [("non_master_id", "=", transaction.id)]
                    )
                    trans_line.write(
                        {
                            "bill_name": bill.name,
                            "reference": "Bill by " + bill.reg_ids.reg_room_no.name,
                        }
                    )

                bill_amount = (
                    bill_amount
                    + (
                        transaction.trans_price
                        + transaction.tax
                        + transaction.service
                        - transaction.discount
                    )
                    * transaction.trans_currency_rate
                )
                bill_amount = round(bill_amount, 1)
                transaction_ids.append(transaction.id)
        for payment in bill.payment_lines:
            payment_amount = payment_amount + (payment.amount * payment.rate)
            payment_amount = round(payment_amount, 1)
        # if bill_amount==0:
        #     raise ValidationError(_("Can't Pay without amount"))

        # if bill_amount != payment_amount:
        #     raise ValidationError(_("Payment amount must be equal total amount "))

        transaction_lines = [(6, 0, transaction_ids)]
        bill.write(
            {
                "bill_amount": bill_amount,
                "payment_amount": payment_amount,
                "transaction_lines": transaction_lines,
            }
        )

        transaction_lines = self.env["hms.trans.line"].search(
            [("reg_id", "=", bill.reg_ids.id), ("bill_name", "=", False)]
        )
        if not transaction_lines:
            reg = self.env["hms.registration"].search([("id", "=", bill.reg_ids.id)])
            reg.write({"all_billed": True, "payment_filter": "paid"})

        else:
            for transaction_line in transaction_lines:
                transaction_line.write({"select": True})
        bill.payment_delete = False
        return bill

    @api.depends("reg_ids","resv_id")
    def _compute_room_no(self):
        for rec in self:
            if rec.reg_ids:
                rec.room_no = rec.reg_ids.reg_room_no.id
                rec.currency = rec.reg_ids.reg_currency.id
            elif rec.resv_id:
                rec.room_no = rec.resv_id.room_no.id
                rec.currency = rec.resv_id.currency.id

    @api.onchange("transaction_lines")
    def _onchange_trans_lines_id(self):
        self.payment_lines = False
        bill_amount = 0
        for transaction in self.transaction_lines:
            if transaction.select:
                bill_amount = bill_amount + (
                    (
                        transaction.trans_price
                        + transaction.tax
                        + transaction.service
                        - transaction.discount
                    )
                    * transaction.trans_currency_rate
                )
        base_currency = self.env["res.currency"].search(
            [("hotelia_base_currency", "=", True)], limit=1
        )
        payment_code = self.env["hotel.payment"].search(
            [("currency", "=", base_currency.id), ("payment_group", "=", "cash")],
            limit=1,
        )
        payment_line = [
            (
                0,
                0,
                {
                    "payment_code": payment_code.id,
                    "currency": base_currency.id,
                    "rate": 1.0,
                    "amount": bill_amount,
                },
            )
        ]
        self.payment_lines = payment_line
        self.bill_amount = bill_amount

    @api.onchange("payment_lines")
    def _onchange_payment_lines(self):
        pay_amount = 0
        for rec in self.payment_lines:
            pay_amount = pay_amount + (rec.amount * rec.rate)

        self.payment_amount = pay_amount

    @api.onchange("trigger_field_add")
    def add_payment(self):
        pay_amount = 0
        base_currency = self.env["res.currency"].search(
            [("hotelia_base_currency", "=", True)], limit=1
        )
        payment_line = self.payment_lines
        if self.trigger_field_add != "something":
            base_currency = self.env["res.currency"].search(
                [("hotelia_base_currency", "=", True)], limit=1
            )
            pay_amount = self.bill_amount - self.payment_amount
            if pay_amount < 0:
                pay_amount = 0
            payment_code = self.env["hotel.payment"].search(
                [("currency", "=", base_currency.id), ("payment_group", "=", "cash")],
                limit=1,
            )
            payment_line = [
                (
                    0,
                    0,
                    {
                        "payment_code": payment_code.id,
                        "currency": base_currency.id,
                        # 'rate': 1.0,
                        "amount": pay_amount,
                        # 'base_amount': pay_amount
                    },
                )
            ]
            self.payment_lines = payment_line

    @api.onchange("trigger_field_search")
    def search_transaction(self):
        transaction_ids = []

        transaction_lines = self.env["hms.trans.line"].search(
            [("reg_id", "=", self.reg_ids.id), ("bill_name", "=", False)]
        )
        for transaction in transaction_lines:
            transaction_ids.append(transaction.id)

        if self.trigger_field_search != "something":
            self.transaction_lines = False
            selecct_criteria = [("id", "in", transaction_ids)]
            if self.all_or_transactions == "transaction_type":
                transaction_type_criteria = (
                    "trans_lines_id",
                    "=",
                    self.transaction_type.id,
                )
                selecct_criteria.append(transaction_type_criteria)
            if self.date == True:
                from_date_criteria = ("trans_date", ">=", self.from_date)
                selecct_criteria.append(from_date_criteria)
                to_date_criteria = ("trans_date", "<=", self.to_date)
                selecct_criteria.append(to_date_criteria)
            searched_transactions = self.env["hms.trans.line"].search(selecct_criteria)
            searched_transaction_ids = []
            if not searched_transactions:
                raise ValidationError("No record found!")
            else:
                for searched_transaction in searched_transactions:
                    searched_transaction_ids.append(searched_transaction.id)
                self.transaction_lines = [(6, 0, searched_transaction_ids)]

    def open_invoice(self):
        for rec in self:
            return {
                "name": _("Bills"),
                "domain": [("hotelia_bill_id", "=", rec.id)],
                "res_model": "account.move",
                "type": "ir.actions.act_window",
                "context": rec._context,
                "views": [[False, "tree"], [False, "kanban"], [False, "form"]],
                "view_mode": "tree, kanban, form",
            }

    def _compute_invoice_count(self):
        for rec in self:
            invoice_count = self.env["account.move"].search_count(
                [("hotelia_bill_id", "=", rec.id)]
            )
            rec.invoice_count = invoice_count

    def fields_view_get(
        self, view_id=None, view_type="form", toolbar=False, submenu=False
    ):
        res = super(Bill, self).fields_view_get(
            view_id=view_id, view_type=view_type, toolbar=toolbar, submenu=submenu
        )

        if view_type == "form" and self.name != "TBA":
            doc = etree.XML(res["arch"])
            for node in doc.xpath("//field[@name='payment_lines']/tree"):
                node.set("delete", "false")

            res["arch"] = etree.tostring(doc, encoding="unicode")
        return res

    @api.onchange("trigger_field_ip")
    def action_print_bill_info(self):
        data = {}
        # if self.trigger_field_ip != "something":
        selected_transaction_ids = self.selected_transaction_ids.ids
        data["form"] = {
            "tran_string": ",".join(str(tid) for tid in selected_transaction_ids),
            "guest_name": self.reg_ids.guest_name,
            "agent_name": self.reg_ids.reg_agent_id.name,
            "arrival_date": self.reg_ids.arrival_date,
            "departure_date": self.reg_ids.departure_date,
            "room_no": self.room_no.name,
            "reg_ids": self.reg_ids.name,
            "print_date": date.today(),
        }
        return (
            self.env.ref("hotelia.action_bill_info_template")
            .with_context(landscape=True)
            .report_action(self, data=data)
        )

    # @api.onchange("trigger_field_bp")
    def action_bill_print(self):
        data = {}
        selected_transaction_ids = self.selected_transaction_ids.ids
        data["form"] = {
            "tran_string": ",".join(str(tid) for tid in selected_transaction_ids),
            "reg_ids": self.reg_ids.name,
            "bill_id": self.id,
            "guest_name": self.reg_ids.guest_name,
            "agent_name": self.reg_ids.reg_agent_id.name,
            "arrival_date": self.reg_ids.arrival_date,
            "departure_date": self.reg_ids.departure_date,
            "room_no": self.room_no.name,
            "bill_no": self.name,
            "bill_date": self.bill_date,
            "print_date": date.today(),
            "received_by": self.create_uid.name,
        }
        return self.env.ref("hotelia.action_bill_print_template").report_action(
            self, data=data
        )

    def unlink(self):
        reg = self.env["hms.registration"].search([("id", "=", self.reg_ids.id)])
        # update_allbill = f"UPDATE hms_registration SET all_billed='False',payment_status='pending' WHERE id={self.reg_ids.id}"
        # self.env.cr.execute(update_allbill)
        if reg:
            reg.write(
                {
                    "all_billed": True,
                    "bill_delete": True,
                    "payment_status": "pending",
                    "payment_filter": "pending",
                }
            )
        transaction_ids = []
        payment_ids = []
        transaction_lines = self.env["hms.trans.line"].search(
            [("reg_id", "=", self.reg_ids.id), ("bill_id", "=", self.id)]
        )
        for transaction in transaction_lines:
            transaction_ids.append(transaction.id)

        payment_lines = self.env["hotel.payment.line"].search(
            [("bill_id", "=", self.id)]
        )
        for payment in payment_lines:
            payment_ids.append(payment.id)

        for rec in self:
            if rec.invoice_id:
                raise UserError("You cannot delete a bill that is already invoiced.")

            if rec.reg_ids.Rsv_Type == "check_out":
                raise UserError("You cannot delete a bill that is already checked out.")

            bill_history_data = {
                "name": rec.name,
                "reg_ids": rec.reg_ids.id,
                "room_no": rec.room_no.id,
                "currency": rec.currency.id,
                "transaction_lines": transaction_ids,
                "payment_lines": payment_ids,
                "bill_amount": rec.bill_amount,
                "payment_amount": rec.payment_amount,
                "lst_price": rec.lst_price,
                "bill_date": rec.bill_date,
                "delete_by": rec.write_uid.id,
                "delete_date": rec.write_date,
            }
            self.env["hotel.bill.history"].create(bill_history_data)
            transaction_lines.write({"bill_name": ""})
            # payment_lines.write({"bill_id": ''})
            super(Bill, self).unlink()
            noti = {
                "type": "ir.actions.client",
                "tag": "display_notification",
                "params": {
                    "type": "info",
                    "sticky": False,
                    "message": _("Bill Deleted"),
                    "fadeout": "slow",
                    "next": {
                        "name": _("Bills Deleted"),
                        "res_model": "hotel.bill.history",
                        "type": "ir.actions.act_window",
                        "context": self._context,
                        "views": [[False, "kanban"], [False, "form"]],
                        "view_mode": "tree, kanban, form",
                    },
                },
            }
        return noti


class BH(models.Model):
    _name = "hotel.bill.history"
    _description = "Hotelia Bill History"

    def _today_date(self):
        # current_date = datetime.now()
        new_date = fields.Date.today()
        return new_date

    delete_by = fields.Many2one("res.users", string="Deleted By")
    name = fields.Char(
        "Bill No.", copy=False, readonly=True, default=lambda self: _("TBA")
    )
    # bill_id = fields.Integer("bill_id")
    reg_ids = fields.Many2one("hms.registration", string="Reg Id")
    room_no = fields.Many2one("hms_room_setup")
    currency = fields.Many2one("res.currency", store=True)
    transaction_lines = fields.One2many("hms.trans.line", "bill_id_history")
    payment_lines = fields.One2many("hotel.payment.line", "bill_id_history")
    bill_amount = fields.Float("Bill Amount")
    payment_amount = fields.Float("Payment Amount")
    lst_price = fields.Float("Total:")
    invoice_id = fields.Many2one("account.move")
    bill_date = fields.Date("Bill Date", default=_today_date)
    delete_date = fields.Date("Delete Date", default=_today_date)
    sequence = fields.Integer("Sequence")
    # Filter Fields
    all_or_transactions = fields.Selection(
        [
            ("all", "All"),
            ("transaction_type", "Transaction Type"),
        ],
        String="Criteria",
    )
    transaction_type = fields.Many2one("hms.transaction", "Transaction Type")
    date = fields.Boolean("Date")
    from_date = fields.Date("From Date", default=_today_date)
    to_date = fields.Date("To Date", default=_today_date)
    payment_delete = fields.Boolean("payment delete", default=True)
