# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models


class HmsConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    # nrc = fields.Boolean(string="Nrc", config_parameter='hotelia.nrc')
    # gn = fields.Boolean(string="Group Name", config_parameter='hotelia.gn')
    # passport = fields.Boolean(string="Passport", config_parameter='hotelia.passport')
    # agent = fields.Boolean(string="Agent", config_parameter='hotelia.agent')
    # company = fields.Boolean(string="Company", config_parameter='hotelia.company')
