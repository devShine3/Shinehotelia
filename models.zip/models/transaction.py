from odoo import api, fields, models, _
from datetime import datetime
from odoo.exceptions import MissingError, UserError, ValidationError, AccessError
from datetime import datetime, timedelta, date
from datetime import datetime, timedelta, time
import logging

_logger = logging.getLogger(__name__)


class Transaction(models.Model):
    _name = "hms.transaction"
    _description = "Transaction Type"

    name = fields.Char(String="Product")
    price = fields.Float(String="Price")
    service = fields.Float(string="Service")
    tax = fields.Float(string="Tax")
    currency = fields.Many2one("res.currency", "Currency")
    # booking_key = fields.Integer(string="Booking Key")
    product_id = fields.Many2one(comodel_name="product.product", string="Product")
    # quantity = fields.Integer(string="Quantity")
    customer_name = fields.Char(string="Customer")

    @api.model
    def create(self, vals):
        transaction_setup = super(Transaction, self).create(vals)

        product_data = self.env["product.product"].search(
            [("id", "=", vals.get("product_id"))]
        )

        if not product_data:
            product = self.env["product.product"].create(
                {
                    "name": vals.get("name"),
                    "type": "service",
                    "taxes_id": False,
                    "supplier_taxes_id": False,
                    "sale_ok": False,
                    "purchase_ok": False,
                    "lst_price": vals.get(
                        "price"
                    ),  # Do not set a high value to avoid issue with coupon code
                }
            )
            transaction_setup.write({"product_id": product.id})
        return transaction_setup


class TransactionLine(models.Model):
    _name = "hms.trans.line"
    _description = "HMS Transaction Lines"

    def _today_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=0)
        return new_date

    show_tran_code = fields.Integer("Trans Code", compute="_compute_show_tran_code")
    bill_transfer_id = fields.Many2one("hotel.bill_transfer", "Bill Transfer")

    advance_receipt_tran = fields.Char(compute="_compute_advance_receipt_tran")

    def _compute_advance_receipt_tran(self):
        for rec in self:
            # _logger.info(f"{len(rec.trans_lines_id.name)} --tranid")

            if rec.trans_lines_id.name == "Advance Receipt":
                rec.advance_receipt_tran = "advance_receipt"
            else:
                rec.advance_receipt_tran = ""

    trans_lines_id = fields.Many2one("hms.transaction", "Name")
    reg_id = fields.Many2one("hms.registration", "Folios")
    pack_id = fields.Many2one("hms.package", "Package")
    resv_id = fields.Many2one("hotel.reservation", "Reservation")
    bill_id = fields.Many2one("hotel.bill", "Bill ID")
    bill_id_history = fields.Many2one("hotel.bill.history", "Bill history")
    bill_name = fields.Char("Bill")
    trans_price = fields.Float(String="Price")
    trans_currency = fields.Many2one("res.currency", "Currency")
    payment_type = fields.Many2one("hotel.payment", "Payment Type")
    trans_currency_rate = fields.Float(
        "Transaction Rate", compute="_compute_currency_rate", store=True
    )
    trans_date = fields.Date("Date", default=_today_date)
    select = fields.Boolean("Select", default=True)
    trans_type = fields.Selection(
        [
            ("pos ", "POS "),
            ("restaurant", "Restaurant"),
            ("day", "Day Use"),
            ("payment", "Payment"),
            ("night", "Night Audit"),
            ("package", "Package"),
            ("deposit", "Deposit"),
            ("discount", "Discount"),
            ("product", "Product"),
        ],
        string="Transaction Type",
    )
    service = fields.Float(String="Service Fee", default="0.00")
    tax = fields.Float(String="Tax", default="0.00")
    discount = fields.Float(String="Discount", default="0.00")
    name = fields.Char(
        string="Trans No.", copy=False, readonly=True, default=lambda self: _("TBA")
    )
    reference = fields.Char(String="Reference")
    sequence = fields.Integer("Sequence")
    data_type = fields.Selection(
        [("left", "Left "), ("right", "Right")], string="Transaction Type"
    )
    non_master_id = fields.Integer()
    group_readonly = fields.Boolean("Groups Access")
    quantity = fields.Integer("Quantity", default=1)
    flag = fields.Boolean(compute='check_group')
    original_price = fields.Float(String="Original Price")
    night_audit_done = fields.Boolean(string="Night Audit Done", default=False)

    def check_group(self):
        for rec in self:
            if self.user_has_groups("hotelia.group_hms_billing_master"):
                rec.flag = True
            else:
                rec.flag = False

    # def update_group_readonly(self):
    #     user = self.env['res.users'].has_group('hotelia.group_hms_billing_master')
    #     if user:
    #         trans_lines = self.env['hms.trans.line'].search([])
    #         trans_lines.write({'group_readonly': True})
    #     else:
    #         trans_lines = self.env['hms.trans.line'].search([])
    #         trans_lines.write({'group_readonly': False})

    def _compute_show_tran_code(self):
        for rec in self:
            if rec.non_master_id:
                rec.show_tran_code = rec.non_master_id
            else:
                rec.show_tran_code = rec.id

    @api.model
    def create(self, vals):
        trans_line = super(TransactionLine, self).create(vals)
        if trans_line.resv_id:
            bill_date = date.today()
            amount = (
                trans_line.trans_price
                + trans_line.tax
                + trans_line.service
                - trans_line.discount
            )
            payment_code = self.env["hotel.payment"].search(
                [
                    ("currency", "=", trans_line.trans_currency.id),
                    ("payment_group", "=", "cash"),
                ],
                limit=1,
            )
            payment_line = [
                (
                    0,
                    0,
                    {
                        "payment_code": payment_code.ensure_one().id,
                        "currency": trans_line.trans_currency.id,
                        "amount": amount,
                    },
                )
            ]

            bill = self.env["hotel.bill"].create(
                {
                    "name": _("TBA"),
                    "bill_amount": amount * trans_line.trans_currency_rate,
                    "payment_amount": amount * trans_line.trans_currency_rate,
                    "payment_lines": payment_line,
                    "bill_date": bill_date,
                    "transaction_lines": trans_line,
                }
            )
        return trans_line

    def action_save(self):
        if self.resv_id:
            current_date = datetime.now()
            new_date = current_date + timedelta(days=1)
            reservation = self.env["hotel.reservation"].search(
                [("id", "=", self.resv_id.id)]
            )
            reservation.write(
                {
                    "Rsv_Type": "cancel",
                    "departure": new_date,
                    "departure_date": fields.Date.today(),
                }
            )
            return {
                "name": _("Cancelled"),
                "type": "ir.actions.act_window",
                "view_mode": "form",
                "res_model": "hotel.reservation",
                "res_id": self.resv_id.id,
                "target": "main",
            }

    @api.onchange("trans_lines_id")
    def _onchange_trans_lines_id(self):
        for rec in self:
            if rec.trans_lines_id:
                trans_data = self.env["hms.transaction"].search(
                    [("id", "=", rec.trans_lines_id.id)], order="id desc", limit=1
                )
                if trans_data:
                    rec.trans_price = trans_data.price
                    rec.trans_currency = trans_data.currency

    @api.depends("trans_currency")
    def _compute_currency_rate(self):
        for rec in self:
            base_currency = self.env["res.currency"].search(
                [("hotelia_base_currency", "=", True)], limit=1
            )
            if rec.trans_currency.id == base_currency.id or not rec.trans_currency:
                rec.trans_currency_rate = 1.0
            else:
                company_obj = self.env.user.sudo().company_id
                if not base_currency:
                    raise ValidationError(
                        _("You must create hotelia base currency first")
                    )
                else:
                    rec.trans_currency_rate = base_currency._get_conversion_rate(
                        rec.trans_currency,
                        base_currency,
                        company_obj,
                        datetime.now().date(),
                    )

    def unlink(self):
        for rec in self:
            trans_line_master = self.env["hms.trans.line"].search(
                [("non_master_id", "=", rec.id)]
            )
            _logger.info(f"trans_line_master: {trans_line_master}")
            if trans_line_master:
                trans_line_master.unlink()
            trans_line_self = super(TransactionLine, rec).unlink()
