from odoo import models, fields, api, _


class companySetup(models.Model):
    _name = "hmslite.companysetup"
    _description = "Group Setup Form"
    _order = "id ASC"

    name = fields.Char(string="Name", required="True")
