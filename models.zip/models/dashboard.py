from odoo import api, fields, models
from datetime import datetime, timedelta, date
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT as dt
import logging
import pytz

_logger = logging.getLogger(__name__)


class Dashboard(models.Model):
    _name = "hotel.dashboard"
    _description = "Dashboard Helpler Methods"

    def compute_daterange(self, month, year=datetime.now().year):
        """
        Give a month as an integer.\n
        Compute the first and last dates of that month.\n
        Return a tuple containing the first date and last date.
        """
        current_year = year
        first_date = date(current_year, month, 1)

        if month == 12:
            next_month = 1
            next_year = current_year + 1
        else:
            next_month = month + 1
            next_year = current_year

        last_date = date(next_year, next_month, 1) - timedelta(days=1)

        return first_date, last_date

    def total_reservation(self, current_month=datetime.now().month):
        first_date, last_date = self.compute_daterange(month=current_month)
        total_booking_count = self.env["hotel.reservation"].search_count(
            [
                ("create_date", ">=", first_date),
                ("create_date", "<=", last_date),
            ]
        )
        reservation_count = self.env["hotel.reservation"].search_count(
            [
                ("create_date", ">=", first_date),
                ("create_date", "<=", last_date),
                (
                    "Rsv_Type",
                    "!=",
                    "cancel",
                ),
                (
                    "Rsv_Type",
                    "!=",
                    "noshow",
                ),
            ]
        )
        return reservation_count, total_booking_count

    def total_cancel(self, current_month=datetime.now().month):
        fast_date, last_date = self.compute_daterange(month=current_month)
        cancel_count = self.env["hotel.reservation"].search_count(
            [
                ("create_date", ">=", fast_date),
                ("create_date", "<=", last_date),
                (
                    "Rsv_Type",
                    "=",
                    "cancel",
                ),
            ]
        )
        return cancel_count

    def avaliable_table__header(self, start_date, end_date):
        def get_day_name(date_string):
            return date_string.strftime("%a")

        def is_weekend(date_string):
            return date_string.weekday() >= 5

        date_range = []

        while start_date <= end_date:
            date_obj = {
                "name": start_date.strftime("%d"),
                "day": get_day_name(start_date),
                "weekend": is_weekend(start_date),
                "date": start_date,
            }
            date_range.append(date_obj)
            start_date += timedelta(days=1)

        return date_range

    def avaliable_table__body(self, current_month=datetime.now().month):
        start_date = datetime.today().date()
        avaliable_rooms_data = []
        room_types = self.env["hms.room.type"].search([("function", "=", False)])
        # room_reservations = self.env["hotel.reservation"].search([("Rsv_Type", "!=", "cancel")])
        room_reservations = self.env["hotel.reservation"].search(
            [("Rsv_Type", "in", ["open", "confirmed", "waitlist", "registration"])]
        )
        # room_reservations = self.env["hms_room_setup"].search([("room_status", "in", ["v_clean", "v_dirty"])])
        all_rooms_total = 0

        date_range = self.avaliable_table__header(
            start_date, end_date=start_date + timedelta(days=14)
        )  # Retrieve the date range using the provided method

        for room_type in room_types:
            total = self.env["hms_room_setup"].search_count(
                [("room_type", "=", room_type.id)]
            )
            all_rooms_total += total
            # Initialize the room type entry
            if room_type.category:
                room_type_entry = {
                    "name": room_type.category,
                    "total": str(total),
                    "avaliable": [],
                }

                for date_obj in date_range:
                    day = date_obj["name"]
                    current_date = date_obj["date"]

                    # Check if there is a reservation for the room type on the current date
                    reservations = room_reservations.filtered(
                        lambda r: r.room_type.id == room_type.id
                        and r.arrival_date <= current_date <= r.departure_date
                        and r.overbook == False
                        # and r.Rsv_Type != 'cancel'
                    )
                    _logger.info(f"{reservations} --rooms")
                    avaliable_count = total - len(reservations)

                    # Create the availability entry for the current date
                    availability_entry = {
                        "avaliable_count": str(avaliable_count)
                        if avaliable_count > 0
                        else 0,
                        "date": day,
                        "weekend": date_obj["weekend"],
                    }

                    room_type_entry["avaliable"].append(availability_entry)

                avaliable_rooms_data.append(room_type_entry)

        return {
            "table_body": avaliable_rooms_data,
            "table_header": date_range,
            "total_rooms": all_rooms_total,
        }

    def chart__doughnut_data(self, day=None):
        if day is None:
            day = date.today()

        start_datetime = datetime.combine(day, datetime.min.time()).strftime(dt)
        end_datetime = datetime.combine(day, datetime.max.time()).strftime(dt)

        # search_domain = [
        #     ("create_date", ">=", start_datetime),
        #     ("create_date", "<=", end_datetime),
        #     ("Rsv_Type", "in", ["registration", "check_out"]),
        # ]
        search_domain = [
            ("write_date", ">=", start_datetime),
            ("write_date", "<=", end_datetime),
            ("Rsv_Type", "in", ["registration", "check_out"]),
        ]

        registration_counts = self.env["hms.registration"].read_group(
            search_domain,
            ["Rsv_Type", "id"],
            ["Rsv_Type"],
        )

        today_checkin_count = 0
        today_checkout_count = 0

        for record in registration_counts:
            rsv_type = record["Rsv_Type"]
            count = record["Rsv_Type_count"]

            if rsv_type == "registration":
                today_checkin_count = count
            elif rsv_type == "check_out":
                today_checkout_count = count

        return today_checkin_count, today_checkout_count
