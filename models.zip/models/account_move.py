import json
import logging
from datetime import datetime
import requests
import base64
from dateutil.parser import parse as duparse
from odoo import api, fields, models
from odoo.exceptions import Warning

_logger = logging.getLogger(__name__)


class AccountMove(models.Model):
    _inherit = "account.move"

    hotelia_bill_id = fields.Many2one(
        "hotel.bill", String="Hotelia Bill", ondelete="set null"
    )
