from odoo import models, fields


class DeliveryOrder(models.Model):
    _inherit = "stock.picking"

    customer_name = fields.Char(string="Customer Name")
    room = fields.Char(string="Room")
    booking_key = fields.Many2one(comodel_name="hms.registration", string="Booking")
