from datetime import date
from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime, timedelta, date
import pytz


class RoomTransfer(models.TransientModel):
    _name = "room.transfer.wizard"
    _description = "Room Transfer"

    def _tomorrow_date(self):
        print(f"{self.env.context} ---env")
        current_date = datetime.now()
        new_date = current_date + timedelta(days=1)
        return new_date

    def _today_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=0)
        return new_date

    reg_no = fields.Many2one("hms.registration")
    guest_name = fields.Char()
    group = fields.Many2one("hms.groupreserve")
    group_name = fields.Char()
    agent = fields.Many2one("hmslite.agentsetup")
    room_type = fields.Many2one("hms.room.type")
    room_no = fields.Many2one("hms_room_setup")
    rate_type = fields.Many2one("hms.customer_type")
    currency = fields.Many2one("res.currency")
    room_amount = fields.Float()
    extra_bed = fields.Selection(
        [("0", "0"), ("1", "1"), ("2", "2"), ("3", "3"), ("4", "4")],
        string="Extra Bed",
        default="0",
    )
    breakfast = fields.Boolean()

    reg_arrival = fields.Datetime(
        "Arrival Date Full",
        compute="_compute_arrival_datetime_field",
        inverse="_reverse_compute_arrival_datetime",
        store=True,
    )
    arrival_date = fields.Date("Arrival Date")
    arrival_time = fields.Float("Ariival Time")

    reg_departure = fields.Datetime(
        "Departure Date Full",
        compute="_compute_departure_datetime_field",
        inverse="_reverse_compute_departure_datetime",
        store=True,
    )
    departure_date = fields.Date("Departure Date")
    departure_time = fields.Float("Departure Time")

    t_room_type = fields.Many2one("hms.room.type")
    t_room_no = fields.Many2one("hms_room_setup")
    t_rate_type = fields.Many2one("hms.customer_type")
    t_currency = fields.Many2one("res.currency")
    t_room_amount = fields.Float()
    t_extra_bed = fields.Selection(
        [("0", "0"), ("1", "1"), ("2", "2"), ("3", "3"), ("4", "4")],
        string="Extra Bed",
        default="0",
    )
    t_breakfast = fields.Boolean()
    t_special_request = fields.Html(string="Special Request")

    def default_get(self, fields):
        res = super(RoomTransfer, self).default_get(fields)
        if self._context["default_reg_no"]:
            regsv_no = self.env["hms.registration"].search(
                [("id", "=", self._context["default_reg_no"])]
            )
            group_id = False
            agent_id = False
            room_type = False
            room_no = False
            rate_type = False
            currency = False
            if regsv_no.group_key:
                group_id = (
                    self.env["hms.groupreserve"]
                    .search([("id", "=", regsv_no.group_key)], order="id desc", limit=1)
                    .name
                )
            if regsv_no.reg_agent_id:
                agent_id = regsv_no.reg_agent_id.id
            if regsv_no.reg_room_type:
                room_type = regsv_no.reg_room_type.id
            if regsv_no.reg_room_no:
                room_no = regsv_no.reg_room_no.id
            if regsv_no.reg_customer_type:
                rate_type = regsv_no.reg_customer_type.id
            if regsv_no.reg_currency:
                currency = regsv_no.reg_currency.id

            res["guest_name"] = regsv_no.guest_name
            res["arrival_date"] = regsv_no.arrival_date
            res["arrival_time"] = regsv_no.arrival_time
            res["departure_date"] = regsv_no.departure_date
            res["departure_time"] = regsv_no.departure_time
            res["group_name"] = group_id
            res["agent"] = agent_id
            res["room_type"] = room_type
            res["room_no"] = room_no
            res["rate_type"] = rate_type
            res["room_amount"] = regsv_no.reg_amount
            res["extra_bed"] = regsv_no.reg_extra_bed
            res["breakfast"] = regsv_no.reg_breakfast
            res["currency"] = currency
            res["t_room_type"] = room_type

            res["t_rate_type"] = rate_type
            res["t_room_amount"] = regsv_no.reg_amount
            res["t_extra_bed"] = regsv_no.reg_extra_bed
            res["t_breakfast"] = regsv_no.reg_breakfast
            res["t_currency"] = currency
        return res

    @api.depends("arrival_date", "arrival_time")
    def _compute_arrival_datetime_field(self):
        for record in self:
            if record.arrival_date:
                # Extract hour and minute values from float time field
                hour, minutes = divmod(int(record.arrival_time * 60), 60)

                # Create a timezone object from the user's timezone string
                tz_string = self._context.get("tz", False)
                user_timezone = pytz.timezone(tz_string)
                print(f"{self.env.context} ---env")

                # Create a datetime object with the date and time values
                arrival_datetime = datetime.combine(
                    record.arrival_date, datetime.min.time()
                ) + timedelta(hours=hour, minutes=minutes)

                # Get the UTC offset for the datetime object
                utc_offset = user_timezone.utcoffset(arrival_datetime)

                # Convert the UTC offset to hours and minutes
                utc_offset_hours = int(utc_offset.total_seconds() / 3600)
                utc_offset_minutes = int((utc_offset.total_seconds() % 3600) / 60)

                # Adjust the datetime object for the UTC offset and store it in the field
                record.reg_arrival = arrival_datetime - timedelta(
                    hours=utc_offset_hours, minutes=utc_offset_minutes
                )

            else:
                # Clear the value of arrival_field
                record.reg_arrival = False

    @api.onchange("reg_arrival")
    def _reverse_compute_arrival_datetime(self):
        for record in self:
            if record.reg_arrival:
                tz_string = self._context.get("tz", False)
                user_timezone = pytz.timezone(tz_string)

                # Convert arrival_datetime_field to a UTC datetime object
                arrival_datetime_utc = record.reg_arrival.replace(tzinfo=pytz.utc)

                # Convert the UTC datetime object to the user's timezone
                arrival_datetime_user_tz = arrival_datetime_utc.astimezone(
                    user_timezone
                )

                # Extract the date and time components in the user's timezone
                my_date = arrival_datetime_user_tz.date()
                my_time = arrival_datetime_user_tz.time()

                # Calculate the float value of the time component
                my_time_float = my_time.hour + my_time.minute / 60

                # print(f"{my_time_float} --time")

                # Store the updated values
                record.arrival_date = my_date
                record.arrival_time = my_time_float

    @api.depends("departure_date", "departure_time")
    def _compute_departure_datetime_field(self):
        for record in self:
            if record.departure_date:
                # Extract hour and minute values from float time field
                hour, minutes = divmod(int(record.departure_time * 60), 60)

                # Create a timezone object from the user's timezone string
                tz_string = self._context.get("tz", False)
                user_timezone = pytz.timezone(tz_string)

                # Create a datetime object with the date and time values
                departure_datetime = datetime.combine(
                    record.departure_date, datetime.min.time()
                ) + timedelta(hours=hour, minutes=minutes)

                # Get the UTC offset for the datetime object
                utc_offset = user_timezone.utcoffset(departure_datetime)

                # Convert the UTC offset to hours and minutes
                utc_offset_hours = int(utc_offset.total_seconds() / 3600)
                utc_offset_minutes = int((utc_offset.total_seconds() % 3600) / 60)

                # Adjust the datetime object for the UTC offset and store it in the field
                record.reg_departure = departure_datetime - timedelta(
                    hours=utc_offset_hours, minutes=utc_offset_minutes
                )

            else:
                # Clear the value of arrival_field
                record.reg_departure = False

    @api.onchange("reg_departure")
    def _reverse_compute_departure_datetime(self):
        for record in self:
            if record.reg_departure:
                tz_string = self._context.get("tz", False)
                user_timezone = pytz.timezone(tz_string)

                # Convert departure_datetime_field to a UTC datetime object
                departure_datetime_utc = record.reg_departure.replace(tzinfo=pytz.utc)

                # Convert the UTC datetime object to the user's timezone
                departure_datetime_user_tz = departure_datetime_utc.astimezone(
                    user_timezone
                )

                # Extract the date and time components in the user's timezone
                my_date = departure_datetime_user_tz.date()
                my_time = departure_datetime_user_tz.time()

                # Calculate the float value of the time component
                my_time_float = my_time.hour + my_time.minute / 60

                # print(f"{my_time_float} --time")

                # Store the updated values
                record.departure_date = my_date
                record.departure_time = my_time_float

    @api.onchange("t_room_type")
    def _onchange_field1_field2_roomno_domain(self):
        # Define your logic here to compute the domain

        for rec in self:
            rooms_id = []

            rooms_id = (
                rec.env["hms.registration"]
                .search(
                    [
                        ("arrival_date", "<=", rec.arrival_date),
                        ("departure_date", ">", rec.arrival_date),
                        ("Rsv_Type", "!=", "waitlist"),
                        ("Rsv_Type", "!=", "cancel"),
                        ("Rsv_Type", "=", "registration"),
                    ]
                )
                .reg_room_no.ids
            )
            reserve_rooms = rec.env["hotel.reservation"].search(
                [
                    ("arrival_date", "<=", rec.arrival_date),
                    ("departure_date", ">", rec.arrival_date),
                    ("Rsv_Type", "=", "registration"),
                ]
            )
            for reserve_room in reserve_rooms:
                rooms_id.append(reserve_room.room_no.id)
            # rooms_id.append(rec.env['hotel.reservation'].search([('arrival_date','<=',rec.arrival_date),('departure_date','>',rec.arrival_date)]).room_no.ids)

            return {
                "domain": {
                    "t_room_no": [
                        ("id", "not in", rooms_id),
                        ("room_type", "=", rec.t_room_type.id),
                    ]
                }
            }

    @api.onchange("t_room_type")
    def _onchange_reg_room_type(self):
        if self.t_room_type and self.t_room_type != self.t_room_no.room_type:
            self.t_room_no = False

    @api.depends(
        "t_room_type",
        "t_rate_type",
        "t_extra_bed",
        "t_breakfast",
        "reg_arrival",
        "t_currency",
    )
    def _compute_room_amount(self):
        for guest in self:
            rateData = self.env["hms_room_rate"].search(
                [
                    ("room_type", "=", guest.t_room_type.id),
                    ("customer_type", "=", guest.t_rate_type.id),
                    ("currency", "=", guest.t_currency.id),
                    ("from_date", "<=", guest.arrival_date),
                    ("to_date", ">=", guest.arrival_date),
                ],
                limit=1,
            )
            guest.t_room_amount = rateData.room_rate

            # extra bed
            if int(guest.t_extra_bed) > 0:
                guest.t_room_amount = rateData.extra_bed * int(guest.reg_extra_bed)

            # break fast
            if rateData.room_type and rateData.rate_type:
                if not rateData.breakfastFlag:
                    guest.t_breakfast = True
                else:
                    if guest.t_breakfast:
                        guest.t_room_amount += rateData.breakfast

    def room_transfer(self):
        old_reg = self.env["hms.registration"].search(
            [("id", "=", self.reg_no.id)], limit=1
        )
        old_reg.write(
            {
                "Rsv_Type": "transfer",
                "departure_date": date.today(),
            }
        )
        old_reg.reg_room_no.write(
            {
                "room_status": "v_dirty",
            }
        )

        guest_info_list = []
        trans_lines = []
        for g_data in old_reg.guest_ids:
            guest_info = (
                0,
                0,
                {
                    "name": g_data.name,
                    "nationality": g_data.nationality.id,
                    "nrc": g_data.nrc,
                    "passport_no": g_data.passport_no,
                    "email": g_data.email,
                    "phone": g_data.phone,
                    "date_of_birth": g_data.date_of_birth,
                    "gender": g_data.gender,
                    "num_1": g_data.num_1,
                },
            )
            guest_info_list.append(guest_info)
        for transaction in old_reg.transaction_id:
            trans_line = (
                0,
                0,
                {
                    "trans_lines_id": transaction.trans_lines_id.id,
                    "trans_price": transaction.trans_price,
                    "tax": transaction.tax,
                    "service": transaction.service,
                    "discount": transaction.discount,
                    "trans_type": transaction.trans_type,
                    "trans_currency": transaction.trans_currency.id,
                    "non_master_id": transaction.non_master_id,
                    "bill_name": transaction.bill_name,
                    "reference": transaction.reference,
                    "trans_date": transaction.trans_date,
                },
            )
            trans_lines.append(trans_line)
        new_reg_object = {
            "name": old_reg.name,
            "departure_date": self.departure_date,
            "departure_time": self.departure_time,
            "reg_departure": self.reg_departure,
            "arrival_date": old_reg.arrival_date,
            "arrival_time": old_reg.arrival_time,
            "reg_arrival": old_reg.reg_arrival,
            # "reg_room_rate": self.t_room_rate,
            "reg_customer_type": self.t_rate_type.id,
            "reg_room_type": self.t_room_type.id,
            "reg_room_no": self.t_room_no.id,
            "reg_amount": self.t_room_amount,
            "reg_currency": self.t_currency.id,
            "reg_extra_bed": self.t_extra_bed,
            "reg_breakfast": self.t_breakfast,
            "reg_adult": old_reg.reg_adult,
            "reg_child": old_reg.reg_child,
            "reg_group_id": old_reg.reg_group_id,
            "reg_agent_id": old_reg.reg_agent_id.id,
            "reg_company_id": old_reg.reg_company_id.id,
            "group_key": old_reg.group_key,
            "reg_group_flag": old_reg.reg_group_flag,
            "Rsv_Type": "registration",
            "guest_name": old_reg.guest_name,
            "guest_name_testing": old_reg.guest_name,
            "title": old_reg.title.id,
            "phone": old_reg.phone,
            "email": old_reg.email,
            "nric": old_reg.nric,
            "date_of_birth": old_reg.date_of_birth,
            "gender": old_reg.gender,
            "passport_no": old_reg.passport_no,
            "national": old_reg.national.id,
            "guest_key": old_reg.guest_key,
            "deposit": old_reg.deposit,
            "payment_status": old_reg.payment_status,
            "payment_info": old_reg.payment_info,
            "remark": old_reg.remark,
            "special_request": self.t_special_request,
            "reservation_id": old_reg.reservation_id,
            "guest_ids": guest_info_list,
            "contact_person": old_reg.contact_person,
            "contact_phone": old_reg.contact_phone,
            "gp_checkin": True,
            "master_room": old_reg.master_room,
            "master_bill": old_reg.master_bill,
            "transaction_id": trans_lines,
            # "bill_count": old_reg.bill_count
        }
        new_reg = self.env["hms.registration"].create(new_reg_object)

        if new_reg:
            # record = self.env['hms.registration'].search([('id', '=', new_reg.id)], limit=1)
            # if record:
            #     record_data = record.read()[0]
            #
            #     # Do something with the reloaded record data
            #     # ...
            #
            #     return record_data
            # record = self.env['hms.registration'].browse(new_reg.id)
            #
            # record.invalidate_cache()
            # record.refresh()
            #
            # # Optional: Return the reloaded record if needed
            # return record

            # action = {
            #     'type': 'ir.actions.client',
            #     'tag': 'reload',
            #     'params': {
            #         'model': 'hms.registration',
            #         'id': new_reg.id,
            #
            #     },
            # }

            original_bills = self.env["hotel.bill"].search(
                [("reg_ids", "=", old_reg.id)]
            )
            for original_bill in original_bills:
                original_bills.reg_ids = new_reg.id

            action = {
                "name": _("Transferred"),
                "type": "ir.actions.act_window",
                "view_mode": "form",
                "res_model": "hms.registration",
                # pass the id
                "res_id": new_reg.id,
                "target": "main",
                # 'context': {'no_breadcrumbs': True }
            }

            return action
