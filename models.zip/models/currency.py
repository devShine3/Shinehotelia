import logging
import math
import re
import time

from lxml import etree
from odoo import api, fields, models, tools, _
from odoo.exceptions import MissingError, UserError, ValidationError, AccessError

_logger = logging.getLogger(__name__)

try:
    from num2words import num2words
except ImportError:
    _logger.warning(
        "The num2words python library is not installed, amount-to-text features won't be fully available."
    )
    num2words = None

CURRENCY_DISPLAY_PATTERN = re.compile(r"(\w+)\s*(?:\((.*)\))?")


class Currency(models.Model):
    _inherit = "res.currency"
    hotelia_base_currency = fields.Boolean("Hotelia Base", default=False)

    # @api.onchange('hotelia_base_currency')
    # def _onchange_trans_lines_id(self):
    #     for rec in self:
    #         existing_base_currency = self.env['res.currency'].search([('hotelia_base_currency','=',True)])
    #         if existing_base_currency and rec.hotelia_base_currency == True and existing_base_currency.id != rec.id:
    #             raise ValidationError(_('Hotelia Base Currency is existed.'))
    #             rec.hotelia_base_currency = False
    def write(self, vals):
        existing_base_currency = self.env["res.currency"].search(
            [("hotelia_base_currency", "=", True)]
        )
        currency_obj = super().write(vals)
        if (
            existing_base_currency
            and self.hotelia_base_currency == True
            and existing_base_currency.id != self.id
        ):
            raise ValidationError(_("Hotelia Base Currency is existed."))
            currency_obj.hotelia_base_currency = False

        return currency_obj
