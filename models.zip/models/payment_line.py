from odoo import api, fields, models
from datetime import datetime, date, timedelta
import logging

_logger = logging.getLogger(__name__)

class PaymentLine(models.Model):
    _name = "hotel.payment.line"
    _description = "Hotelia Payment"
    name = fields.Char("Payment Line")
    bill_id = fields.Many2one("hotel.bill", string="Bill Id", ondelete="set null")
    bill_id_history = fields.Many2one("hotel.bill.history", "Bill history")
    payment_code = fields.Many2one(
        "hotel.payment", string="Payment Code", ondelete="set null"
    )
    currency = fields.Many2one(
        "res.currency", string="Currency", compute="_compute_currency_rate"
    )
    rate = fields.Float("Currency Rate", compute="_compute_currency_rate")
    amount = fields.Float("Payment Amount")
    base_rate = fields.Float("Changed currency")
    base_amount = fields.Float("Currency Rate", compute="_compute_base_amount")
    previous_currency = fields.Many2one("res.currency", string="Previous Currency")

    @api.depends("payment_code")
    def _compute_currency_rate(self):
        for rec in self:
            payment = self.env["hotel.payment"].search(
                [("id", "=", rec.payment_code.id)]
            )
            rec.name = payment.name
            rec.currency = payment.currency

            base_currency = self.env["res.currency"].search(
                [("hotelia_base_currency", "=", True)], limit=1
            )
            company_obj = self.env.user.sudo().company_id
            if rec.currency.id == base_currency.id or not rec.currency:
                rec.rate = 1.0

            else:
                rec.rate = base_currency._get_conversion_rate(
                    rec.currency, base_currency, company_obj, datetime.now().date()
                )

    @api.onchange("amount")
    def _change_base_amount(self):
        for rec in self:
            rec.base_amount = rec.amount * rec.rate

    @api.depends("amount")
    def _compute_base_amount(self):
        for rec in self:
            rec.base_amount = rec.amount * rec.rate

    @api.onchange("payment_code")
    def _onchange_currency_rate(self):
        for rec in self:
            base_currency = self.env["res.currency"].search(
                [("hotelia_base_currency", "=", True)], limit=1
            )
            company_obj = self.env.user.sudo().company_id

            changed_currency = rec.currency

            if rec.currency.id == base_currency.id or not rec.currency:
                rec.rate = 1.0
                rec.amount = rec.base_amount * rec.rate

            else:
                rec.rate = base_currency._get_conversion_rate(
                    rec.currency, base_currency, company_obj, datetime.now().date()
                )
                actual_rate = changed_currency._get_conversion_rate(
                    base_currency, rec.currency, company_obj, datetime.now().date()
                )
                rec.amount = actual_rate * rec.base_amount

    def compute_daterange(self, month, year=datetime.now().year):
        """
        Give a month as an integer.\n
        Compute the first and last dates of that month.\n
        Return a tuple containing the first date and last date.
        """
        current_year = year
        first_date = date(current_year, month, 1)
        print(first_date, "first date----------")
        if month == 12:
            next_month = 1
            next_year = current_year + 1
        else:
            next_month = month + 1
            next_year = current_year

        last_date = date(next_year, next_month, 1) - timedelta(days=1)
        print(last_date, "last date----------")
        return first_date, last_date

    def total_income(self, current_month=datetime.now().month):
        # import pdb; pdb.set_trace()
        current_year = datetime.now().year
        prev_year = datetime.now().year -1
        prev_month = current_month - 1
        if prev_month == 0:
            prev_month = 12

            current_first_date, current_last_date = self.compute_daterange(
                month=current_month, year=current_year
            )
            print(current_first_date, current_last_date, "current_first_date, current_last_date------------" )
            prev_first_date, prev_last_date = self.compute_daterange(
                month=prev_month, year=prev_year
            )
        else:
            current_first_date, current_last_date = self.compute_daterange(
                    month=current_month, year=current_year
                )
            print(current_first_date, current_last_date, "current_first_date, current_last_date------------" )
            prev_first_date, prev_last_date = self.compute_daterange(
                month=prev_month, year=current_year
            )
        current_month_bills = [0] * 4  # Initialize with default value
        print(current_month_bills, "current_month---------------------------")
        prev_month_bills = [0] * 4  # Initialize with default value
        bills_by_week = {
            i: {"current": 0, "previous": 0} for i in range(4)
        }  # Use a dictionary to store data
        print(bills_by_week, "bill by week-------------------")
        all_bills = self.env["hotel.payment.line"].search(
            [
                ("create_date", ">=", current_first_date),
                ("create_date", "<=", current_last_date),
            ]
        )
        print(all_bills, "all_bills---------------------------")
        for rec in all_bills:
            day = rec.create_date.day
            week_number = (day - 1) // 7 if day <= 21 else 3
            bills_by_week[week_number]["current"] += rec.base_amount
            print(all_bills, "all bills---------------------------")
        all_bills = self.env["hotel.payment.line"].search(
            [
                ("create_date", ">=", prev_first_date),
                ("create_date", "<=", prev_last_date),
            ]
        )
        print(all_bills, "all_bills---------------------------")
        for rec in all_bills:
            day = rec.create_date.day
            week_number = (day - 1) // 7 if day <= 21 else 3
            bills_by_week[week_number]["previous"] += rec.base_amount
            print(all_bills, "all bills---------------------------")
        # Convert the dictionary to separate lists for each period
        current_month_bills = [bills_by_week[i]["current"] for i in range(4)]
        prev_month_bills = [bills_by_week[i]["previous"] for i in range(4)]
        print(current_month_bills, "current_month---------------------------")

        total_income = {
            "prev_month": prev_month_bills,
            "current_month": current_month_bills,
        }
        print(total_income, "---------------------------")
        return {
            "total_income": total_income,
        }
