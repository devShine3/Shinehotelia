from odoo import api, fields, models, tools, _
from datetime import date


class RoomReserve(models.Model):
    _name = "hms.roomresreve"
    _description = "Room And Reservation Combo"

    name = fields.Char(
        string="Name",
        required=True,
        copy=False,
        readonly=True,
        default=lambda self: _("TBA"),
    )
    type = fields.Integer(string="Type")
    update_by = fields.Char(string="Update By")

    guest_id = fields.Many2one(
        "hotel.guest",
        string="Guest Name",
    )
    phone = fields.Char("Phone", tracking=50, readonly=False, store=True)
    email_from = fields.Char(
        "Email", tracking=40, index=True, readonly=False, store=True
    )
    contact_person = fields.Char("Contact Person", readonly=False, store=True)

    def _get_default_room_type(self):
        # journals = self.env['account.journal'].search([('type', '=', 'bank')])
        # accounts = []
        # for journal in journals:
        #     accounts.append(journal.company_id.account_journal_payment_credit_account_id.id)
        #     accounts.append(journal.company_id.account_journal_payment_debit_account_id.id)
        #     accounts.append(journal.default_account_id.id)

        return self.room_no.room_type.id

    room_type = fields.Many2one(
        "hms.room.type",
        String="Room Type",
        ondelete="set null",
        default=_get_default_room_type,
    )
    room_no = fields.Many2one("hms_room_setup", string="Room No")
    # room_rate = fields.Many2one('hms.customer_type', 'Customre Type')
    room_rate = fields.Selection(
        [
            ("ota", "OTA"),
            ("s_foreigner", "Single Foreigner"),
            ("d_local", "Double Local"),
            ("c_foreigner", "Complimentry Foreigner"),
            ("c_local", "Complimentry Local"),
            ("company1", "Company"),
        ],
        String="Customer Type",
        default="ota",
        tracking=True,
        translate=True,
    )

    arrival = fields.Datetime(
        "Start Date",
        help="Starting datetime for the pricelist item validation\n"
        "The displayed value depends on the timezone set in your preferences.",
    )
    departure = fields.Datetime(
        "End Date",
        help="Ending datetime for the pricelist item validation\n"
        "The displayed value depends on the timezone set in your preferences.",
    )

    adult = fields.Char("Adult")
    group = fields.Char("Group")
    agent = fields.Char("Agent")
    company = fields.Char("Company")
    address = fields.Char("Address")
    amount = fields.Float("Amount", compute="_compute_room_amount")
    currency = fields.Many2one("res.currency", "Currency")
    extra_bed = fields.Selection(
        [("0", "0"), ("1", "1"), ("2", "2"), ("3", "3"), ("4", "4")],
        string="Extra Bed",
    )
    breakfast = fields.Boolean("Breakfast")
    overbook = fields.Boolean("Overbook")
    special_request = fields.Html(string="Special Request")

    rsv_type = fields.Selection(
        [
            ("open", "Open"),
            ("confirmed", "Confirmed"),
            ("waitlist", "Waitlist"),
            ("registration", "Registered"),
        ],
        String="Reservation Type",
        default="open",
        tracking=True,
        translate=True,
    )
    wait_list = fields.Boolean("Waitlist")
    duration = fields.Float("Duration")

    # Address fields
    street = fields.Char("Street", readonly=False, store=True)
    street2 = fields.Char("Street2", readonly=False, store=True)
    zip = fields.Char("Zip", change_default=True, readonly=False, store=True)
    city = fields.Char("City", readonly=False, store=True)
    national = fields.Many2one(
        "hms.national",
        string="Nationality",
        readonly=False,
        store=True,
    )
    state_id = fields.Many2one(
        "res.country.state",
        string="State",
        readonly=False,
        store=True,
        domain="[('country_id', '=?', country_id)]",
    )
    country_id = fields.Many2one(
        "res.country", string="Country", readonly=False, store=True
    )
    company_id = fields.Many2one(
        "res.company", string="Company", index=True, readonly=False, store=True
    )

    @api.model
    # type 1 from hotel_reservation
    # type 2 from room
    # type 3 from self
    def create(self, vals):
        # from room
        if vals.get("type") == 2:
            vals["name"] = ""
            reservation_obj = super(RoomReserve, self).create(vals)
        # from hotel_reservation
        if vals.get("type") == 1:
            reservation_obj = super(RoomReserve, self).create(vals)

        if not vals.get("type"):
            vals["type"] = 3
            today = str(date.today())
            # year=t_date.year # 2022
            # month=t_date.month # 9
            # day=t_date.day  # 20
            # vals['name'] = str(day)+str(month)+str(year)+sequence

            sql = (
                "select coalesce(max(sequence),0)+1 from hotel_reservation where  TO_CHAR(create_date,'yyyy-mm-dd') LIKE '%"
                + today
                + "%' "
            )
            # create_date like '%%' """ % (today)

            self.env.cr.execute(sql)
            result = self.env.cr.fetchall()
            # sequence_no=int(rsv_num)+1
            sequence = result[0][0]
            sequence_number = str(result[0][0])
            if len(str(result[0][0])) == 1:
                sequence_number = "0" + str(result[0][0])
            vals["name"] = "Rsv/" + today + "/" + sequence_number

            reservation_obj = super(RoomReserve, self).create(vals)
            room_type = (
                self.env["hms_room_setup"]
                .search([("id", "=", reservation_obj.room_no.id)])
                .room_type
            )
            # roomreserv_id = self.env['hotel.reservation'].create(
            #
            #     {
            #
            #         'name': reservation_obj.name,
            #         'guest_id': reservation_obj.guest_id.id,
            #         'phone': reservation_obj.phone,
            #         'email_from': reservation_obj.email_from,
            #         'contact_person': reservation_obj.contact_person,
            #         'room_type': room_type.id,
            #         'room_no': reservation_obj.room_no.id,
            #         'room_rate': reservation_obj.room_rate,
            #         'arrival': reservation_obj.arrival,
            #         'sequence': sequence,
            #         'departure': reservation_obj.departure,
            #         'Rsv_Type': reservation_obj.rsv_type,
            #         'type': 1
            #
            #     }
            # )
        return reservation_obj

    def write(self, vals):
        if vals.get("update_by") == "Hotel Reservation":
            roomrsv = super(RoomReserve, self).write(vals)
        else:
            vals["update_by"] = "Booking Chart"
            roomrsv = super(RoomReserve, self).write(vals)
            # reservation_obj = self.env['hotel.reservation'].search([('name', '=', self.name)])
            # reservation_obj.write(
            #
            #     {
            #         'name': self.name,
            #         'guest_id': self.guest_id.id,
            #         'phone': self.phone,
            #         'email_from': self.email_from,
            #         'contact_person': self.contact_person,
            #         'room_type': self.room_type.id,
            #         'room_no': self.room_no.id,
            #         'room_rate': self.room_rate,
            #         'arrival': self.arrival,
            #         'departure': self.departure,
            #         'Rsv_Type': self.rsv_type,
            #         'update_by': "Booking Chart"
            #
            #     }
            #
            # )

        return roomrsv

    # compute function form amount field
    @api.depends("room_type", "room_rate", "extra_bed", "breakfast")
    def _compute_room_amount(self):
        for guest in self:
            rateData = self.env["hms_room_rate"].search(
                [
                    ("room_type", "=", guest.room_type.id),
                    ("rate_type", "=", guest.room_rate),
                ]
            )
            guest.amount = rateData.room_rate

            # extra bed
            if guest.extra_bed == "0":
                guest.amount = guest.amount
            else:
                guest.amount += rateData.extra_bed * int(guest.extra_bed)

            # Breakfast Exclusive
            if guest.breakfast:
                if rateData.breakfastFlag:
                    guest.amount += rateData.breakfast
