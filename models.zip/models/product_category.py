from odoo import models, fields


class ProductCategory(models.Model):
    _inherit = "product.category"

    transaction_type = fields.Many2one("hms.transaction", string="Transaction Type")
