# -*- coding: utf-8 -*-
import requests
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class BCconfig(models.Model):
    _name = "bc_config"
    _description = "Booking Chart Data Config"
    #
    # name = fields.Char(string='Name', readonly=True, default=lambda self: _('Booking Chart Config'))
    # group_name = fields.Boolean(string="Group Name")
    # nrc = fields.Boolean(string="NRC")
    # passport = fields.Boolean(string="Passport")
    # agent = fields.Boolean(string="Agent")
    # company = fields.Boolean(string="Company")
