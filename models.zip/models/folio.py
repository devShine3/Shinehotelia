# from odoo import api, fields, models, tools, _
# from datetime import datetime, date, time
# from datetime import date, timedelta
# from datetime import datetime
# import datetime
#
#
# class hmsfolio(models.Model):
#     _name = "hms.folio"
#     _description = "HMS Folio"
#     _order = 'id DESC'
#
#     fol_sequence = fields.Integer("Folio Sequence", default=0)
#     name = fields.Char("Folio Number", copy=False, readonly=True, default=lambda self: _('TBA'))
#     reg_ids = fields.Many2one('hms.registration', String="Registrations")
#     # reg_name = fields.Char(string='Reg No.')
#     checkin_date = fields.Datetime("Check In", )
#     checkout_date = fields.Datetime("Check Out")
#     # currency = fields.Char("Currency")
#     currency = fields.Many2one('res.currency', string="Currency")
#
#     transaction_id = fields.One2many("hms.trans.line", "fol_id", string="Transactions")
#     room_no = fields.Char(string='Room No.')
#     reg_key = fields.Integer('Registration ID')
#     guest_name = fields.Char(string="Guest Name")
#     all_billed = fields.Boolean(string="All Billed")
#     bill_count = fields.Integer("No. Folio", compute="_compute_bill_count")
#
#     def name_get(self):
#         res = []
#         fname = ""
#         for rec in self:
#             if rec.name:
#                 fname = "Fol" + str(rec.name)
#                 res.append((rec.id, fname))
#         return res
#
#     @api.model
#     def create(self, vals):
#         today = str(date.today())
#         date_format = date.today().strftime("%Y%m%d")
#         if vals.get('name', _('TBA')) == _('TBA'):
#             sql = "select coalesce(max(fol_sequence),0)+1 from hms_folio"
#             self.env.cr.execute(sql)
#             result = self.env.cr.fetchall()
#             vals['fol_sequence'] = result[0][0]
#             sequence_number = str(result[0][0])
#             if len(str(result[0][0])) == 1:
#                 sequence_number = "00" + str(result[0][0])
#             if len(str(result[0][0])) == 2:
#                 sequence_number = "0" + str(result[0][0])
#             if len(str(result[0][0])) > 2:
#                 sequence_number = str(result[0][0])
#             vals['name'] = sequence_number
#         folio_id = super(hmsfolio, self).create(vals)
#         reg_no = self.env['hms.registration'].search([('id', '=', folio_id.reg_ids.id)])
#         reg_no.write({"folio": folio_id.name})
#         return folio_id
#
#     # Choose one Record from `Registration Modal` and Update the `Folio`
#     @api.onchange('reg_key')
#     def _onchange_reg_key(self):
#         for rec in self:
#             if rec.reg_key:
#                 print(f'reg_key => {rec.reg_key}')
#                 reg_data = self.env['hms.registration'].search(
#                     [('id', '=', rec.reg_key)], order="id desc", limit=1)
#                 if reg_data:
#                     rec.reg_key = reg_data.id
#                     rec.room_no = reg_data.reg_room_no.name
#                     rec.reg_ids = reg_data.id
#                     rec.guest_name = reg_data.guest_name
#                     rec.currency = reg_data.reg_currency.id
#
#     @api.onchange('transaction_id')
#     def _onchange_reg_key(self):
#         self.all_billed = False
#         for transaction in self.transaction_id:
#             if transaction.bill_id == False:
#                 self.all_billed = True
#
#     def _compute_bill_count(self):
#         for rec in self:
#             rec.bill_count = self.env['hotel.bill'].search_count(
#                 [('folio_id', '=', rec.id)])
#
#     def open_bill_view(self):
#         return {
#             'name': _('Bills'),
#             'domain': [('folio_id', '=', self.id)],
#             'res_model': 'hotel.bill',
#             'type': 'ir.actions.act_window',
#             'context': self._context,
#             # 'view_id': self.env.ref('hms_integration.add_account_move_view_tree').id,
#             'views': [[False, "tree"], [False, "kanban"], [False, "form"]],
#             'view_mode': 'tree, kanban, form',
#         }
#
#     def open_bill(self):
#         bill_amount = 0
#         trans_lines = []
#         for transaction in self.transaction_id:
#             if not transaction.bill_id:
#                 bill_amount = bill_amount + transaction.trans_price
#                 trans_line = (0, 0, {
#                     'trans_lines_id': transaction.trans_lines_id.id,
#                     'trans_price': transaction.trans_price,
#                     'trans_currency': transaction.trans_currency.id,
#                     'fol_id': self.id,
#                 })
#                 # trans_lines.append(trans_line)
#                 trans_lines.append(transaction.id)
#         payment_code = self.env['hotel.payment'].search(
#             [('currency', '=', self.currency.id), ('payment_group', '=', 'cash')])
#         payment_line = [(0, 0, {
#             'payment_code': payment_code.id,
#             'currency': self.currency.id,
#             'rate': 1.0,
#             'amount': bill_amount
#
#         })
#                         ]
#         return {
#             'name': _('Bill'),
#             'type': 'ir.actions.act_window',
#             'view_type': 'form',
#             'view_mode': 'form',
#             'res_model': 'hotel.bill',
#             'context': {'default_all_or_transactions': 'all',
#                         'default_date': True,
#                         'default_folio_id': self.id,
#                         'default_transaction_lines': trans_lines,
#                         'default_bill_amount': bill_amount,
#                         'default_payment_amount': bill_amount,
#                         'default_payment_lines': payment_line,
#                         'default_trigger_field_search': 'something',
#                         },
#         }
