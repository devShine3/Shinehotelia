from odoo import api, fields, models


class functional_room_rate(models.Model):
    _name = "hms.functional.room.rate"
    _description = "functional_room_rate"
    _order = "id DESC"
    _rec_name = "room_rate"

    room_no = fields.Char("Room No.")
    room_id = fields.Integer("Functional Room ID")
    room_description = fields.Char("Description")
    room_function_type = fields.Many2one(
        "hms.functional.room.type", "Room Function Type", ondelete="set null"
    )
    from_date = fields.Date("From Date")
    to_date = fields.Date("To Date")
    currency = fields.Many2one(
        "res.currency", "Currency", require="True", ondelete="set null"
    )
    room_rate = fields.Float("Room Rate")

    # Choose one Record from `Rooms Modal` and Update the `Room Rate Form`
    @api.onchange("room_id")
    def _onchange_room_no(self):
        for rec in self:
            if rec.room_id:
                room_data = self.env["hms.functional.rooms.setup"].search(
                    [("id", "=", rec.room_id)], order="id desc", limit=1
                )
                if room_data:
                    rec.room_id = room_data.id
                    rec.room_no = room_data.room_no
                    rec.room_description = room_data.description
