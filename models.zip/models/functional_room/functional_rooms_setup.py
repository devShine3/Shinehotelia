from odoo import api, fields, models


class functional_room(models.Model):
    _name = "hms.functional.rooms.setup"
    _description = "functional_room_setup"
    _order = "id DESC"
    _rec_name = "room_no"

    room_type = fields.Many2one(
        "hms.functional.room.type", "Room Function Type", ondelete="set null"
    )
    room_no = fields.Char(string="Room No.")
    description = fields.Char(string="Description")
    location = fields.Char(string="Location")

    # Room Ref modal relatedAction
    def copy_functional_room_id(self):
        room_id = 0
        for rec in self:
            room_id = rec.id
        return room_id
