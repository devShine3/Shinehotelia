from odoo import api, fields, models


class functional_room_type(models.Model):
    _name = "hms.functional.room.type"
    _description = "functional_room_type"
    _order = "id DESC"
    _rec_name = "room_type"

    room_type = fields.Char(string="Room Function Type")
