from odoo import fields, models, api


class Package(models.Model):
    _name = "hms.package"
    _description = "Hotelia's Package"

    def _today_date(self):
        new_date = fields.Date.today()
        return new_date

    name = fields.Char(String="Name")
    # total_amt = fields.Float(String="Total amount",default=0)
    currency = fields.Many2one("res.currency", String="Currency", ondelete="set null")
    pack_date = fields.Date(String="Date", default=_today_date, readonly=True)
    transaction_id = fields.One2many(
        "hms.trans.line", "pack_id", string="Transaction Lines"
    )
    product_id = fields.Integer(String="Product")
    total_amt = fields.Integer(string="Total Quantity", compute="_compute_total_qty")

    # @api.onchange("transaction_id.trans_price")
    # def _compute_total_qty(self):
    #     total_amt = 0.0
    #     for record in self:
    #         for line in record.transaction_id:
    #             currency_rate = 1
    #             if line.trans_currency:
    #                 currency_rate = line.trans_currency_rate
    #             else:
    #                 line.trans_currency = self.currency.id
    #                 currency_rate = line.trans_currency_rate
    #             record.total_amt += (line.trans_price + line.tax + line.service - line.discount) * currency_rate

    @api.depends("transaction_id.trans_price")
    def _compute_total_qty(self):
        for record in self:
            total_amt = 0.0
            for line in record.transaction_id:
                currency_rate = 1
                if line.trans_currency:
                    currency_rate = line.trans_currency_rate
                total_amt += (
                    line.trans_price + line.tax + line.service - line.discount
                ) * currency_rate
            record.total_amt = total_amt

    @api.model
    def create(self, vals):
        # package type create in transaction
        type_search = self.env["hms.transaction"].search([("name", "=", "Package")])
        if not type_search:
            transaction_create = self.env["hms.transaction"].create(
                {
                    "name": "Package",
                }
            )
        package_setup = super(Package, self).create(vals)
        product = self.env["product.product"].create(
            {
                "name": vals.get("name"),
                "type": "service",
                "taxes_id": False,
                "supplier_taxes_id": False,
                "sale_ok": False,
                "purchase_ok": False,
                "lst_price": vals.get("total_amt"),
            }
        )
        package_setup.write({"product_id": product.id})
        return package_setup

    def copy_package_name(self):
        package_id = 0
        for rec in self:
            package_id = rec.id
        return package_id

    def name_get(self):
        result = []
        for rec in self:
            name = str(rec.id)
            result.append((rec.id, name))
        return result
