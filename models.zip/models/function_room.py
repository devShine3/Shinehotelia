import datetime
from odoo import api, fields, models
from datetime import datetime


class FunctionRooms(models.Model):
    _name = "function.room"
    _description = "to crate functional room"

    name = fields.Char(
        string="Rsv No.", readonly=True, copy=False, default=lambda self: ("TBA")
    )
    status = fields.Selection(
        [
            ("reserve", "Reservation"),
            ("registration", "Registered"),
            ("check_out", "Check Out"),
        ],
        string="Status",
        default="reserve",
        readonly=True,
    )
    title_guest = fields.Many2one(
        "hms.namelist", string="Title", readonly=False, store=True
    )
    g_name = fields.Char(string="Guest Name", required=True)
    g_key = fields.Integer("Guest ID")
    date = fields.Date(String="Date", required=True)
    time_1 = fields.Float(String="Time", required=True)
    time_2 = fields.Float()
    time_3 = fields.Float(compute="_compute_time_time3", readonly=True, String="Time")
    pax = fields.Char(String="Pax", default=0)
    c_person = fields.Char(String="Contact Person")
    c_phone = fields.Char(String="Contact Phone")
    c_address = fields.Html(String="Address")
    s_request = fields.Html(String="Special Request")
    f_remark = fields.Html(String="Remark")
    f_type = fields.Many2one("hms.functional.room.type")
    f_room = fields.Many2one("hms.functional.rooms.setup")
    function_type = fields.Many2one(
        "hms.room.type", string="Function Type", domain="[('function','=',True)]"
    )
    function_room = fields.Many2one(
        "hms_room_setup", string="Room No", domain="[('room_type', '=',function_type)]"
    )
    f_currency = fields.Many2one(
        "hms.functional.room.rate", string="Currency", readonly=False, store=True
    )
    f_price = fields.Many2one(
        "hms.room.rate", domain="[('f_currency', '=?', f_currency)]"
    )
    room_rate = fields.Float("Room Rate.", compute="compute_room_amount")
    price = fields.Float("Room Rate.", store=True)
    currency_1 = fields.Many2one("res.currency", readonly=True)
    currency_2 = fields.Many2one("res.currency", onchange="_currency_chnage")
    room_type = fields.Char()
    f_deposit = fields.Float("Deposit Amt.", required=True)
    sequence = fields.Integer("Sequence")
    room_id = fields.Integer(default=2)
    guest_ids = fields.One2many("hms.guestline", "functional_id")
    # guest data
    phone = fields.Char("Phone")
    email = fields.Char("Email")
    nric = fields.Char("NRIC")
    passport_no = fields.Char("Passport")
    national = fields.Many2one("hms.national", string="Nationality")
    date_of_birth = fields.Date("DOB")
    gender = fields.Selection(
        [("male", "Male"), ("female", "Female"), ("na", "NA")], default="male"
    )
    # transaction_ids
    bill_ids = fields.One2many("hms.trans.line", "trans_id", string="Transactions")

    def name_get(self):
        res = []
        fname = ""
        for rec in self:
            if rec.name:
                fname = "Rsv" + str(rec.name)
                res.append((rec.id, fname))
        return res

    @api.depends("function_room", "currency_2", "function_type", "date")
    def compute_room_amount(self):
        for rec in self:
            rateData = self.env["hms_room_rate"].search(
                [
                    ("room_no", "=", rec.function_room.id),
                    ("currency", "=", rec.currency_2.id),
                    ("from_date", "<=", rec.date),
                    ("to_date", ">=", rec.date),
                ],
                limit=1,
            )
            rec.room_rate = rateData.room_rate

    @api.onchange("g_key")
    def _onchange_guest_name(self):
        for rec in self:
            if rec.g_key:
                guest_data = self.env["hotel.guest"].search(
                    [("id", "=", rec.g_key)], order="id desc", limit=1
                )
                if guest_data:
                    rec.g_name = guest_data.name
                    rec.nric = guest_data.id_no
                    rec.passport_no = guest_data.passport_no
                    rec.email = guest_data.email_from
                    rec.phone = guest_data.phone
                    rec.national = guest_data.national
                    rec.title_guest = guest_data.title
                    rec.g_key = guest_data.id
                    rec.gender = guest_data.gender
                    rec.date_of_birth = guest_data.date_of_birth

    @api.depends("time_1", "time_2", "time_3")
    def _compute_time_time3(self):
        for rec in self:
            total_hour = rec.time_2 - rec.time_1
            rec.time_3 = total_hour

    @api.model
    def create(self, vals):
        if vals.get("name", ("TBA")) == ("TBA"):
            vals["name"] = self.env["ir.sequence"].next_by_code("function.room") or (
                "TBA"
            )
        res = super(FunctionRooms, self).create(vals)
        return res

    def funtion_to_reg(self):
        super(FunctionRooms, self).write(
            {
                "status": "registration",
            }
        )
        guest_info_list = []
        transaction_ids = []
        trans_lines = []
        price = ""
        if self.f_deposit == 0.00:
            price = self.f_deposit
        elif self.f_deposit > 0.00:
            price = -self.f_deposit
        # bill ids
        type_search = self.env["hms.transaction"].search([("name", "=", "Deposit")])
        if not type_search:
            transaction_create = self.env["hms.transaction"].create(
                {
                    "name": "Deposit",
                }
            )
            product = self.env["product.product"].create(
                {
                    "name": "Deposit",
                    "type": "service",
                    "taxes_id": False,
                    "supplier_taxes_id": False,
                    "sale_ok": False,
                    "purchase_ok": False,
                    "lst_price": price,
                }
            )
        trans_lines = (
            self.env["hms.transaction"].sudo().search([("name", "=", "Deposit")])
        )
        if self.f_deposit > 0.00:
            trans_info = (
                0,
                0,
                {
                    "trans_lines_id": trans_lines.id,
                    "trans_price": price,
                    "trans_currency": self.currency_2.id,
                    "reference": "Deposit Amount",
                },
            )
            transaction_ids.append(trans_info)

        #
        # trans_lines = self.env['hms.transaction'].sudo().create({
        #     'name': self.function_type.name,
        #     'price': price,
        #     'currency': self.currency_2.id,
        # })
        # trans_info = (0, 0, {
        #     'trans_lines_id': trans_lines.id,
        #     'trans_price': price,
        #     'trans_currency': self.currency_2.id,
        #
        # })
        # transaction_ids.append(trans_info)
        for g_data in self.guest_ids:
            guest_info = (
                0,
                0,
                {
                    "name": g_data.name,
                    "nationality": g_data.nationality.id,
                    "nrc": g_data.nrc,
                    "passport_no": g_data.passport_no,
                    "email": g_data.email,
                    "phone": g_data.phone,
                    "gender": g_data.gender,
                    "date_of_birth": g_data.date_of_birth,
                },
            )
            guest_info_list.append(guest_info)

        return (
            self.env["hms.registration"]
            .sudo()
            .create(
                {
                    "reg_date": self.date,
                    "reg_departure": self.date,
                    "reg_arrival": self.date,
                    "reg_room_type": self.function_type.id,
                    "reg_room_no": self.function_room.id,
                    "reg_currency": self.currency_2.id,
                    "reg_adult": self.pax,
                    "time_1": self.time_1,
                    "time_2": self.time_2,
                    "time_3": self.time_3,
                    "Rsv_Type": "registration",
                    "guest_name": self.g_name,
                    "guest_name_testing": self.g_name,
                    "contact_person": self.c_person,
                    "contact_phone": self.c_phone,
                    "guest_key": self.g_key,
                    "title": self.title_guest.id,
                    "remark": self.f_remark,
                    "special_request": self.s_request,
                    "guest_ids": guest_info_list,
                    "address": self.c_address,
                    "function_id": "1",
                    "f_deposit": self.f_deposit,
                    "reg_amount": self.room_rate,
                    "date_of_birth": self.date_of_birth,
                    "transaction_id": transaction_ids,
                    "reg_customer_type": False,
                    "function_resv_id": self.id,
                }
            )
        )


class GuestLine(models.Model):
    _inherit = "hms.guestline"
    functional_id = fields.Many2one("function.room")


class hms_trans_line(models.Model):
    _inherit = "hms.trans.line"
    trans_id = fields.Many2one("function.room")
