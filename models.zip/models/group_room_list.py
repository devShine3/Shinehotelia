from odoo import models, fields

class GroupRoomList(models.Model):
    _name = "hms.group.room.list"
    _description = "Group Room List for Group Reservation"

    room_type = fields.Many2one('hms.room.type', string="Room Type")
    total_rooms = fields.Integer(string="Total", default=0)
    available_rooms = fields.Integer(string="Available", default=0)
    room_rate = fields.Char(string="Room Rate", default="")
    book = fields.Integer(string="Book", default=0)
    booking_available = fields.Boolean(string="Booking Available", compute="_compute_booking_available")

    group_reserve = fields.Many2one('hms.groupreserve', string="Group Reservation")


    def add_booking_list(self):
        list = self
        if not list.book < 0 and list.book != list.total_rooms:
            list.book = list.book + 1
        elif list.book == list.total_rooms:
            list.book = list.book * 1


    def remove_booking_list(self):
        list = self
        if not list.book <= 0:
            list.book = list.book - 1
        elif list.book < 0:
            list.book = 0


    def _compute_booking_available(self):
        for record in self:
            if record.book == record.total_rooms:
                record.booking_available = False
            else:
                record.booking_available = True