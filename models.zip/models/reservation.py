from datetime import datetime, timedelta, time, date
from odoo import api, fields, models, tools, _
import os
import shutil
import zipfile
import io
import html
import re
import xlsxwriter
from odoo.exceptions import (
    RedirectWarning,
    UserError,
    ValidationError,
    AccessError,
    AccessDenied,
)

import pytz

import logging

_logger = logging.getLogger(__name__)

# import pyzipper
import json

# from datetime import datetime, timedelta
# Subset of partner fields: sync all or none to avoid mixed addresses
PARTNER_ADDRESS_FIELDS_TO_SYNC = [
    "street",
    "street2",
    "city",
    "zip",
    "state_id",
    "country_id",
    "visa_no",
    "national",
    "passport_no",
    "company_id",
]
# Subset of partner fields: sync any of those
PARTNER_FIELDS_TO_SYNC = [
    "mobile",
    "title",
    "function",
    "website",
]


class ReseRvation(models.Model):
    _name = "hotel.reservation"
    _description = "Hotel Reservation Form"
    _order = "name DESC"

    @api.model
    def reload_settings(self):
        isGuestNameChecked = self.env["ir.config_parameter"].get_param(
            "hotelia.isGuestNameChecked", ""
        )
        isIdChecked = self.env["ir.config_parameter"].get_param(
            "hotelia.isIdChecked", ""
        )
        isGroupNameChecked = self.env["ir.config_parameter"].get_param(
            "hotelia.isGroupNameChecked", ""
        )
        isAgentChecked = self.env["ir.config_parameter"].get_param(
            "hotelia.isAgentChecked", ""
        )
        isCompanyChecked = self.env["ir.config_parameter"].get_param(
            "hotelia.isCompanyChecked", ""
        )
        isPhoneChecked = self.env["ir.config_parameter"].get_param(
            "hotelia.isPhoneChecked", ""
        )
        check_out_time = self.env["ir.config_parameter"].get_param(
            "hotelia.check_out_time", ""
        )
        for record in self:
            if isGuestNameChecked:
                record.isGuestNameChecked = isGuestNameChecked
            else:
                record.isGuestNameChecked = "False"
            if isIdChecked:
                record.isIdChecked = isIdChecked
            else:
                record.isIdChecked = "False"
            if isGroupNameChecked:
                record.isGroupNameChecked = isGroupNameChecked
            else:
                record.isGroupNameChecked = "False"
            if isAgentChecked:
                record.isAgentChecked = isAgentChecked
            else:
                record.isAgentChecked = "False"
            if isCompanyChecked:
                record.isCompanyChecked = isCompanyChecked
            else:
                record.isCompanyChecked = "False"
            if isPhoneChecked:
                record.isPhoneChecked = isPhoneChecked
            else:
                record.isPhoneChecked = "False"
            if check_out_time:
                record.check_out_time = check_out_time
            else:
                record.check_out_time = 12

    def _default_room_type(self):
        room_type = False
        room_type_id = (
            self.env["hms.room.type"].search([("function", "=", False)], limit=1).id
        )
        if room_type_id:
            room_type = room_type_id
        return room_type

    def _default_customer_type(self):
        customer_type = False
        customer_type_id = (
            self.env["hms.customer_type"]
            .search(([("name", "=", "Regular")]), limit=1)
            .id
        )
        if customer_type_id:
            customer_type = customer_type_id
        return customer_type

    def _default_currency(self):
        currency = False
        currency_id = (
            self.env["res.currency"]
            .search([("hotelia_base_currency", "=", True)], limit=1)
            .id
        )
        if currency_id:
            currency = currency_id
        return currency

    def _tomorrow_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=1)
        return new_date

    def _today_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=0)
        return new_date

    name = fields.Char(
        string="Rsv No.", copy=False, readonly=True, default=lambda self: _("TBA")
    )
    type = fields.Integer("Type")
    update_by = fields.Char("Update By")
    sequence = fields.Integer("Sequence")
    # create_month = create_date.month
    guest_id = fields.Many2one("hotel.guest", string="Guest Name")
    guest_ids = fields.One2many("hms.guestline", "reservation_id")

    # room_type = fields.Many2one("hms.room.type", String="Room Type", ondelete="set null", default=_default_room_type)
    room_type = fields.Many2one(
        "hms.room.type",
        String="Room Type",
        ondelete="set null",
        compute="_compute_room_type",
        inverse="_inverse_room_type",
        store=True,
        domain="[('function', '=', False)]",
    )
    room_no = fields.Many2one(
        "hms_room_setup", string="Room No.", domain="[('room_type', '=?', room_type)]"
    )
    room_no_domain = fields.Char(
        compute="_compute_field1_field2_roomno_domain",
        readonly=True,
        store=False,
    )

    customer_type = fields.Many2one(
        "hms.customer_type", "Customer Type", default=_default_customer_type
    )
    room_rate = fields.Selection(
        [
            ("ota", "OTA"),
            ("s_foreigner", "Single Foreigner"),
            ("d_local", "Double Local"),
            ("cooperate", "Cooperate"),
            # ('c_local', 'Complimentry Local'),
            ("company1", "Company"),
        ],
        String="Customer Type",
        default="ota",
        tracking=True,
        translate=True,
    )

    """
    Separate datetime fields to date and time
    """
    arrival = fields.Datetime(
        "Arrival Date Full",
        compute="_compute_arrival_datetime_field",
        inverse="_reverse_compute_arrival_datetime",
        store=True,
        default=_today_date,
    )

    arrival_date = fields.Date("Arrival Date")

    arrival_time = fields.Float("Ariival Time")
    # arrival_month = arrival.month
    # month = arrival.strftime('%B')
    departure = fields.Datetime(
        "Departure Date Full",
        compute="_compute_departure_datetime_field",
        inverse="_reverse_compute_departure_datetime",
        store=True,
        default=_tomorrow_date,
    )
    departure_date = fields.Date("Departure Date")
    departure_time = fields.Float("Departure Time")
    intial_arrival_date = fields.Datetime(
        "Init Arrival Date Full",
        # compute="_compute_arrival_datetime_field",
        # inverse="_reverse_compute_arrival_datetime",
        store=True,
        # default=_today_date,
    )
    intial_departure_date = fields.Datetime(
        "Init Departure Date Full",
        # compute="_compute_departure_datetime_field",
        # inverse="_reverse_compute_departure_datetime",
        store=True,
        # default=_tomorrow_date,
    )

    # departure_month = departure.month
    @api.depends("arrival_date", "arrival_time")
    def _compute_arrival_datetime_field(self):
        for record in self:
            if record.arrival_date:
                # Extract hour and minute values from float time field
                hour, minutes = divmod(int(record.arrival_time * 60), 60)

                # Create a timezone object from the user's timezone string
                tz_string = self.env.user.tz or "UTC"
                user_timezone = pytz.timezone(tz_string)
                print(f"{self.env.context} ---env")

                # Create a datetime object with the date and time values
                arrival_datetime = datetime.combine(
                    record.arrival_date, datetime.min.time()
                ) + timedelta(hours=hour, minutes=minutes)

                # Get the UTC offset for the datetime object
                utc_offset = user_timezone.utcoffset(arrival_datetime)

                # Convert the UTC offset to hours and minutes
                utc_offset_hours = int(utc_offset.total_seconds() / 3600)
                utc_offset_minutes = int((utc_offset.total_seconds() % 3600) / 60)

                # Adjust the datetime object for the UTC offset and store it in the field
                record.arrival = arrival_datetime - timedelta(
                    hours=utc_offset_hours, minutes=utc_offset_minutes
                )
                record.intial_arrival_date = arrival_datetime - timedelta(
                    hours=utc_offset_hours, minutes=utc_offset_minutes
                )
            else:
                # Clear the value of arrival_field
                record.arrival = False
                record.intial_arrival_date = False

    @api.depends("room_type")
    def _compute_field1_field2_roomno_domain(self):
        for rec in self:
            rooms_id = []
            rooms_id = (
                self.env["hotel.reservation"]
                .search(
                    [
                        ("arrival_date", "<=", rec.arrival_date),
                        ("departure_date", ">", rec.arrival_date),
                        ("Rsv_Type", "!=", "waitlist"),
                        ("Rsv_Type", "!=", "cancel"),
                        ("Rsv_Type", "=", "registration"),
                    ]
                )
                .room_no.ids
            )
            domain = [
                ("id", "not in", rooms_id),
                ("room_type", "=", rec.room_type.id),
                ("room_status", "!=", "oos"),
                ("room_status", "!=", "ooo"),
            ]
            rec.room_no_domain = json.dumps(domain)

    @api.onchange("arrival")
    def _reverse_compute_arrival_datetime(self):
        for record in self:
            if record.arrival:
                tz_string = self.env.user.tz or "UTC"
                user_timezone = pytz.timezone(tz_string)
                _logger.info(f"{user_timezone} {tz_string} --tz")

                # Convert arrival_datetime_field to a UTC datetime object
                arrival_datetime_utc = record.arrival.replace(tzinfo=pytz.utc)

                # Convert the UTC datetime object to the user's timezone
                arrival_datetime_user_tz = arrival_datetime_utc.astimezone(
                    user_timezone
                )

                # Extract the date and time components in the user's timezone
                my_date = arrival_datetime_user_tz.date()
                my_time = arrival_datetime_user_tz.time()

                # Calculate the float value of the time component
                my_time_float = my_time.hour + my_time.minute / 60

                # print(f"{my_time_float} --time")

                # Store the updated values
                record.arrival_date = my_date
                record.arrival_time = my_time_float

    @api.depends("departure_date", "departure_time")
    def _compute_departure_datetime_field(self):
        for record in self:
            if record.departure_date:
                # Extract hour and minute values from float time field
                hour, minutes = divmod(int(record.departure_time * 60), 60)

                # Create a timezone object from the user's timezone string
                tz_string = self.env.user.tz or "UTC"
                user_timezone = pytz.timezone(tz_string)

                # Create a datetime object with the date and time values
                departure_datetime = datetime.combine(
                    record.departure_date, datetime.min.time()
                ) + timedelta(hours=hour, minutes=minutes)

                # Get the UTC offset for the datetime object
                utc_offset = user_timezone.utcoffset(departure_datetime)

                # Convert the UTC offset to hours and minutes
                utc_offset_hours = int(utc_offset.total_seconds() / 3600)
                utc_offset_minutes = int((utc_offset.total_seconds() % 3600) / 60)

                # Adjust the datetime object for the UTC offset and store it in the field
                record.departure = departure_datetime - timedelta(
                    hours=utc_offset_hours, minutes=utc_offset_minutes
                )
                record.intial_departure_date = departure_datetime - timedelta(
                    hours=utc_offset_hours, minutes=utc_offset_minutes
                )

            else:
                # Clear the value of arrival_field
                record.departure = False
                record.intial_departure_date = False

    @api.onchange("departure")
    def _reverse_compute_departure_datetime(self):
        for record in self:
            if record.departure:
                tz_string = self.env.user.tz or "UTC"
                user_timezone = pytz.timezone(tz_string)

                # Convert departure_datetime_field to a UTC datetime object
                departure_datetime_utc = record.departure.replace(tzinfo=pytz.utc)

                # Convert the UTC datetime object to the user's timezone
                departure_datetime_user_tz = departure_datetime_utc.astimezone(
                    user_timezone
                )

                # Extract the date and time components in the user's timezone
                my_date = departure_datetime_user_tz.date()
                my_time = departure_datetime_user_tz.time()

                # Calculate the float value of the time component
                my_time_float = my_time.hour + my_time.minute / 60

                # Store the updated values
                record.departure_date = my_date
                record.departure_time = my_time_float

    adult = fields.Integer("Adult", default=1)
    child = fields.Integer("Child", default=0)
    address = fields.Char("Address")
    amount = fields.Float("Amount", compute="_compute_room_amount")
    currency = fields.Many2one("res.currency", "Currency", default=_default_currency)
    # currency = fields.Many2one("res.currency", "Currency")
    extra_bed = fields.Selection(
        [("0", "0"), ("1", "1"), ("2", "2"), ("3", "3"), ("4", "4")],
        string="Extra Bed",
        default="0",
        required="1",
    )
    breakfast = fields.Boolean("Breakfast", default=False)
    overbook = fields.Boolean("Overbook", default=False, compute="_compute_over_book")
    dayuse = fields.Boolean(string="Day Use", default=False)

    @api.depends("room_type", "arrival_date", "room_no")
    def _compute_over_book(self):
        # ("Rsv_Type", "!=", 'check_out'),
        check_over_book = []
        for rec in self:
            rec.overbook = False
            if rec.room_no:
                same_room_reservations = self.env["hotel.reservation"].search(
                    [
                        ("arrival_date", "<=", rec.arrival_date),
                        ("departure_date", ">", rec.arrival_date),
                        ("room_no", "=", rec.room_no.id),
                        ("id", "!=", rec.id),
                        ("Rsv_Type", "not in", ["check_out", "cancel"]),
                    ],
                    order="id desc",
                )
                if same_room_reservations and rec.id not in check_over_book:
                    rec.overbook = True
                    for reservation in same_room_reservations:
                        check_over_book.append(reservation.id)
            else:
                total_rooms = self.env["hms_room_setup"].search_count(
                    [("room_type", "=", rec.room_type.id)]
                )
                total_reserve = self.env["hotel.reservation"].search_count(
                    [
                        ("arrival_date", "<=", rec.arrival_date),
                        ("departure_date", ">", rec.arrival_date),
                        ("room_type", "=", rec.room_type.id),
                    ]
                )
                total_reservation = self.env["hotel.reservation"].search(
                    [
                        ("arrival_date", "<=", rec.arrival_date),
                        ("departure_date", ">", rec.arrival_date),
                        ("room_type", "=", rec.room_type.id),
                        ("id", "!=", rec.id),
                    ]
                )
                available = total_rooms - total_reserve + 1
                if available <= 0 and rec.id not in check_over_book:
                    rec.overbook = True
                    for reservation in total_reservation:
                        check_over_book.append(reservation.id)

    special_request = fields.Html(string="Special Request")
    Rsv_Type = fields.Selection(
        [
            ("open", "Open"),
            ("confirmed", "Confirmed"),
            ("waitlist", "Waitlist"),
            ("registration", "Registered"),
            ("cancel", "Cancel"),
            ("noshow", "No Show"),
            ("check_out", "Check Out"),
            ("transfer", "Room Transferred"),
        ],
        string="Rsv Type",
        default="open",
    )

    @api.depends("Rsv_Type")
    def _compute_state(self):
        for record in self:
            if record.Rsv_Type == "open":
                record.state = "open"
            elif record.Rsv_Type == "confirmed":
                record.state = "confirmed"
            elif record.Rsv_Type == "waitlist":
                record.state = "waitlist"
            elif record.Rsv_Type == "registration":
                record.state = "registration"
            elif record.Rsv_Type == "cancel":
                record.state = "cancel"
            else:
                record.state = False

    state = fields.Selection(
        [
            ("open", "Open"),
            ("confirmed", "Confirmed"),
            ("waitlist", "Waitlist"),
            ("registration", "Registered"),
            ("cancel", "Cancel"),
        ],
        string="Rsv Type",
        compute=_compute_state,
    )

    rsv_date = fields.Date("Rsv Date", default=_today_date)

    # guest info
    title = fields.Many2one("hms.namelist", string="Title", readonly=False, store=True)
    guest_name = fields.Char(string="Guest Name")

    def _compute_full_name(self):
        for rec in self:
            if rec.title and rec.guest_name:
                rec.full_name = rec.title.name + " " + rec.guest_name
            elif not rec.title:
                rec.full_name = rec.guest_name
            elif not rec.guest_name:
                rec.full_name = ""
            else:
                rec.full_name = ""

    full_name = fields.Char(compute=_compute_full_name)
    phone = fields.Char("Phone")
    email = fields.Char("Email")
    nric = fields.Char("NRIC")
    passport_no = fields.Char("Passport")
    visa_no = fields.Char("visa No.")
    national = fields.Many2one("hms.national", string="Nationality")
    date_of_birth = fields.Date("DOB")
    gender = fields.Selection(
        [("male", "Male"), ("female", "Female"), ("na", "NA")], default="male"
    )
    contact_person = fields.Char("Contact Person")
    contact_phone = fields.Char("Contact Phone")
    guest_key = fields.Integer("Guest ID")
    package_id = fields.Char(string="Group", search=True)
    package_key = fields.Integer("Group ID")
    deposit = fields.Float("Deposit")
    payment_status = fields.Selection(
        [("partial ", "Partial Paid "), ("paid", "Paid"), ("pending", "Unpaid")]
    )
    payment_ref = fields.Char("Payment Refs")

    group_id = fields.Char(string="Group", search=True)
    agent_id = fields.Many2one("hmslite.agentsetup", "Agent", search=True)
    company_id = fields.Many2one("hmslite.companysetup", "Company", search=True)
    master_room = fields.Boolean("Master Room", default=False)

    group_key = fields.Integer("Group ID")
    group_bk_ref = fields.Char(string="Booking Ref")
    group_flag = fields.Boolean("Group Flag", default=False)

    # guest tab section
    guestinfo_name = fields.Char(string="Name")
    guestinfo_key = fields.Integer(string="Guest ID")
    guestinfo_nric = fields.Char("NRIC")
    guestinfo_passport_no = fields.Char("Passport")
    guestinfo_visa_no = fields.Char("Visa No.")
    guestinfo_phone = fields.Char("Phone")
    guestinfo_email = fields.Char("Email")
    guestinfo_dob = fields.Date("Date of Birth", tracking=True)
    guestinfo_gender = fields.Selection(
        [("male", "Male"), ("female", "Female"), ("na", "NA")], string="Gender"
    )
    guestinto_nationality = fields.Many2one("hms.national", string="Nationality")

    form_type = fields.Selection(
        [
            ("registration", "registration"),
            ("reservation", "reservation"),
        ],
        String="Form Type",
    )
    remark = fields.Html(string="Remark")

    # bc_config_id = fields.Many2one('bc_config', string="BC Config")
    bc_group_name = fields.Char(string="Group Name")
    bc_nrc = fields.Char(string="NRC")
    bc_passport = fields.Char(string="Passport")
    bc_agent = fields.Char(string="Agent")
    bc_company = fields.Char(string="Company")
    """
    field names for reload_settings to change the timeline view
    """
    isGuestNameChecked = fields.Char("Guest Name Checked?", compute=reload_settings)
    isIdChecked = fields.Char("ID Checked?", compute=reload_settings)
    isGroupNameChecked = fields.Char("Group Name Checked?", compute=reload_settings)
    isAgentChecked = fields.Char("Agent Name Checked?", compute=reload_settings)
    isCompanyChecked = fields.Char("Company Name Checked?", compute=reload_settings)
    isPhoneChecked = fields.Char("Company Phone Checked?", compute=reload_settings)
    backdate_allow = fields.Char("Backdate")
    check_out_time = fields.Integer(
        "Check Out Hour", compute=reload_settings, default=12
    )

    total_pax_count = fields.Char(compute="_compute_total_pax_count")
    concatenated_field = fields.Char(compute="_compute_concatenated_field")
    cancellation_fee = fields.Float(compute="_compute_cancellation_fee")

    def _compute_cancellation_fee(self):
        for rec in self:
            rec.cancellation_fee = 0
            trans_line = self.env["hms.trans.line"].search(
                [("resv_id", "=", rec.id)], limit=1
            )
            if trans_line:
                rec.cancellation_fee = (
                    trans_line.trans_price
                    + trans_line.service
                    + trans_line.tax
                    - trans_line.discount
                )

    def _compute_total_pax_count(self):
        for record in self:
            record.total_pax_count = record.adult + (record.child)

    def _compute_concatenated_field(self):
        for record in self:
            if record.guest_name:
                record.concatenated_field = (
                    f"{record.full_name} - {record.total_pax_count}"
                )
            else:
                record.concatenated_field = ""

    # button no save
    trigger_field = fields.Char()
    group_summary = fields.Text("Group Summary", default="group_summary_calculation")
    group_summary_ids = fields.Text(
        "Group Summary List", default="_group_summary_list_calculation"
    )

    # hide delete button
    num_1 = fields.Char("main", default="1")

    # group_reservation
    gpreserve_id = fields.Many2one("hms.groupreserve")
    gpreserve_flag = fields.Boolean("Group Flag", default=False)
    change_room_type = fields.Many2one(
        "hms.room.type", default=_default_room_type, groupby=False
    )
    master = fields.Boolean(string="Master Room", default=False)

    @api.model
    def get_guests_arriving_today(self):
        today = datetime.today()
        start_of_day = datetime.combine(today, time.min)
        end_of_day = datetime.combine(today, time.max)
        guests_today = self.search(
            [
                ("arrival", ">=", start_of_day),
                ("arrival", "<=", end_of_day),
                ("Rsv_Type", "!=", "registration"),
            ]
        )
        return guests_today

    def get_fields_to_ignore_in_search(self):
        return ["change_room_type", "num_1"]

    @api.model
    def download_data_to_excel(self):
        # Arrival Excel
        arrival_guest_data = self.env["hotel.reservation"].get_guests_arriving_today()

        dir_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        file_path1 = os.path.join(dir_path, "Arrival Guests List.xlsx")

        arrival_workbook = xlsxwriter.Workbook(file_path1)
        arrival_worksheet = arrival_workbook.add_worksheet()
        arrival_worksheet.set_column("A:H", 20)

        arrival_header_data = [
            "Rsv No.",
            "Guest Name",
            "Arrival",
            "Departure",
            "Room Type",
            "Room No.",
            "Room Rate",
            "Special Request",
        ]
        cell_format = arrival_workbook.add_format({"bold": True, "bg_color": "#D3D3D3"})
        arrival_worksheet.write_row(0, 0, arrival_header_data, cell_format)

        datetime_format = arrival_workbook.add_format({"num_format": "dd/mm/yy hh:mm"})
        user_tz = pytz.timezone(self.env.user.tz)

        for row, record in enumerate(arrival_guest_data):
            arrival_worksheet.write(row + 1, 0, record.name)
            arrival_worksheet.write(row + 1, 1, record.guest_name)
            arrival_worksheet.write(
                row + 1,
                2,
                record.arrival.astimezone(user_tz).replace(tzinfo=None),
                datetime_format,
            )
            arrival_worksheet.write(
                row + 1,
                3,
                record.departure.astimezone(user_tz).replace(tzinfo=None),
                datetime_format,
            )
            arrival_worksheet.write(row + 1, 4, record.room_type.name)
            arrival_worksheet.write(row + 1, 5, record.room_no.name)
            arrival_worksheet.write(row + 1, 6, record.amount)
            arrival_worksheet.write(
                row + 1, 7, re.sub("<[^<]+?>", "", record.special_request)
            )
        arrival_workbook.close()

        # In House Registration Excel
        in_house_guest_data = self.env["hms.registration"].search([])
        file_path2 = os.path.join(dir_path, "In House Guests List.xlsx")

        in_house_workbook = xlsxwriter.Workbook(file_path2)
        in_house_worksheet = in_house_workbook.add_worksheet()
        in_house_worksheet.set_column("A:H", 20)

        in_house_header_data = [
            "Rsv No.",
            "Guest Name",
            "Arrival",
            "Departure",
            "Room Type",
            "Room No.",
            "Room Rate",
        ]
        cell_format = in_house_workbook.add_format(
            {"bold": True, "bg_color": "#D3D3D3"}
        )
        in_house_worksheet.write_row(0, 0, in_house_header_data, cell_format)

        datetime_format = in_house_workbook.add_format({"num_format": "dd/mm/yy hh:mm"})

        for row, record in enumerate(in_house_guest_data):
            in_house_worksheet.write(row + 1, 0, record.name)
            in_house_worksheet.write(row + 1, 1, record.guest_name)
            in_house_worksheet.write(
                row + 1,
                2,
                record.reg_arrival.astimezone(user_tz).replace(tzinfo=None),
                datetime_format,
            )
            in_house_worksheet.write(
                row + 1,
                3,
                record.reg_departure.astimezone(user_tz).replace(tzinfo=None),
                datetime_format,
            )
            in_house_worksheet.write(row + 1, 4, record.reg_room_type.name)
            in_house_worksheet.write(row + 1, 5, record.reg_room_no.name)
            in_house_worksheet.write(row + 1, 6, record.reg_amount)
        in_house_workbook.close()

        # No Show Excel
        no_show_guest_data = self.env["hotel.reservation"].search(
            [("arrival", "<", date.today())]
        )
        file_path3 = os.path.join(dir_path, "No Show Guests List.xlsx")

        no_show_workbook = xlsxwriter.Workbook(file_path3)
        no_show_worksheet = no_show_workbook.add_worksheet()
        no_show_worksheet.set_column("A:H", 20)

        no_show_header_data = [
            "Rsv No.",
            "Guest Name",
            "Arrival",
            "Departure",
            "Room Type",
            "Room No.",
            "Room Rate",
        ]
        cell_format = no_show_workbook.add_format({"bold": True, "bg_color": "#D3D3D3"})
        no_show_worksheet.write_row(0, 0, no_show_header_data, cell_format)

        datetime_format = no_show_workbook.add_format({"num_format": "dd/mm/yy hh:mm"})

        for row, record in enumerate(no_show_guest_data):
            no_show_worksheet.write(row + 1, 0, record.name)
            no_show_worksheet.write(row + 1, 1, record.guest_name)
            no_show_worksheet.write(
                row + 1,
                2,
                record.arrival.astimezone(user_tz).replace(tzinfo=None),
                datetime_format,
            )
            no_show_worksheet.write(
                row + 1,
                3,
                record.departure.astimezone(user_tz).replace(tzinfo=None),
                datetime_format,
            )
            no_show_worksheet.write(row + 1, 4, record.room_type.name)
            no_show_worksheet.write(row + 1, 5, record.room_no.name)
            no_show_worksheet.write(row + 1, 6, record.amount)
        no_show_workbook.close()

        # Reservation Excel
        reservation_guest_data = self.env["hotel.reservation"].search([])
        file_path4 = os.path.join(dir_path, "Reservation List.xlsx")

        reservation_workbook = xlsxwriter.Workbook(file_path4)
        reservation_worksheet = reservation_workbook.add_worksheet()
        reservation_worksheet.set_column("A:H", 20)

        reservation_header_data = [
            "Rsv No.",
            "Guest Name",
            "Arrival",
            "Departure",
            "Room Type",
            "Room No.",
            "Room Rate",
        ]
        cell_format = reservation_workbook.add_format(
            {"bold": True, "bg_color": "#D3D3D3"}
        )
        reservation_worksheet.write_row(0, 0, reservation_header_data, cell_format)

        datetime_format = reservation_workbook.add_format(
            {"num_format": "dd/mm/yy hh:mm"}
        )

        for row, record in enumerate(reservation_guest_data):
            reservation_worksheet.write(row + 1, 0, record.name)
            reservation_worksheet.write(row + 1, 1, record.guest_name)
            reservation_worksheet.write(
                row + 1,
                2,
                record.arrival.astimezone(user_tz).replace(tzinfo=None),
                datetime_format,
            )
            reservation_worksheet.write(
                row + 1,
                3,
                record.departure.astimezone(user_tz).replace(tzinfo=None),
                datetime_format,
            )
            reservation_worksheet.write(row + 1, 4, record.room_type.name)
            reservation_worksheet.write(row + 1, 5, record.room_no.name)
            reservation_worksheet.write(row + 1, 6, record.amount)
        reservation_workbook.close()

        # Guests Names Excel
        guest_guest_data = self.env["hotel.guest"].search([])
        file_path5 = os.path.join(dir_path, "Guests List.xlsx")

        guest_workbook = xlsxwriter.Workbook(file_path5)
        guest_worksheet = guest_workbook.add_worksheet()
        guest_worksheet.set_column("A:H", 20)

        guest_header_data = [
            "Guest Name",
            "Phone",
            "Email",
            "Passport",
            "ID",
            "Gender",
            "Date of Birth",
        ]
        cell_format = guest_workbook.add_format({"bold": True, "bg_color": "#D3D3D3"})
        guest_worksheet.write_row(0, 0, guest_header_data, cell_format)

        datetime_format = guest_workbook.add_format({"num_format": "dd/mm/yy"})

        for row, record in enumerate(guest_guest_data):
            guest_worksheet.write(row + 1, 0, record.name)
            guest_worksheet.write(row + 1, 1, record.phone)
            guest_worksheet.write(row + 1, 2, record.email_from)
            guest_worksheet.write(row + 1, 3, record.passport_no)
            guest_worksheet.write(row + 1, 4, record.visa_no)
            guest_worksheet.write(row + 1, 5, record.id_no)
            guest_worksheet.write(row + 1, 6, record.gender)
            guest_worksheet.write(
                row + 1,
                7,
                record.date_of_birth if record.date_of_birth else "",
                datetime_format,
            )
        guest_workbook.close()

        # List of Excel files in the directory
        excel_files = [f for f in os.listdir(dir_path) if f.endswith(".xlsx")]

        # Zip file name
        zip_file_name = os.path.join(dir_path, "excel_files.zip")

        # Create the zip file and add the Excel files to it
        with pyzipper.AESZipFile(
            zip_file_name,
            mode="w",
            compression=pyzipper.ZIP_DEFLATED,
            encryption=pyzipper.WZ_AES,
        ) as zip_file:
            zip_file.setpassword(b"mypassword")
            for excel_file in excel_files:
                zip_file.write(os.path.join(dir_path, excel_file), excel_file)

        os.remove(file_path1)
        os.remove(file_path2)
        os.remove(file_path3)
        os.remove(file_path4)
        os.remove(file_path5)

    # modified create function
    @api.model
    def create(self, vals):
        today = str(date.today())
        date_format = date.today().strftime("%Y%m%d")
        config_gpname = self.env["ir.config_parameter"].get_param("hotelia.gn", " ")
        config_nrc = self.env["ir.config_parameter"].get_param("hotelia.nrc", " ")
        config_passport = self.env["ir.config_parameter"].get_param(
            "hotelia.passport", " "
        )
        config_agent = self.env["ir.config_parameter"].get_param("hotelia.agent", " ")
        config_company = self.env["ir.config_parameter"].get_param(
            "hotelia.company", " "
        )
        arrival_date = False
        if "arrival_date" in vals:
            arrival_date = vals["arrival_date"]
        if "departure_date" in vals:
            departure_date = vals["departure_date"]

        new_date = datetime.now() + timedelta(hours=6, minutes=30)
        current_hour = new_date.time().hour
        backdate_allow = self.env["ir.config_parameter"].get_param(
            "hotelia.backdate_allow", ""
        )
        if not backdate_allow:
            if current_hour > self.check_out_time:
                if str(arrival_date) < str(today):
                    raise ValidationError(_("Arrival Date should not be backdate."))

        if str(departure_date) < str(arrival_date):
            raise ValidationError(
                _("Departure Date should not be less than Arrival Date.")
            )

        if "room_no" in vals:
            reg_no = self.env["hms.registration"].search_count(
                [
                    ("arrival_date", "<=", arrival_date),
                    ("departure_date", ">", arrival_date),
                    ("reg_room_no", "=", vals["room_no"]),
                ]
            )
            rsv_no = self.env["hotel.reservation"].search_count(
                [
                    ("arrival_date", "<=", arrival_date),
                    ("departure_date", ">", arrival_date),
                    ("room_no", "=", vals["room_no"]),
                ]
            )
            # if reg_no > 0 and rsv_no > 0:
            #     raise ValidationError(_("This room already reserved or registered"))
        if vals.get("form_type") == "reservation":
            if "arrival":
                vals["intial_arrival_date"] = vals["arrival"]
            if "departure":
                vals["intial_departure_date"] = vals["departure"]
            if vals.get("name", _("TBA")) == _("TBA"):
                sql = "select coalesce(max(sequence),0)+1 from hotel_reservation "
                self.env.cr.execute(sql)
                result = self.env.cr.fetchall()
                vals["sequence"] = result[0][0]
                sequence_number = str(result[0][0])
                if len(str(result[0][0])) == 1:
                    sequence_number = "00" + str(result[0][0])
                if len(str(result[0][0])) == 2:
                    sequence_number = "0" + str(result[0][0])
                if len(str(result[0][0])) > 2:
                    sequence_number = str(result[0][0])
                vals["name"] = sequence_number
                vals["gpreserve_id"] = vals.get("group_key")
                print(f'{vals["gpreserve_id"]}---{vals.get("group_key")}---vals')
                guest_info_arr = [
                    (
                        0,
                        0,
                        {
                            "name": vals["guest_name"],
                            "nationality": vals["national"],
                            "nrc": vals["nric"],
                            "email": vals["email"],
                            "phone": vals["phone"],
                            "gender": vals["gender"],
                            "date_of_birth": vals["date_of_birth"],
                        },
                    )
                ]
                if vals["guest_ids"]:
                    for guest in vals["guest_ids"]:
                        guest_info_arr.append(guest)

                vals["guest_ids"] = guest_info_arr

                if not vals.get("type"):
                    vals["type"] = 2

        reservation_obj = super(ReseRvation, self).create(vals)
        summary_list = []
        if reservation_obj.gpreserve_id:
            sql = (
                """SELECT room_type, COUNT(room_type) from hotel_reservation WHERE gpreserve_id=%s GROUP BY room_type
                    """
                % reservation_obj.gpreserve_id.id
            )
            self.env.cr.execute(sql)
            results = self.env.cr.fetchall()
            for result in results:
                room_name = (
                    self.env["hms.room.type"].search([("id", "=", result[0])]).name
                )
                room_type = {
                    "room_type": room_name,
                    "count": str(result[1]),
                }
                summary_list.append(room_type)

        group_summary_lines = []
        if reservation_obj.gpreserve_id:
            group_reservation_list = self.env["hotel.reservation"].search(
                [("gpreserve_id", "=", reservation_obj.gpreserve_id.id)]
            )
            for reservation in group_reservation_list:
                print(f"{reservation} --resveer")
                resv = {
                    "reservation": reservation.name,
                    "guest_name": reservation.guest_name,
                    "group": reservation.gpreserve_id.name,
                    "room_type": reservation.room_type.name,
                }
                group_summary_lines.append(resv)
                print(f"{group_summary_lines} --summary")
        reservation_obj.write(
            {
                "group_summary_ids": str(group_summary_lines),
                "group_summary": str(summary_list),
            }
        )
        print(f"{reservation_obj} ---reservation")
        return reservation_obj

    def write(self, vals):
        today = str(date.today())
        # arrival_date = False
        # rsv_type = False
        if "Rsv_Type" in vals:
            rsv_type = vals["Rsv_Type"]
        else:
            rsv_type = self.Rsv_Type
        if "arrival_date" in vals:
            arrival_date = vals["arrival_date"]
            backdate_allow = self.env["ir.config_parameter"].get_param(
                "hotelia.backdate_allow", ""
            )
            if not backdate_allow:
                if rsv_type != "registration":
                    if datetime.now().time().hour > 12:
                        if str(arrival_date) < str(today):
                            raise ValidationError(
                                _("Arrival Date should not be backdate.")
                            )
        else:
            arrival_date = self.arrival_date
        if "departure_date" in vals:
            departure_date = vals["departure_date"]
            if rsv_type != "registration":
                if str(departure_date) < str(arrival_date):
                    raise ValidationError(
                        _("Departure Date should not be less than Arrival Date.")
                    )

        if "room_no" in vals:
            reg_with_this = self.env["hms.registration"].search(
                [("reservation_id", "=", self.id)], limit=1
            )
            reg_no = self.env["hms.registration"].search_count(
                [
                    ("arrival_date", "<=", arrival_date),
                    ("departure_date", ">", arrival_date),
                    ("reg_room_no", "=", vals["room_no"]),
                    ("id", "!=", reg_with_this.id),
                ]
            )
            rsv_no = self.env["hotel.reservation"].search_count(
                [
                    ("arrival_date", "<=", arrival_date),
                    ("departure_date", ">", arrival_date),
                    ("room_no", "=", vals["room_no"]),
                ]
            )
            if (
                reg_no > 0
                and rsv_no > 0
                and vals["room_no"] != self.room_no.id
                and reg_with_this.Rsv_Type == "registration"
                and not reg_with_this.transaction_id
            ):
                raise ValidationError(_("This room already reserved or registered"))
        # add group id
        group_val = False
        guest_val = " "
        guest_val_nationality = None
        guest_val_nrc = ""
        guest_val_phone = ""
        guest_val_email = " "
        guest_val_gender = False
        guest_val_dob = date.today()
        guest_update = False
        guest_info = {}
        config_gpname = self.env["ir.config_parameter"].get_param("hotelia.gn", " ")
        config_nrc = self.env["ir.config_parameter"].get_param("hotelia.nrc", " ")
        config_passport = self.env["ir.config_parameter"].get_param(
            "hotelia.passport", " "
        )
        config_agent = self.env["ir.config_parameter"].get_param("hotelia.agent", " ")
        config_company = self.env["ir.config_parameter"].get_param(
            "hotelia.company", " "
        )
        if "guest_name" in vals:
            guest_val = vals.get("guest_name")
            guest_update = True
            guest_info["name"] = vals.get("guest_name")
        else:
            guest_val = self.guest_name
        if "national" in vals:
            guest_update = True
            guest_val_nationality = vals.get("national")
            guest_info["national"] = vals.get("national")
        else:
            guest_val_nationality = self.national.id

        if "nric" in vals:
            guest_update = True
            guest_val_nrc = vals.get("nric")
            guest_info["id_no"] = vals.get("nric")
        else:
            guest_val_nrc = self.nric

        if "phone" in vals:
            guest_update = True
            guest_val_phone = vals.get("phone")
            guest_info["phone"] = vals.get("phone")
        else:
            guest_val_phone = self.phone

        if "email" in vals:
            guest_update = True
            guest_val_email = vals.get("email")
            guest_info["email_from"] = vals.get("email")
        else:
            guest_val_email = self.email

        if "gender" in vals:
            guest_update = True
            guest_val_gender = vals.get("gender")
            guest_info["gender"] = vals.get("gender")
        else:
            guest_val_gender = self.gender

        if "passport_no" in vals:
            guest_update = True
            passport_no = vals.get("passport_no")
            guest_info["passport_no"] = vals.get("passport_no")
        else:
            passport_no = self.passport_no

        if "visa_no" in vals:
            guest_update = True
            visa_no = vals.get("visa_no")
            guest_info["visa_no"] = vals.get("visa_no")
        else:
            visa_no = self.visa_no

        if "date_of_birth" in vals:
            guest_update = True
            guest_val_dob = vals.get("date_of_birth")
            guest_info["date_of_birth"] = vals.get("date_of_birth")
        else:
            guest_val_dob = date.today()
        if "group_id" in vals:
            group_val = vals.get("group_id")
        else:
            group_val = self.group_id

        arrvial_val = depature_val = room_type_val = room_no_val = False

        if "arrival" in vals:
            vals["intial_arrival_date"] = vals["arrival"]
        if "departure" in vals:
            vals["intial_departure_date"] = vals["departure"]

        if "arrival" in vals:
            arrvial_val = vals["arrival"]
        else:
            arrvial_val = self.arrival

        if "departure" in vals:
            depature_val = vals["departure"]
        else:
            depature_val = self.departure

        if "room_type" in vals:
            room_type_val = vals["room_type"]
        else:
            room_type_val = self.room_type.id

        if "room_no" in vals:
            room_no_val = vals["room_no"]
        else:
            room_no_val = self.room_no.id
        reservation_obj = super(ReseRvation, self).write(vals)
        group_reservation = self.env["hotel.reservation"].search([("id", "=", self.id)])
        guestline_info = self.env["hms.guestline"].search(
            [("reservation_id", "=", self.id)]
        )
        if guestline_info:
            # update_guest = f"UPDATE hms_guestline SET name='{guest_val}',nationality={guest_val_nationality if int(guest_val_nationality) else 'NULL'},nrc='{guest_val_nrc if (guest_val_nrc) else ' '}', phone='{guest_val_phone if (guest_val_phone) else ' '}',email='{guest_val_email if (guest_val_email) else ' '}',gender='{guest_val_gender}', date_of_birth='{guest_val_dob}' WHERE reservation_id={self.id} and num_1='2'"
            # self.env.cr.execute(update_guest)
            g_update = (
                self.env["hotel.guest"].sudo().search([("id", "=", self.guest_key)])
            )
            if guest_update == True:
                g_update.write(guest_info)

        # Reconsider overbook for all same (room_no,room_type,arrival, departure) reservations
        total_room_count = self.env["hms_room_setup"].search_count(
            [("room_type", "=", room_type_val), ("room_status", "=", "v_clean")]
        )

        toal_reserve_count = self.env["hotel.reservation"].search_count(
            [
                ("room_type", "=", room_type_val),
                ("arrival", "<=", arrvial_val),
                ("departure", ">=", arrvial_val),
            ]
        )
        toal_unassigned_count = self.env["hotel.reservation"].search_count(
            [
                ("room_type", "=", room_type_val),
                ("arrival", "<=", arrvial_val),
                ("departure", ">=", arrvial_val),
                ("room_no", "=", False),
            ]
        )

        total_assigned_overbook_count = self.env["hotel.reservation"].search_count(
            [
                ("room_type", "=", room_type_val),
                ("arrival", "<=", arrvial_val),
                ("departure", ">=", arrvial_val),
                ("room_no", "!=", False),
                ("overbook", "=", True),
            ]
        )
        # # overbook for unassigned reservations calculation formula is "total reservation count on today for same room type - total room count - total overbook count for assigned rooms(this is to shift for available unassigned count)
        overbook_limit = (
            toal_reserve_count - total_room_count - total_assigned_overbook_count
        )
        # this case is for total_assigned_overbook_count is over overbook_limit this means that no over book for unassigned count
        if overbook_limit < 0:
            overbook_limit = 0
        # this is to consider non overbook limit
        # if overbook limit is zero all unassigned reservation will be non-overbook
        non_overbook_limit = toal_reserve_count - overbook_limit
        # to change latest unassigned reservation to overbook
        overbook_reservation_arr = self.env["hotel.reservation"].search(
            [
                ("room_type", "=", room_type_val),
                ("arrival", "<=", arrvial_val),
                ("departure", ">=", arrvial_val),
                ("room_no", "=", False),
            ],
            order="id desc",
            limit=overbook_limit,
        )
        # to change firstly unassigned reservation to non-overbook
        non_overbook_reservation_arr = self.env["hotel.reservation"].search(
            [
                ("room_type", "=", room_type_val),
                ("arrival", "<=", arrvial_val),
                ("departure", ">=", arrvial_val),
                ("room_no", "=", False),
            ],
            order="id asc",
            limit=non_overbook_limit,
        )
        return reservation_obj

    # compute function form amount field
    @api.depends(
        "room_type",
        "customer_type",
        "extra_bed",
        "breakfast",
        "currency",
        "arrival_date",
    )
    def _compute_room_amount(self):
        for guest in self:
            rateData = self.env["hms_room_rate"].search(
                [
                    ("room_type", "=", guest.room_type.id),
                    ("customer_type", "=", guest.customer_type.id),
                    ("currency", "=", guest.currency.id),
                    ("from_date", "<=", guest.arrival_date),
                    ("to_date", ">=", guest.arrival_date),
                ],
                limit=1,
            )
            guest.amount = rateData.room_rate
            # extra bed
            if guest.extra_bed == "0":
                guest.amount = guest.amount
            else:
                guest.amount += rateData.extra_bed * int(guest.extra_bed)
            # break fast
            if rateData.room_type and rateData.rate_type:
                if guest.breakfast:
                    guest.amount += rateData.breakfast

    @api.depends("room_no")
    def _compute_room_type(self):
        room_type_id = (
            self.env["hms.room.type"].search([("function", "=", False)], limit=1).id
        )
        for rec in self:
            print(f"{rec.room_no} ---computing roomtype")
            if rec.room_type:
                rec.room_type = rec.room_type.id
            else:
                rec.room_type = room_type_id
            if rec.room_no:
                rec.room_type = (
                    self.env["hms_room_setup"]
                    .search([("id", "=", rec.room_no.id)])
                    .room_type.id
                )
                print(f"{rec.room_type} ---get roomtype")

    def _inverse_room_type(self):
        for rec in self:
            if rec.room_no:
                rec.room_type = rec.room_no.room_type
            else:
                rec.room_type = rec.change_room_type
        pass

    @api.onchange("room_type")
    def _onchange_room_type(self):
        self.change_room_type = self.room_type
        if self.room_type and self.room_type != self.room_no.room_type:
            self.room_no = False

    @api.onchange("guest_key")
    def _onchange_guest_name(self):
        for rec in self:
            if rec.guest_key:
                guest_data = self.env["hotel.guest"].search(
                    [("id", "=", rec.guest_key)], order="id desc", limit=1
                )
                if guest_data:
                    rec.guest_name = guest_data.name
                    rec.nric = guest_data.id_no
                    rec.passport_no = guest_data.passport_no
                    rec.visa_no = guest_data.visa_no
                    rec.email = guest_data.email_from
                    rec.phone = guest_data.phone
                    rec.national = guest_data.national
                    rec.title = guest_data.title
                    rec.guest_key = guest_data.id
                    rec.gender = guest_data.gender
                    rec.date_of_birth = guest_data.date_of_birth

    @api.onchange("guestinfo_key")
    def _onchange_guestinfo_name(self):
        for rec in self:
            if rec.guestinfo_key:
                guest_data = self.env["hotel.guest"].search(
                    [("id", "=", rec.guestinfo_key)], order="id desc", limit=1
                )
                if guest_data:
                    rec.guestinfo_name = guest_data.name
                    rec.guestinfo_nric = guest_data.id_no
                    rec.guestinfo_passport_no = guest_data.passport_no
                    rec.guestinfo_visa_no = guest_data.visa_no
                    rec.guestinfo_email = guest_data.email_from
                    rec.guestinfo_phone = guest_data.phone
                    rec.guestinto_nationality = guest_data.national
                    rec.guestinfo_key = guest_data.id
                    rec.guestinfo_gender = guest_data.gender
                    rec.guestinfo_dob = guest_data.date_of_birth

    @api.onchange("trigger_field")
    def add_guestinfo(self):
        for rec in self:
            if rec.guestinfo_name:
                rec.guest_ids = [
                    (
                        0,
                        0,
                        {
                            "name": rec.guestinfo_name,
                            "nationality": rec.guestinto_nationality.id,
                            "nrc": rec.guestinfo_nric,
                            "passport_no": rec.guestinfo_passport_no,
                            "visa_no": rec.guestinfo_visa_no,
                            "email": rec.guestinfo_email,
                            "phone": rec.guestinfo_phone,
                            "date_of_birth": rec.guestinfo_dob,
                            "gender": rec.guestinfo_gender,
                            "guest_id": rec.guestinfo_key,
                            "num_1": "1",
                        },
                    )
                ]
                rec.guestinfo_name = ""
                rec.guestinfo_key = False
                rec.guestinfo_nric = ""
                rec.guestinfo_passport_no = ""
                rec.guestinfo_visa_no = ""
                rec.guestinfo_email = ""
                rec.guestinfo_phone = ""
                rec.guestinto_nationality = False
                rec.guestinfo_dob = ""
                rec.guestinfo_gender = ""
                rec.num_1 = ""

    def action_getReg(self):
        transaction_ids = []
        trans_lines = []
        if self.dayuse == True:
            trans_line_id = self.env["hms.transaction"].search(
                [("name", "=", "Room Charges")]
            )
            trans_info = (
                0,
                0,
                {
                    "trans_lines_id": trans_line_id.id,
                    "trans_price": self.amount,
                    "trans_currency": self.currency.id,
                    "trans_type": "day",
                    "trans_date": date.today(),
                    "reference": "Day Use",
                },
            )
            transaction_ids.append(trans_info)

        if self.package_key:
            trans_lines = (
                self.env["hms.transaction"].sudo().search([("name", "=", "Package")])
            )
            pack_data = self.env["hms.package"].search(
                [("id", "=", self.package_key)], order="id desc", limit=1
            )
            for pdata in pack_data:
                p_info = (
                    0,
                    0,
                    {
                        "trans_lines_id": trans_lines.id,
                        "trans_price": pdata.total_amt,
                        "trans_type": "package",
                        "trans_currency": pdata.currency.id,
                        "reference": pdata.name,
                    },
                )
                transaction_ids.append(p_info)
        if self.deposit == 0.00:
            deposit = 0.00
        elif self.deposit > 0.00:
            deposit = -self.deposit
        type_search = self.env["hms.transaction"].search(
            [("name", "=", "Advance Receipt")]
        )
        if not type_search:
            base_currency = self.env["res.currency"].search(
                [("hotelia_base_currency", "=", True)], limit=1
            )
            company_obj = self.env.user.sudo().company_id
            changed_currency = type_search.currency
            if not changed_currency:
                changed_currency = base_currency
            transaction_create = self.env["hms.transaction"].create(
                {
                    "name": "Advance Receipt",
                    "currency": changed_currency.id,
                }
            )
            product = self.env["product.product"].create(
                {
                    "name": "Advance Receipt",
                    "type": "service",
                    "taxes_id": False,
                    "supplier_taxes_id": False,
                    "sale_ok": False,
                    "purchase_ok": False,
                    "lst_price": deposit,
                }
            )
        trans_lines = (
            self.env["hms.transaction"]
            .sudo()
            .search([("name", "=", "Advance Receipt")])
        )
        if deposit != 0.0:
            trans_info = (
                0,
                0,
                {
                    "trans_lines_id": trans_lines.id,
                    "trans_price": deposit,
                    "trans_type": "payment",
                    "trans_currency": trans_lines.currency.id,
                    "reference": "Deposit Amount",
                },
            )
            transaction_ids.append(trans_info)

        guest_info_list = []
        for g_data in self.guest_ids:
            guest_info = (
                0,
                0,
                {
                    "name": g_data.name,
                    "nationality": g_data.nationality.id,
                    "nrc": g_data.nrc,
                    "passport_no": g_data.passport_no,
                    "visa_no": g_data.visa_no,
                    "email": g_data.email,
                    "phone": g_data.phone,
                    "date_of_birth": g_data.date_of_birth,
                    "gender": g_data.gender,
                    "num_1": g_data.num_1,
                },
            )
            guest_info_list.append(guest_info)

        return {
            "name": _("Registration"),
            "type": "ir.actions.act_window",
            "view_type": "form",
            "view_mode": "form",
            "res_model": "hms.registration",
            "context": {
                "default_reg_amount": self.amount,
                "default_reg_departure": self.departure,
                "default_reg_room_rate": self.room_rate,
                "default_reg_customer_type": self.customer_type.id,
                "default_reg_room_type": self.room_type.id,
                "default_reg_room_no": self.room_no.id,
                "default_reg_amount": self.amount,
                "default_reg_currency": self.currency.id,
                "default_reg_extra_bed": self.extra_bed,
                "default_dayuse": self.dayuse,
                "default_reg_breakfast": self.breakfast,
                "default_reg_adult": self.adult,
                "default_reg_child": self.child,
                "default_reg_group_id": self.group_id,
                "default_package_id": self.package_id,
                "default_reg_agent_id": self.agent_id.id,
                "default_reg_company_id": self.company_id.id,
                "default_group_key": self.gpreserve_id.id,
                "default_reg_group_flag": self.group_flag,
                "default_Rsv_Type": "registration",
                "default_guest_name": self.guest_name,
                "default_guest_name_testing": self.guest_name,
                "default_title": self.title.id,
                "default_phone": self.phone,
                "default_email": self.email,
                "default_nric": self.nric,
                "default_date_of_birth": self.date_of_birth,
                "default_gender": self.gender,
                "default_passport_no": self.passport_no,
                "default_visa_no": self.visa_no,
                "default_national": self.national.id,
                "default-contact_person": self.contact_person,
                "default_guest_key": self.guest_key,
                "default_package_key": self.package_key,
                "default_deposit": self.deposit,
                # "default_package": self.package.id,
                "default_payment_status": self.payment_status,
                "default_payment_ref": self.payment_ref,
                "default_remark": self.remark,
                "default_special_request": self.special_request,
                "default_reservation_id": self.id,
                "default_guest_ids": guest_info_list,
                "default_contact_person": self.contact_person,
                "default_contact_phone ": self.contact_phone,
                "default_reg_customer_type": self.customer_type.id,
                "default_transaction_id": transaction_ids,
            },
        }

    def action_get_reserve(self):
        for rec in self:
            return {
                "name": "Reservations",
                "type": "ir.actions.act_window",
                "view_type": "form",
                "view_mode": "form",
                "res_model": "hotel.reservation",
                "res_id": self.id,
            }

    def show_booking_chart(self):
        for rec in self:
            return {
                "name": "Booking Chart",
                "type": "ir.actions.act_window",
                "view_type": "timeline",
                "view_mode": "timeline",
                "res_model": "hotel.reservation",
                "view_id": self.env.ref(
                    "hotelia.reservation_timeline_booking_chart"
                ).id,
            }

    def name_get(self):
        res = []
        fname = ""
        for rec in self:
            if rec.name:
                fname = "Rsv" + str(rec.name)
                res.append((rec.id, fname))
        return res

    @api.onchange("group_key")
    def _onchange_group_name(self):
        for rec in self:
            if rec.group_key:
                rec.gpreserve_id = rec.group_key
                group_data = self.env["hms.groupreserve"].search(
                    [("id", "=", rec.group_key)], order="id desc"
                )
                if group_data:
                    rec.group_id = group_data.name
                    rec.group_key = group_data.id
                    rec.group_bk_ref = group_data.book_ref
                    rec.agent_id = group_data.gr_agent_id.id
                    rec.company_id = group_data.gr_company_id.id
                    rec.company_id = group_data.gr_company_id.id
                    # rec.arrival = group_data.gr_arrival
                    # rec.departure = group_data.gr_departure

    @api.onchange("package_key")
    def _onchange_package_name(self):
        for rec in self:
            if rec.package_key:
                pack_data = self.env["hms.package"].search(
                    [("id", "=", rec.package_key)], order="id desc", limit=1
                )
                if pack_data:
                    rec.package_id = pack_data.name
                    rec.package_key = pack_data.id

    @api.onchange("gpreserve_id", "guest_name", "room_type")
    def _group_summary_list_calculation(self):
        # if self.gr_add_flag:
        group_summary_lines = []
        gp_reserve_ids = []
        if self.gpreserve_id.id:
            group_reservation_list = self.env["hotel.reservation"].search(
                [("gpreserve_id", "=", self.gpreserve_id.id)]
            )
            for reservation in group_reservation_list:
                guest_name = reservation.guest_name
                room_type = reservation.room_type.name
                if reservation.name == self.name:
                    guest_name = self.guest_name
                    room_type = self.room_type.name
                resv = {
                    "reservation": reservation.name,
                    "guest_name": guest_name,
                    "group": reservation.gpreserve_id.name,
                    "room_type": room_type,
                }
                group_summary_lines.append(resv)
                gp_reserve_ids.append(reservation.id)
            if self._origin.id not in gp_reserve_ids:
                group_summary_lines.append(
                    {
                        "reservation": self.name,
                        "guest_name": self.guest_name,
                        "group": self.gpreserve_id.name,
                        "room_type": self.room_type.name,
                    }
                )
            for reservation in group_reservation_list:
                reservation.write({"group_summary_ids": str(group_summary_lines)})
        if not self.gpreserve_id.id:
            group_reservation_list = self.env["hotel.reservation"].search(
                [("gpreserve_id", "=", False)]
            )
            for reservation in group_reservation_list:
                resv = {
                    "reservation": reservation.name,
                    "guest_name": reservation.guest_name,
                    "group": reservation.gpreserve_id.name,
                    "room_type": reservation.room_type.name,
                }
                group_summary_lines.append(resv)
        self.group_summary_ids = str(group_summary_lines)

    @api.onchange("gpreserve_id", "guest_name")
    def group_summary_calculation(self):
        if self.gpreserve_id.id:
            summary_list = []
            sql = (
                """
                SELECT room_type, COUNT(room_type) from hotel_reservation WHERE gpreserve_id=%s GROUP BY room_type
                """
                % self.gpreserve_id.id
            )
            self.env.cr.execute(sql)
            results = self.env.cr.fetchall()
            for result in results:
                room_name = (
                    self.env["hms.room.type"].search([("id", "=", result[0])]).name
                )
                room_type = {
                    "room_type": room_name,
                    "count": str(result[1]),
                }
                summary_list.append(room_type)
            self.group_summary = str(summary_list)

        if not self.gpreserve_id.id:
            summary_list_no = []
            results = self.env["hms.room.type"].search([])
            for result in results:
                room_count = self.env["hms_room_setup"].search_count(
                    [("room_type", "=", result.id)]
                )

                room_type = {
                    "room_type": result.name,
                    "count": str(room_count),
                }
                summary_list_no.append(room_type)
            self.group_summary = str(summary_list_no)

    def compute_daterange(self, month, year=datetime.now().year):
        """
        Give a month as an integer.\n
        Compute the first and last dates of that month.\n
        Return a tuple containing the first date and last date.
        """
        current_year = year
        first_date = date(current_year, month, 1)

        if month == 12:
            next_month = 1
            next_year = current_year + 1
        else:
            next_month = month + 1
            next_year = current_year

        last_date = date(next_year, next_month, 1) - timedelta(days=1)

        return (first_date, last_date)

    def total_reservation(self, current_month=datetime.now().month):
        fast_date, last_date = self.compute_daterange(month=current_month)
        total_booking_count = self.env["hotel.reservation"].search_count(
            [
                ("create_date", ">=", fast_date),
                ("create_date", "<=", last_date),
            ]
        )
        reservation_count = self.env["hotel.reservation"].search_count(
            [
                ("create_date", ">=", fast_date),
                ("create_date", "<=", last_date),
                (
                    "Rsv_Type",
                    "!=",
                    "registration",
                ),
                (
                    "Rsv_Type",
                    "!=",
                    "cancel",
                ),
            ]
        )
        return reservation_count, total_booking_count

    def total_cancel(self, current_month=datetime.now().month):
        fast_date, last_date = self.compute_daterange(month=current_month)
        cancel_count = self.env["hotel.reservation"].search_count(
            [
                ("create_date", ">=", fast_date),
                ("create_date", "<=", last_date),
                (
                    "Rsv_Type",
                    "=",
                    "cancel",
                ),
            ]
        )
        return cancel_count

    def action_cancel(self):
        return {
            "name": _("Confirmation"),
            "type": "ir.actions.act_window",
            "view_mode": "form",
            "res_model": "cancel.transaction",
            "context": {
                "default_message": _("Do you want to take cancellation fee"),
                "default_resv_id": self.id,
            },
            "target": "new",
        }

    def fields_get(self, allfields=None, attributes=None):
        result = super().fields_get(allfields=allfields, attributes=attributes)
        # fields_to_hide = ['guestinfo_phone','guestinfo_passport_no','num_1',
        #                   'trigger_field','guestinfo_gender','guestinfo_nric','group_summary','group_summary_ids','gpreserve_flag','guestinfo_email',
        #                   'bc_agent','bc_company','bc_group_name','bc_nrc','guest_name', 'change_room_type',
        #                   'master','guestinto_nationality','bc_passport']  # Replace with the field names you want to hide
        fields_to_hide = [
            "guestinfo_key",
            "guestinfo_phone",
            "guestinfo_passport_no",
            "guestinfo_visa_no"
            "guestinfo_gender",
            "guestinfo_email",
            "bc_agent",
            "bc_company",
            "bc_group_name",
            "bc_nrc",
            "guest_name",
            "change_room_type",
            "master",
            "guestinto_nationality",
            "bc_passport",
            "",
        ]  # Replace with the field names you want to hide

        for field_name in fields_to_hide:
            if field_name in result:
                result[field_name]["searchable"] = False
                result[field_name]["sortable"] = False

        return result


class GuestLine(models.Model):
    _name = "hms.guestline"
    _description = "Guest Lines"

    guest_id = fields.Many2one("hotel.guest", string="Guest Name")
    name = fields.Char("Name")
    reservation_id = fields.Many2one("hotel.reservation")
    registration_id = fields.Many2one("hms.registration")
    phone = fields.Char("Phone")
    email = fields.Char("Email")
    nrc = fields.Char("ID")
    passport_no = fields.Char("Passport")
    visa_no = fields.Char("visa No.")
    date_of_birth = fields.Date("Date of Birth")
    gender = fields.Selection([("male", "Male"), ("female", "Female"), ("na", "NA")])
    nationality = fields.Many2one("hms.national", string="Nationality")
    num_1 = fields.Char("main", default="2")
