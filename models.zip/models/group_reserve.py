import datetime
from datetime import datetime, timedelta, date
import pytz
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
import random

global_room_list = []

class GroupReserve(models.Model):
    _name = "hms.groupreserve"
    _description = "Group Reservation Form"
    _order = "id DESC"

    def _tomorrow_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=1)
        return new_date

    def _today_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=0)
        return new_date

    def _default_currency(self):
        currency = False
        currency_id = (
            self.env["res.currency"]
            .search([("hotelia_base_currency", "=", True)], limit=1)
            .id
        )
        if currency_id:
            currency = currency_id
        return currency

    def rooms_count(self):
        for rec in self:
            sup_count = 0
            dcv_count = 0
            dpv_count = 0
            for reservation in rec.reserve_ids:
                if reservation.room_type.name == "Superior":
                    sup_count = sup_count + 1
                if reservation.room_type.name == "Deluxe Pagoda View":
                    dpv_count = dpv_count + 1
                if reservation.room_type.name == "Deluxe City View":
                    dcv_count = dcv_count + 1
            rec.sup_count = sup_count
            rec.dpv_count = dpv_count
            rec.dcv_count = dcv_count

    # button no save
    trigger_field = fields.Char()
    name = fields.Char(string="Group")
    book_ref = fields.Char(string="Booking Refs")
    gr_customer_type = fields.Many2one("hms.customer_type", "Customer Type")
    gr_room_rate = fields.Selection(
        [
            ("ota", "OTA"),
            ("s_foreigner", "Single Foreigner"),
            ("d_local", "Double Local"),
            ("cooperate", "Cooperate"),
            ("company1", "Company"),
        ],
        String="Customer Type",
        default="ota",
        tracking=True,
        translate=True,
    )
    gr_currency = fields.Many2one("res.currency", "Currency", default=_default_currency)
    gr_room_type = fields.Many2one(
        "hms.room.type", String="Room Type", ondelete="set null"
    )
    gr_breakfast = fields.Boolean("Breakfast", default=False)
    gr_agent_id = fields.Many2one("hmslite.agentsetup", "Agent")
    gr_company_id = fields.Many2one("hmslite.companysetup", "Company")
    reserve_ids = fields.One2many("hotel.reservation", "gpreserve_id")
    sequence = fields.Integer("Sequence")
    sup_count = fields.Integer("Superior", compute=rooms_count)
    dpv_count = fields.Integer("Deluxe Pagoda View", compute=rooms_count)
    dcv_count = fields.Integer("Deluxe City View", compute=rooms_count)
    gr_date = fields.Date("Date", readonly=True, default=_today_date)
    """
    Separate datetime fields to date and time
    """
    group_key = fields.Integer()

    def _today_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=0)
        return new_date

    arrival = fields.Datetime(
        "Arrival Date Full",
        compute="_compute_arrival_datetime_field",
        inverse="_reverse_compute_arrival_datetime",
        store=True,
    )
    arrival_date = fields.Date("Arrival Date")
    arrival_time = fields.Float("Ariival Time")
    departure = fields.Datetime(
        "Departure Date Full",
        compute="_compute_departure_datetime_field",
        inverse="_reverse_compute_departure_datetime",
        store=True,
    )
    departure_date = fields.Date("Departure Date", required=True)
    departure_time = fields.Float("Departure Time", required=True)

    assign_room = fields.Boolean('Assign Room', default=False)
    group_room_list = fields.One2many('hms.group.room.list', 'group_reserve', string="Room List", default=lambda self: self._default_room_list(), compute="_compute_group_room_list", store=False)
    room_list_booking = fields.Boolean('Room List Booking', default=False, compute="_compute_room_list_booking")

    @api.depends("arrival_date", "arrival_time")
    def _compute_arrival_datetime_field(self):
        for record in self:
            if record.arrival_date:
                # Extract hour and minute values from float time field
                hour, minutes = divmod(int(record.arrival_time * 60), 60)

                # Create a timezone object from the user's timezone string

                if self._context.get("tz", False):
                    tz_string = pytz.timezone(self._context.get("tz", False))
                else:
                    tz_string = pytz.timezone("UTC")
                    # tz_string = "UTC"
                    user_timezone = pytz.timezone(tz_string)

                    # Create a datetime object with the date and time values
                    arrival_datetime = datetime.combine(
                        record.arrival_date, datetime.min.time()
                    ) + timedelta(hours=hour, minutes=minutes)

                    # Get the UTC offset for the datetime object
                    utc_offset = user_timezone.utcoffset(arrival_datetime)

                    # Convert the UTC offset to hours and minutes
                    utc_offset_hours = int(utc_offset.total_seconds() / 3600)
                    utc_offset_minutes = int((utc_offset.total_seconds() % 3600) / 60)

                    # Adjust the datetime object for the UTC offset and store it in the field
                    record.arrival = arrival_datetime - timedelta(
                        hours=utc_offset_hours, minutes=utc_offset_minutes
                    )

            else:
                # Clear the value of arrival_field
                record.arrival = False

    @api.onchange("arrival")
    def _reverse_compute_arrival_datetime(self):
        for record in self:
            if record.arrival:
                tz_string = self._context.get("tz", False)
                user_timezone = pytz.timezone(tz_string)
                arrival_datetime_utc = record.arrival.replace(tzinfo=pytz.utc)
                arrival_datetime_user_tz = arrival_datetime_utc.astimezone(
                    user_timezone
                )
                my_date = arrival_datetime_user_tz.date()
                my_time = arrival_datetime_user_tz.time()
                my_time_float = my_time.hour + my_time.minute / 60
                record.arrival_date = my_date
                record.arrival_time = my_time_float

    @api.depends("departure_date", "departure_time")
    def _compute_departure_datetime_field(self):
        for record in self:
            if record.departure_date:
                # Extract hour and minute values from float time field
                hour, minutes = divmod(int(record.departure_time * 60), 60)

                # Create a timezone object from the user's timezone string
                tz_string = self._context.get("tz", False)
                user_timezone = pytz.timezone(tz_string)

                # Create a datetime object with the date and time values
                departure_datetime = datetime.combine(
                    record.departure_date, datetime.min.time()
                ) + timedelta(hours=hour, minutes=minutes)

                # Get the UTC offset for the datetime object
                utc_offset = user_timezone.utcoffset(departure_datetime)

                # Convert the UTC offset to hours and minutes
                utc_offset_hours = int(utc_offset.total_seconds() / 3600)
                utc_offset_minutes = int((utc_offset.total_seconds() % 3600) / 60)

                # Adjust the datetime object for the UTC offset and store it in the field
                record.departure = departure_datetime - timedelta(
                    hours=utc_offset_hours, minutes=utc_offset_minutes
                )

            else:
                # Clear the value of arrival_field
                record.departure = False

    @api.onchange("departure")
    def _reverse_compute_departure_datetime(self):
        for record in self:
            if record.departure:
                tz_string = self._context.get("tz", False)
                user_timezone = pytz.timezone(tz_string)

                # Convert departure_datetime_field to a UTC datetime object
                departure_datetime_utc = record.departure.replace(tzinfo=pytz.utc)

                # Convert the UTC datetime object to the user's timezone
                departure_datetime_user_tz = departure_datetime_utc.astimezone(
                    user_timezone
                )

                # Extract the date and time components in the user's timezone
                my_date = departure_datetime_user_tz.date()
                my_time = departure_datetime_user_tz.time()

                # Calculate the float value of the time component
                my_time_float = my_time.hour + my_time.minute / 60

                # print(f"{my_time_float} --time")

                # Store the updated values
                record.departure_date = my_date
                record.departure_time = my_time_float

    def add_group_summary(self):
        reservation = self.sudo().env["hotel.reservation"].search([])
        for rec in reservation:
            group_summary = self.group_summary_calculation(rec.id)
            group_summary_ids = self._group_summary_list_calculation(rec.id)
            rec.write(
                {"group_summary": group_summary, "group_summary_ids": group_summary_ids}
            )

    @api.model
    def create(self, vals):
        # group_key = False
        if vals["group_key"]:
            group_key = vals["group_key"]
        else:
            if self.id:
                group_key = self.id
            else:
                group_key = False
        group_reservation = self.env["hms.groupreserve"].search([("id", "=", group_key)])
        if not group_reservation:
            group_reservation = super(GroupReserve, self).create(vals)
            if group_reservation.arrival == group_reservation.departure:
                raise ValidationError(
                    _("Arrival and Departure date should not be same")
                )
            for reservation in group_reservation.reserve_ids:
                if reservation.Rsv_Type != "registration":
                    if reservation.name == _("TBA"):
                        sql = (
                            "select coalesce(max(sequence),0)+1 from hotel_reservation "
                        )
                        self.env.cr.execute(sql)
                        result = self.env.cr.fetchall()
                        reservation.sequence = result[0][0]
                        sequence_number = str(result[0][0])
                        if len(str(result[0][0])) == 1:
                            sequence_number = "00" + str(result[0][0])
                        if len(str(result[0][0])) == 2:
                            sequence_number = "0" + str(result[0][0])
                        if len(str(result[0][0])) > 2:
                            sequence_number = str(result[0][0])
                        reservation.name = sequence_number
                        reservation.guest_ids = [
                            (
                                0,
                                0,
                                {
                                    "name": reservation.guest_name,
                                },
                            )
                        ]
                        reservation.arrival_date = group_reservation.arrival_date
                        reservation.departure_date = group_reservation.departure_date
                        reservation.arrival_time = group_reservation.arrival_time
                        reservation.departure_time = group_reservation.departure_time
                        reservation.room_type = group_reservation.room_type
                        reservation.group_key = group_key
                        reservation.gpreserve_id = self.id
                        reservation.group_id = self.name

                summary_list = []
                if reservation.gpreserve_id:
                    sql = (
                        """SELECT room_type, COUNT(room_type) from hotel_reservation WHERE gpreserve_id=%s GROUP BY room_type
                                """
                        % reservation.gpreserve_id.id
                    )
                    self.env.cr.execute(sql)
                    results = self.env.cr.fetchall()
                    for result in results:
                        room_name = (
                            self.env["hms.room.type"]
                            .search([("id", "=", result[0])])
                            .name
                        )
                        room_type = {
                            "room_type": room_name,
                            "count": str(result[1]),
                        }
                        summary_list.append(room_type)

                group_summary_lines = []
                if reservation.gpreserve_id:
                    group_reservation_list = self.env["hotel.reservation"].search(
                        [("gpreserve_id", "=", reservation.gpreserve_id.id)]
                    )
                    for reservation1 in group_reservation_list:
                        print(f"{reservation} --resveer")
                        resv = {
                            "reservation": reservation1.name,
                            "guest_name": reservation1.guest_name,
                            "group": reservation1.gpreserve_id.name,
                            "room_type": reservation1.room_type.name,
                        }
                        group_summary_lines.append(resv)
                        print(f"{group_summary_lines} --summary")
                reservation.write(
                    {
                        "group_summary_ids": str(group_summary_lines),
                        "group_summary": str(summary_list),
                    }
                )
        else:
            group_reservation.write(vals)
        return group_reservation

    def write(self, vals):
        group_rsv = super(GroupReserve, self).write(vals)

        group_reservation = self.env['hms.groupreserve'].search([('id', '=', self.id)])
        if group_reservation.arrival == group_reservation.departure:
            raise ValidationError(_("Arrival and Departure date should not be same"))
        if "arrival_date" in vals:
            arrival_date = vals["arrival_date"]
        else:
            arrival_date = self.arrival_date

        if "departure_date" in vals:
            departure_date = vals["departure_date"]
        else:
            departure_date = self.departure_date
        if "arrival_time" in vals:
            arrival_time = vals["arrival_time"]
        else:
            arrival_time = self.arrival_time
        if "departure_time" in vals:
            departure_time = vals["departure_time"]
        else:
            departure_time = self.departure_time
        if "group_key" in vals:
            group_key = vals["group_key"]
        else:
            group_key = self.id

        for reservation in self.reserve_ids:
            rsv_guest_name = reservation.guest_name
            if reservation.Rsv_Type != "registration":
                guestline_id = 0
                if reservation.name == _("TBA"):
                    sql = "select coalesce(max(sequence),0)+1 from hotel_reservation "
                    self.env.cr.execute(sql)
                    result = self.env.cr.fetchall()
                    reservation.sequence = result[0][0]
                    sequence_number = str(result[0][0])
                    if len(str(result[0][0])) == 1:
                        sequence_number = "00" + str(result[0][0])
                    if len(str(result[0][0])) == 2:
                        sequence_number = "0" + str(result[0][0])
                    if len(str(result[0][0])) > 2:
                        sequence_number = str(result[0][0])
                    reservation.name = sequence_number
                    reservation.guest_ids = [
                        (
                            0,
                            0,
                            {
                                "name": reservation.guest_name,
                            },
                        )
                    ]
                reservation.arrival_date = arrival_date
                reservation.arrival_time = arrival_time
                reservation.departure_date = departure_date
                reservation.arrival_time = arrival_time
                reservation.departure_time = departure_time
                reservation.room_type = reservation.room_type
                reservation.gpreserve_id = self.id
                reservation.group_id = self.name
                reservation.group_key = group_key
                guestline_info = self.env["hms.guestline"].search(
                    [("reservation_id", "=", reservation.id), ("num_1", "=", "2")]
                )
                if guestline_info:
                    update_guest = (
                        """UPDATE hms_guestline SET name='%s'  WHERE reservation_id=%s"""
                        % (rsv_guest_name, reservation.id)
                    )
                    self.env.cr.execute(update_guest)
            summary_list = []
            if reservation.gpreserve_id:
                sql = (
                    """SELECT room_type, COUNT(room_type) from hotel_reservation WHERE gpreserve_id=%s GROUP BY room_type
                            """
                    % reservation.gpreserve_id.id
                )
                self.env.cr.execute(sql)
                results = self.env.cr.fetchall()
                # results = self.env['hms.groupreserve'].search([("id","=",self.gpreserve_id.id)])
                for result in results:
                    room_name = (
                        self.env["hms.room.type"].search([("id", "=", result[0])]).name
                    )

                    room_type = {
                        "room_type": room_name,
                        "count": str(result[1]),
                    }
                    summary_list.append(room_type)

            group_summary_lines = []
            if reservation.gpreserve_id:
                group_reservation_list = self.env["hotel.reservation"].search(
                    [("gpreserve_id", "=", reservation.gpreserve_id.id)]
                )
                for reservation1 in group_reservation_list:
                    print(f"{reservation} --resveer")
                    resv = {
                        "reservation": reservation1.name,
                        "guest_name": reservation1.guest_name,
                        "group": reservation1.gpreserve_id.name,
                        "room_type": reservation1.room_type.name,
                    }
                    group_summary_lines.append(resv)
            reservation.write(
                {
                    "group_summary_ids": str(group_summary_lines),
                    "group_summary": str(summary_list),
                }
            )

        return group_rsv

    def unlink(self):
        """
        Overrides orm unlink method.
        @param self: The object pointer
        @return: True/False.
        """
        for line in self:
            if line.reserve_ids:
                rsv_room_lines = self.env["hotel.reservation"].search(
                    [
                        ("gpreserve_id", "=", line.id),
                        ("id", "=", line.reserve_ids.ids),
                    ]
                )
                rsv_room_lines.unlink()
        return super(GroupReserve, self).unlink()

    @api.onchange("trigger_field")
    def add_grinfo(self):
        for rec in self:
            if rec.name:
                reservation_obj = {
                    'arrival': rec.arrival,
                    'departure': rec.departure,
                    'arrival_date': rec.arrival_date,
                    'departure_date': rec.departure_date,
                    'arrival_time': rec.arrival_time,
                    'departure_time': rec.departure_time,
                    # 'currency': rec.gr_currency,
                    'breakfast': rec.gr_breakfast,
                    'room_rate': rec.gr_room_rate,
                    # 'customer_type': rec.gr_customer_type.id,
                    'group_id': rec.name,
                    'gpreserve_id': rec.id,
                    'group_key': rec.id,
                    'agent_id': rec.gr_agent_id.id,
                    'company_id': rec.gr_company_id.id,
                    'room_no': False
                }
                
                if rec.assign_room == True:
                    room_list = rec.group_room_list
                    room_type = False
                    room_reserved = False
                    reserve_room = False

                    for list in room_list:
                        room_reserve_count = 0
                        if list.book > 0:
                            book_count = list.book
                            room_type = list.room_type
                            rooms = self.env['hms_room_setup'].search([('room_type', '=', room_type.id)])
                            
                            while(room_reserve_count!=book_count):
                                for room in rooms:
                                    room_reserved = False
                                    for reservation in rec.reserve_ids:
                                        if reservation.room_no.id == room.id:
                                            room_reserved = True
                                    if room_reserved == False:
                                        reserve_room = room
                                        if reserve_room:
                                            reservation_obj["room_no"] = reserve_room.id
                                            break

                                rec.reserve_ids = [(0, 0, reservation_obj)]
                                room_reserve_count = room_reserve_count + 1
                else:
                    rec.reserve_ids = [(0, 0, {
                    'arrival': rec.arrival,
                    'departure': rec.departure,
                    'arrival_date': rec.arrival_date,
                    'departure_date': rec.departure_date,
                    'group_key': rec.id,
                    'agent_id': rec.gr_agent_id.id,
                    'company_id': rec.gr_company_id.id,
                })]

    def _group_summary_list_calculation(self, resv_id):
        # if self.gr_add_flag:
        resv = self.env["hotel.reservation"].sudo().search([("id", "=", resv_id)])
        group_summary_lines = []
        if resv.gpreserve_id:
            group_reservation_list = self.env["hotel.reservation"].search(
                [("gpreserve_id", "=", resv.gpreserve_id.id)]
            )
            for reservation in group_reservation_list:
                resv = {
                    "reservation": reservation.name,
                    "guest_name": reservation.guest_name,
                    "group": reservation.gpreserve_id.name,
                    "room_type": reservation.room_type.name,
                }
                group_summary_lines.append(resv)
        else:
            group_reservation_list = self.env["hotel.reservation"].search(
                [("gpreserve_id", "=", False)]
            )
            for reservation in group_reservation_list:
                resv = {
                    "reservation": reservation.name,
                    "guest_name": reservation.guest_name,
                    "group": reservation.gpreserve_id.name,
                    "room_type": reservation.room_type.name,
                }
                group_summary_lines.append(resv)
        return group_summary_lines

    def group_summary_calculation(self, resv_id):
        summary_list = []
        resv = self.env["hotel.reservation"].sudo().search([("id", "=", resv_id)])
        if resv.gpreserve_id:
            sql = (
                """
                SELECT room_type, COUNT(room_type) from hotel_reservation WHERE gpreserve_id=%s GROUP BY room_type
                """
                % resv.gpreserve_id.id
            )
            self.env.cr.execute(sql)
            results = self.env.cr.fetchall()
            for result in results:
                room_name = (
                    self.env["hms.room.type"].search([("id", "=", result[0])]).name
                )
                room_type = {
                    "room_type": room_name,
                    "count": str(result[1]),
                }
                summary_list.append(room_type)

        else:
            results = self.env["hms.room.type"].search([])
            for result in results:
                room_count = self.env["hms_room_setup"].search_count(
                    [("room_type", "=", result.id)]
                )

                room_type = {
                    "room_type": result.name,
                    "count": str(room_count),
                }
                summary_list.append(room_type)
        return summary_list

    def copy_group_name(self):
        group_id = 0
        for rec in self:
            group_id = rec.id
        return group_id

    @api.onchange("group_key")
    def _onchange_group_name(self):
        for rec in self:
            if rec.group_key:
                group_data = self.env["hms.groupreserve"].search(
                    [("id", "=", rec.group_key)], order="id desc"
                )
                if group_data:
                    rec.name = group_data.name
                    rec.group_key = group_data.id
                    rec.gr_agent_id = group_data.gr_agent_id.id
                    rec.gr_company_id = group_data.gr_company_id.id

    def _default_room_list(self):
        room_list = []
        room_types = self.env['hms.room.type'].search([])
        for room_type in room_types:
            total_rooms = self.env['hms_room_setup'].search_count([('room_type', '=', room_type.id)])
            available_rooms = self.env['hms_room_setup'].search_count([('room_type', '=', room_type.id), ('room_status', '=', 'v_clean')])
            room_rate = self.env['hms_room_rate'].search([('room_type', '=', room_type.id)])
            room_rate_text = ""
            for rate in room_rate:
                if not room_rate_text == "":
                    room_rate_text += ", "
                room_rate_text += str(rate.room_rate) + " " + rate.currency.name
            # room_list.append(
            #     (0, 0, {})
            # )
            list = self.env["hms.group.room.list"].create({
                'room_type': room_type.id,
                'total_rooms': total_rooms,
                'available_rooms': available_rooms,
                'room_rate': room_rate_text,
                'group_reserve': self.id
            })
            room_list.append(list.id)
        global global_room_list
        global_room_list = room_list
        return global_room_list


    @api.depends("assign_room")
    def _compute_group_room_list(self):
        for record in self:
            global global_room_list
            if record.assign_room == True:
                group_reserve_id = record.id if record.id else record.id.origin
                if group_reserve_id:
                    # room_list = self.env['hms.group.room.list'].search([('group_reserve','=',group_reserve_id)])
                    room_list = global_room_list
                    group_room_list = []
                    if room_list:
                        room_types = self.env['hms.room.type'].search([])
                        for room_type in room_types:
                            total_rooms = self.env['hms_room_setup'].search_count([('room_type', '=', room_type.id)])
                            available_rooms = self.env['hms_room_setup'].search_count([('room_type', '=', room_type.id), ('room_status', '=', 'v_clean')])
                            room_rate = self.env['hms_room_rate'].search([('room_type', '=', room_type.id)])
                            room_rate_text = ""
                            for rate in room_rate:
                                if not room_rate_text == "":
                                    room_rate_text += ", "
                                room_rate_text += str(rate.room_rate) + " " + rate.currency.name
                            for list_id in room_list:
                                list = self.env['hms.group.room.list'].search([('id', '=', list_id)])
                                if list.room_type == room_type:
                                    list.write({
                                    "total_rooms": total_rooms,
                                    "available_rooms": available_rooms,
                                    "room_rate": room_rate_text,
                                    "group_reserve": group_reserve_id
                                })
                        record.group_room_list = room_list
                    else:
                        global_room_list = record._default_room_list()
                        record.group_room_list = global_room_list
                else:
                    global_room_list = record._default_room_list()
                    record.group_room_list = global_room_list
            else:
                record.group_room_list = False

    def _compute_room_list_booking(self):
        for record in self:
            room_list = record.group_room_list
            if room_list:
                for list in room_list:
                    if list.book > 0:
                        record.room_list_booking = True
                        break

    class reserveline(models.Model):
        _name = "hms.reservationline"
        _description = "Reservation Lines"

        name = fields.Char("Name")
        guest_name = fields.Char("Guest")
        reservation_id = fields.Many2one("hotel.reservation")

        rl_group_id = fields.Char(string="Group")
        rl_group_key = fields.Integer("Group ID")
        rl_room_rate = fields.Selection(
            [
                ("ota", "OTA"),
                ("s_foreigner", "Single Foreigner"),
                ("d_local", "Double Local"),
                ("cooperate", "Cooperate"),
                ("company1", "Company"),
            ],
            String="Customer Type",
            default="ota",
            tracking=True,
            translate=True,
        )
        rl_customer_type = fields.Many2one("hms.customer_type", "Customer Type")
        rl_currency = fields.Many2one("res.currency", "Currency")
        rl_room_type = fields.Many2one(
            "hms.room.type", String="Room Type", ondelete="set null"
        )
        rl_arrival = fields.Date("Arrival Date", default=date.today())
        rl_departure = fields.Date("Departure Date")
        rl_breakfast = fields.Boolean("Breakfast", default=False)
