from odoo import api, models, fields, _
from datetime import datetime


class MinibarTransaction(models.Model):
    booking_id = None
    guest_id = None
    room_id = None

    _name = "hotel.minibar_transaction"
    _description = "Minibar Transaction"
    _order = "id DESC"

    def _default_currency(self):
        currency = False
        currency_id = (
            self.env["res.currency"]
            .search([("hotelia_base_currency", "=", True)], limit=1)
            .id
        )
        if currency_id:
            currency = currency_id
        return currency

    reference = fields.Char(
        string="Reference",
        default=lambda self: self._generate_reference(),
        readonly=True,
    )
    booking_key = fields.Integer(string="Booking")
    room = fields.Char(string="Room")
    guest_name = fields.Char(string="Guest Name")
    product_category = fields.Many2one(
        "product.category", string="Product Category", required=True
    )
    total_amount = fields.Integer(
        string="Total Amount", compute="_compute_total_amount"
    )
    currency = fields.Many2one("res.currency", "Currency", default=_default_currency)
    date = fields.Date("Date", default=datetime.today())
    products = fields.One2many(
        "hotel.product", "minibar_transaction", string="Products"
    )
    is_posted = fields.Boolean(string="Is Posted", default=False)

    @api.model
    def _generate_reference(self):
        # Customize the sequence format as needed
        return (
            self.env["ir.sequence"].next_by_code("hotel.minibar_transaction.sequence")
            or "/"
        )

    @api.model
    def create(self, vals):
        global booking_id
        global guest_id
        global room_id

        vals["booking_key"] = booking_id
        vals["guest_name"] = guest_id
        vals["room"] = room_id

        minibar_obj = super(MinibarTransaction, self).create(vals)

        return minibar_obj

    @api.onchange("booking_key")
    def _compute_booking_data(self):
        global booking_id
        global guest_id
        global room_id

        for record in self:
            if record.booking_key:
                record.booking_key = booking_id
                record.guest_name = guest_id
                record.room = room_id

    @api.depends("products")
    def _compute_total_amount(self):
        amount = 0
        for record in self:
            if record.products:
                for product in record.products:
                    amount += product.amount
            record.total_amount = amount

    @api.onchange("product_category")
    def _onchange_product_category(self):
        self.env['ir.config_parameter'].set_param("minibar_product_category", self.product_category.id)

    def copy_registration(self, data):
        global booking_id
        global guest_id
        global room_id

        booking = data

        booking_id = booking.id
        guest_id = booking.guest_name
        room_id = booking.reg_room_name

        registration_data = data

        return registration_data

    def post_transaction(self):
        for record in self:
            if record.booking_key:
                booking = self.env["hms.registration"].search(
                    [("id", "=", record.booking_key)]
                )

                price = 0
                service = 0
                tax = 0

                for product_record in record.products:
                    price = product_record.amount  # product_record.list_price
                    service = product_record.service
                    tax = product_record.tax

                    transaction_data = self.env["hms.transaction"].search([('product_id','=',product_record.product.id)])
                    if not transaction_data:
                        transaction_data = self.env["hms.transaction"].create({
                            "name": "Minibar - " + product_record.product.display_name,
                            "price": price,
                            "service": service,
                            "tax": tax,
                            "currency": record.currency.id,
                            "product_id": product_record.product.id,
                            "customer_name": record.guest_name,
                        })

                    folio_data = {
                        "trans_lines_id": transaction_data.id,
                        "reg_id": booking.id,
                        "trans_price": price,  # transaction_data.price,
                        "service": service,  # transaction_data.service,
                        "tax": tax,  # transaction_data.tax,
                        "trans_currency": transaction_data.currency.id,
                        "quantity": 1,  # product_record.quantity, #transaction_data.quantity,
                        "trans_type": "product"
                    }

                    line_data = self.env["hms.trans.line"].search(
                        [
                            ("trans_lines_id", "=", folio_data["trans_lines_id"]),
                            ("reg_id", "=", folio_data["reg_id"]),
                        ]
                    )
                    if not line_data:
                        folio_record = self.env["hms.trans.line"].create(folio_data)

                record.is_posted = True
                
                noti = {
                    "type": "ir.actions.client",
                    "tag": "display_notification",
                    "params": {
                        "type": "info",
                        "sticky": False,
                        "message": _("Minibar transaction posted!"),
                        "fadeout": "slow",
                        "next": {
                            "type": "ir.actions.act_window_close",
                        },
                    },
                }
                return noti

    def unpost_transaction(self):
        for record in self:
            if record.booking_key:
                booking = self.env["hms.registration"].search(
                    [("id", "=", record.booking_key)]
                )

            if booking.payment_status != "paid":
                for product_record in record.products:
                    transaction_data = self.env["hms.transaction"].search([('product_id','=',product_record.product.id)])
                    if transaction_data:
                        folio_data = self.env["hms.trans.line"].search(
                            [
                                ("trans_lines_id", "=", transaction_data.id),
                                ("reg_id", "=", booking.id),
                            ]
                        )
                        if folio_data:
                            folio_data.unlink()

                record.is_posted = False
                
                noti = {
                    "type": "ir.actions.client",
                    "tag": "display_notification",
                    "params": {
                        "type": "info",
                        "sticky": False,
                        "message": _("Minibar transaction unposted!"),
                        "fadeout": "slow",
                        "next": {
                            "type": "ir.actions.act_window_close",
                        },
                    },
                }
                return noti
            else:
                noti = {
                    "type": "ir.actions.client",
                    "tag": "display_notification",
                    "params": {
                        "type": "info",
                        "sticky": False,
                        "message": _("Payment made. Transactions cannot be unposted."),
                        "fadeout": "slow",
                        "next": {
                            "type": "ir.actions.act_window_close",
                        },
                    },
                }
                return noti
            # search for record in hms_transaction and hms_trans_line based on booking_key and product_id
            # delete record in hms_trans_line then delete record in hms_transaction
