from odoo import api, fields, models


class Message(models.Model):
    _name = "hotel.message"
    _description = "Messages From Customers"
    _order = "id DESC"

    room_no = fields.Char(string="Room No.")
    reg_no = fields.Char(string="Registration No.")
    reg_key = fields.Integer("Registration ID")
    guest_name = fields.Char(string="Guest Name")
    message_type = fields.Selection(
        [("normal", "Normal"), ("urgent", "Urgent"), ("important", "Important")],
        default="normal",
        String="Message Type",
    )
    subject = fields.Char(string="Subject")
    remark = fields.Text(string="Remark")
    date = fields.Date(string="Date")
    mytimefieldname = fields.Float(string="Time")

    # Choose one Record from `Registration Modal` and Update the `Message Form`
    @api.onchange("reg_key")
    def _onchange_guest_name(self):
        for rec in self:
            if rec.reg_key:
                # print(f'reg_key => {rec.reg_key}')
                reg_data = self.env["hms.registration"].search(
                    [("id", "=", rec.reg_key)], order="id desc", limit=1
                )
                if reg_data:
                    rec.reg_key = reg_data.id
                    rec.room_no = reg_data.reg_room_no.name
                    rec.reg_no = reg_data.name
                    rec.guest_name = reg_data.guest_name

    # bread crumbs
    def name_get(self):
        result = []
        for rec in self:
            name = str(rec.id)
            result.append((rec.id, name))
        return result
