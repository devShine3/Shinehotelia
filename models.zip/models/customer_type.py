from odoo import api, fields, models


class Customer_Type(models.Model):
    _name = "hms.customer_type"
    _description = "Customer Types"
    name = fields.Char(String="Customer Type")
