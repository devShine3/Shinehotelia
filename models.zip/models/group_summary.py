from odoo import models, fields, api, _
from datetime import datetime, date, time
from datetime import date, timedelta
from datetime import datetime
import datetime


class groupSummary(models.Model):
    _name = "hms.group.summary"
    _description = "Group Summary Form"
    _order = "id DESC"

    name = fields.Char(string="Name", required="True")
    reservation = fields.Char(string="Reservation")
    group = fields.Char(string="Group")
    room_type = fields.Char(string="Room Type")
    reservation_id = fields.Many2one("hotel.reservation")
