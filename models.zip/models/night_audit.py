from datetime import date, datetime, timedelta

from odoo import api, fields, models, tools, _
from odoo.exceptions import MissingError, UserError, ValidationError, AccessError
from datetime import datetime

import logging

_logger = logging.getLogger(__name__)


class NightAudit(models.Model):
    _name = "hms.night.audit"
    _description = "Night Audit"
    _order = "id DESC"

    @api.model
    def reload_settings(self):
        check_out_time = self.env["ir.config_parameter"].get_param("hotelia.check_out_time", "")
        minibar_erp = self.env["ir.config_parameter"].get_param("hotelia.minibar_erp", "")

        service_inclusive = self.env["ir.config_parameter"].get_param("hotelia.service_inclusive", "")
        service_percent = self.env["ir.config_parameter"].get_param("hotelia.service_percent", "")

        tax_inclusive = self.env["ir.config_parameter"].get_param("hotelia.tax_inclusive", "")
        tax_percent = self.env["ir.config_parameter"].get_param("hotelia.tax_percent", "")

        for record in self:
            if check_out_time:
                record.check_out_time = check_out_time
            else:
                record.check_out_time = 12

            record.minibar_erp = minibar_erp
            record.service_inclusive = service_inclusive
            record.service_percent = service_percent
            record.tax_inclusive = tax_inclusive
            record.tax_percent = tax_percent

    name = fields.Char()
    add_one_day = fields.Boolean(
        "Add one day for In-House Guest that has already ended"
    )
    no_show = fields.Boolean(
        "Change Reservation Status to No Show for Current Date Arrival"
    )
    room_rate = fields.Boolean("Room Rate Posting")
    expected_departure = fields.Boolean("Show Expected Departure Rooms")
    show_no_show = fields.Boolean("Show No Show Rooms")

    night_audit_date = fields.Boolean("Date", compute='_compute_flag_date', default=False)

    def _compute_flag_date(self):
        for record in self:
            na_transaction_date = record.env["ir.config_parameter"].get_param("hotelia.na_transaction_date", "")
            if na_transaction_date:
                record.night_audit_date = True
            else:
                record.night_audit_date = False

    @api.model
    def _compute_system_date(self):
        for record in self:
            na_transaction_date = record.env["ir.config_parameter"].sudo().get_param("hotelia.na_transaction_date")

            if na_transaction_date == 'True':
                record.transaction_date_display = date.today()
            else:
                record.transaction_date_display = False
    
    transaction_date_display = fields.Date("Transaction Date", compute=_compute_system_date, store=False)

    @api.model
    def _compute_transaction_date(self):
        for record in self:
            na_transaction_date = record.env["ir.config_parameter"].sudo().get_param("hotelia.na_transaction_date")

            if na_transaction_date == 'False':
                sql = "SELECT transaction_date FROM hms_night_audit ORDER BY transaction_date DESC LIMIT 1"
                record.env.cr.execute(sql)
                last_trans_date = record.env.cr.fetchone()
                if last_trans_date:
                    last_date = last_trans_date[0]
                    record.transaction_date  = record.transaction_date or last_date
            else:
                record.transaction_date = False

    transaction_date = fields.Date("Transaction Date", default=date.today(), compute=_compute_transaction_date, store=True)

    check_out_time = fields.Integer(
        "Check Out Hour", compute=reload_settings, default=12
    )
    minibar_erp = fields.Boolean(string="Minibar ERP")
    service_inclusive = fields.Boolean(string="Service Inclusive")
    service_percent = fields.Integer(string="Service Percent")

    tax_inclusive = fields.Boolean(string="Tax Inclusive")
    tax_percent = fields.Integer(string="Tax Percent")

    def _today_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(hours=6, minutes=30, days=0)
        return new_date

    def _yestderday_date(self):
        current_date = datetime.now()
        new_date = current_date - timedelta(days=1) + timedelta(hours=6, minutes=30)
        return new_date

    def _tomorrow_date(self):
        print(f"{self.env.context} ---env")
        current_date = datetime.now()
        new_date = current_date + timedelta(hours=6, minutes=30, days=1)
        return new_date  

    # bill to DO(delivery order)
    def night_audit(self):
        # check_ins = self.env["hms.registration"].search([("Rsv_Type", "=", "registration")])
        dm_room = self.env["hms.room.type"].search([("name", "=", "Dummy Room")]).id
        check_ins = self.env["hms.registration"].search(
            [("Rsv_Type", "=", "registration"), ("reg_room_type", "!=", dm_room)]
        )
        trans_line_id = self.env["hms.transaction"].search(
            [("name", "=", "Room Charges")]
        )
        pack_line_id = (
            self.env["hms.transaction"].sudo().search([("name", "=", "Package")])
        )
        trans_date = False
        dep_extend_date = False
        service_percent = int(self.env["ir.config_parameter"].get_param("hotelia.service_percent")) #10 #0.1 #10%
        tax_percent = int(self.env["ir.config_parameter"].get_param("hotelia.tax_percent")) #5 #0.05 #5%

        # Add Room Charges Transactions to check in registration
        if check_ins:
            for check_in in check_ins:
                # check flag for Ticket 15889
                if self.room_rate == True:
                    found = False
                    new_date = datetime.now() + timedelta(hours=6, minutes=30)
                    current_hour = new_date.time().hour

                    # _logger.info(f"{new_date.time().hour} !!Today Night Audit Hour")
                    if current_hour < self.check_out_time:
                        trans_date = self._yestderday_date().date()
                        dep_extend_date = self._today_date().date()

                    else:
                        trans_date = self._today_date().date()
                        dep_extend_date = self._tomorrow_date().date()

                    for transaction in check_in.transaction_id:
                        if (
                            transaction.trans_lines_id.id == trans_line_id.id
                            and transaction.trans_date == trans_date
                            and not transaction.non_master_id
                        ):
                            found = True
                        elif transaction.trans_lines_id.id == pack_line_id.id:
                            found = True

                    if found == True:
                        original_price = 0.00
                        trans_price = 0.00
                        service_price = 0.00
                        tax_price = 0.00
                        if transaction.original_price:
                            original_price = transaction.original_price
                            trans_price = original_price      
                        if self.service_inclusive and trans_price > 0.00:
                            service_amount = trans_price * (1 - round(service_percent/100, 2))
                            service_price = trans_price - service_amount #round((service_percent / trans_price) * 100, 2)
                            trans_price = trans_price - service_price
                            transaction.write({
                                "trans_price": trans_price,
                                "service": service_price
                            })
                        if self.tax_inclusive and trans_price > 0.00:
                            tax_amount = trans_price * (1 - round(tax_percent/100, 2))
                            tax_price = trans_price - tax_amount #round((tax_percent / trans_price) * 100, 2)
                            trans_price = trans_price - tax_price
                            transaction.write({
                                "trans_price": trans_price,
                                "tax": tax_price
                            })

                    # room charges add if not exist for today
                    if found == False and check_in.reg_room_type:
                        original_price = 0.00
                        trans_price = 0.00
                        service_price = 0.00
                        tax_price = 0.00
                        if check_in.reg_amount:
                            original_price = check_in.reg_amount
                            trans_price = original_price
                        if self.service_inclusive and trans_price > 0.00: 
                            service_amount = trans_price * (1 - round(service_percent/100, 2))
                            service_price = trans_price - service_amount # round(trans_price/service_percent, 2) #round((service_percent / trans_price) * 100, 2)
                            trans_price = trans_price - service_price
                        if self.tax_inclusive and trans_price > 0.00:
                            tax_amount = trans_price * (1 - round(tax_percent/100, 2))
                            tax_price = trans_price - tax_amount # round(trans_price/tax_percent, 2) #round((tax_percent / trans_price) * 100, 2)
                            trans_price = trans_price - tax_price

                        transaction_id = [
                            (
                                0,
                                0,
                                {
                                    "trans_lines_id": trans_line_id.id,
                                    "original_price": original_price,
                                    "trans_price": trans_price,
                                    "trans_currency": check_in.reg_currency.id,
                                    "trans_type": "night",
                                    "trans_date": trans_date,
                                    "service": service_price,
                                    "tax": tax_price
                                },
                            )
                        ]

                        # _logger.info(f"{check_in.id} {check_in.reservation_id} !!reg_departure write 1")
                        check_in.write(
                            {
                                "transaction_id": transaction_id,
                                "all_billed": False,
                            }
                        )
                        # _logger.info(f"{check_in.id} {check_in.reservation_id} !!reg_departure write 2")
                        # room charge add for master room
                        if check_in.group_key and not check_in.master_bill:
                            non_master_id = (
                                self.env["hms.trans.line"]
                                .search(
                                    [
                                        ("bill_id", "=", check_in.id),
                                        ("trans_lines_id", "=", trans_line_id.id),
                                        ("trans_date", "=", trans_date),
                                    ]
                                )
                                .id
                            )
                            master_reservation_obj = self.env[
                                "hms.registration"
                            ].search(
                                [
                                    ("group_key", "=", check_in.group_key),
                                    ("master_bill", "=", True),
                                    ("Rsv_Type", "=", "registration"),
                                ],
                                limit=1,
                            )

                            transaction_id = [
                                (
                                    0,
                                    0,
                                    {
                                        "trans_lines_id": trans_line_id.id,
                                        "trans_price": check_in.reg_amount,
                                        "trans_currency": check_in.reg_currency.id,
                                        "trans_type": "night",
                                        "trans_date": trans_date,
                                        "non_master_id": non_master_id,
                                    },
                                )
                            ]
                            if master_reservation_obj:
                                record_no_master_ids = []
                                for master in master_reservation_obj.transaction_id:
                                    record_no_master_ids.append(master.non_master_id)
                                if non_master_id not in record_no_master_ids:
                                    master_reservation_obj.write(
                                        {
                                            "transaction_id": transaction_id,
                                            "all_billed": False,
                                        }
                                    )
            
                # check flag for Ticket 15888
                if self.add_one_day == True:
                    if (
                        check_in.departure_date < dep_extend_date
                        and check_in.dayuse == False
                    ):
                        reg_departure = dep_extend_date

                        _logger.info(f"{reg_departure} !!reg_departure again")
                        check_in.write(
                            {
                                "reg_departure": reg_departure,
                                "departure": reg_departure,
                            }
                        )

                check_in.reg_room_no.write({"room_status": "o_dirty"})

        # self.transaction_date = date.today()
        self.transaction_date = trans_date

        # Generate Invoice for bills which are not invoiced
        bills = self.env["hotel.bill"].search([("invoice_id", "=", False)])
        bill_invoices = self.env["account.move"].search(
            [("hotelia_bill_id", "!=", False)]
        )
        bill_ids = []
        for invoice in bill_invoices:
            bill_ids.append(invoice.hotelia_bill_id.id)
        if bills:
            base_currency = self.env["res.currency"].search(
                [("hotelia_base_currency", "=", True)], limit=1
            )
            if not base_currency:
                raise ValidationError(_("You must create hotelia base currency first"))
        for bill in bills:
            if bill.reg_ids.Rsv_Type == "check_out" and bill.id not in bill_ids:
                guest = self.env["hotel.guest"].search(
                    [("id", "=", bill.reg_ids.guest_key)]
                )
                # if not guest:
                #     create_guest = {
                #         "name": bill.reg_ids.guest_name,
                #         "id_no": bill.reg_ids.nric,
                #         "passport_no": bill.reg_ids.passport_no,
                #         "email_from": bill.reg_ids.email,
                #         "phone": bill.reg_ids.phone,
                #         "national": bill.reg_ids.national.id,
                #         "title": bill.reg_ids.title.id,
                #     }
                #     guest = self.env["hotel.guest"].create(create_guest)
                #     bill.reg_ids.write({"guest_key": guest.id})

                if guest:
                    customer = self.env["res.partner"].search(
                        [("id", "=", guest.partner_id)]
                    )
                    self.insert_detail_invoice(bill.id, customer)
                else:
                    _logger.error(
                        f"\n registration_id: {str(bill.reg_ids.id)},\n guest_id: {str(bill.reg_ids.guest_key)},\n bill_id: {str(bill.id)}\n --night audit bill invoice"
                    )

        # Generate Delivery Order(DO)
        # get data from minibar and hms_transaction
        # create_delivery_order
        # minibar_erp = eval(minibar_erp)
        if self.minibar_erp == True:
            delivery_order_data = {}
            if check_ins:
                for check_in in check_ins:
                    if check_in.transaction_id:
                        transaction_lines = check_in.transaction_id

                        # check/create delivery order
                        delivery_order = self.env["stock.picking"].search([
                            ("booking_key","=",check_in.id),
                            ("state","=","assigned")
                        ])
                        if not delivery_order:
                            picking_type = self.env["stock.picking.type"].search([('name', '=', 'Delivery Orders'), ('barcode', '=', 'WH-DELIVERY')])
                            location = self.env["stock.location"].search([('name', '=', 'Stock'), ('complete_name', '=', 'WH/Stock')])
                            location_dest = self.env["stock.location"].search([('name', '=', 'Customers'), ('complete_name', '=', 'Partner Locations/Customers')])
                            
                            delivery_order_data = {
                                "customer_name": check_in.guest_name,
                                "room": check_in.reg_room_no.display_name,
                                'booking_key': check_in.id,
                                'picking_type_id': picking_type.id, #2, # stock.picking.type
                                'scheduled_date': datetime.today(),
                                'location_id': location.id, #8, # stock.location
                                'location_dest_id': location_dest.id, #5, # stock.location
                            }
                            delivery_order = self.env["stock.picking"].create(
                                delivery_order_data
                            )
                            delivery_order.write({"state": "assigned"})

                        # add products for delivery order
                        if not delivery_order.move_ids_without_package:
                            for transaction_line in transaction_lines:
                                if not transaction_line.bill_id and transaction_line.night_audit_done == False:
                                    hms_transaction = transaction_line.trans_lines_id
                                    if hms_transaction.product_id:
                                        for product in hms_transaction.product_id:
                                            stock_move_data = {
                                                "picking_id": delivery_order.id,
                                                "name": product.name,
                                                "date": datetime.today(),
                                                "product_id": product.id,
                                                # 'product_qty': hotel_product.quantity, #hms_transaction.quantity,
                                                "product_uom": 1,
                                                "product_uom_qty": transaction_line.quantity,
                                                "picking_type_id": delivery_order.picking_type_id.id,
                                                "location_id": delivery_order.location_id.id,
                                                "location_dest_id": delivery_order.location_dest_id.id,
                                                "state": "assigned",
                                                "quantity_done": transaction_line.quantity,
                                            }
                                            stock_move = self.env["stock.move"].create(
                                                stock_move_data
                                            )
                                            if stock_move:
                                                transaction_line.night_audit_done = True
                                elif transaction_line.bill_id and transaction_line.night_audit_done == False:
                                    transaction_line.night_audit_done = True

                        
                        # calculate items in delivery order
                        if delivery_order.move_ids_without_package:
                            delivery_order.button_validate()
                        else:
                            delivery_order.unlink()
            
        
        # no show status
        no_show_data = self.env["hotel.reservation"].search(
            [
                ("Rsv_Type", "in", ["open", "confirmed"]),
                ("arrival", "<", fields.Date.today()),
            ]
        )
        if no_show_data:
            for n in no_show_data:
                n.write({"Rsv_Type": "noshow"})

        noti = {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "type": "info",
                "sticky": False,
                "message": _("Night Audit Running Completed"),
                "fadeout": "slow",
                "next": {
                    "type": "ir.actions.act_window_close",
                },
            },
        }
        return noti

    def insert_detail_invoice(self, bill_id, customer):
        transactions = self.env["hms.trans.line"].search([("bill_id", "=", bill_id)])
        invoices = []
        payments_arr = []
        base_currency = self.env["res.currency"].search(
            [("hotelia_base_currency", "=", True)], limit=1
        )
        journal = self.env["account.journal"].search([("type", "=", "sale")], limit=1)

        for transaction in transactions:
            _logger.info(
                f"{transaction.trans_lines_id.product_id} --night audit product"
            )
            if transaction.trans_price > 0:
                product = self.env["product.product"].search(
                    [("id", "=", transaction.trans_lines_id.product_id.id)]
                )
                product_name = product.name
                invoice_line = (
                    0,
                    None,
                    {
                        "name": product_name,
                        "product_id": transaction.trans_lines_id.product_id.id,
                        "quantity": 1,
                        "price_unit": transaction.trans_price,
                        "date": date.today(),
                    },
                )
                currency = base_currency.id
                if transaction.trans_currency:
                    currency = transaction.trans_currency.id
                found = False
                for item in invoices:
                    if item.get("currency_id") == currency:
                        found = True
                        break

                if found == True:
                    item["invoice_line_ids"].append(invoice_line)

                else:
                    invoice = {
                        "move_type": "out_invoice",
                        "date": date.today(),
                        "partner_id": customer.id,
                        "invoice_date": date.today(),
                        "hotelia_bill_id": bill_id,
                        "currency_id": currency,
                        "invoice_payment_term_id": 1,
                        "journal_id": journal.id,  # Customer Invoices for journal
                        "invoice_line_ids": [invoice_line],
                    }
                    invoices.append(invoice)

        for inv in invoices:
            invoice_erp = self.env["account.move"].create(inv)
            invoice_erp.action_post()
            invoice_name = (
                self.env["account.move"].search([("id", "=", invoice_erp.id)]).name
            )
            inv["name"] = invoice_name
            inv["id"] = invoice_erp.id

        payments = self.env["hotel.payment.line"].search([("bill_id", "=", bill_id)])

        for payment in payments:
            if payment.amount > 0:
                found_pay_currency = False
                currency = base_currency.id
                journal = self.env["hotel.payment"].search(
                    [
                        ("payment_group", "=", "cash"),
                        ("currency", "=", base_currency.id),
                    ]
                )
                if payment.payment_code:
                    journal = payment.payment_code.cash_book.id
                if payment.currency:
                    currency = payment.currency.id
                if payment.payment_code.payment_group == "cash":
                    payment_list = {
                        "currency": currency,
                        "amount": payment.amount,
                        "journal": journal,
                    }
                    for item in payments_arr:
                        if item.get("currency_id") == currency:
                            found_pay_currency = True
                            break

                    if found_pay_currency == True:
                        item["amount"] += payment.amount

                    else:
                        payments_arr.append(payment_list)

        for payment in payments_arr:
            found_currency = False
            currency = base_currency
            only_one_invoice = False
            for inv in invoices:
                currency = inv["currency_id"]
                only_one_invoice = inv
                if inv["currency_id"] == payment["currency"]:
                    found_currency = True
                    self.insert_payment(
                        inv["id"],
                        inv["name"],
                        payment["amount"],
                        payment["journal"],
                        payment["currency"],
                    )
                    break

            if found_currency == False:
                if only_one_invoice != False:
                    self.insert_payment(
                        only_one_invoice["id"],
                        only_one_invoice["name"],
                        payment["amount"],
                        payment["journal"],
                        payment["currency"],
                    )

    def insert_payment(self, invoice_id, invoice_name, amount, journal_id, currency_id):
        PaymentReg = (
            self.env["account.payment.register"]
            .with_context({"active_model": "account.move", "active_ids": invoice_id})
            .create(
                {
                    "journal_id": journal_id,
                    "amount": amount,
                    "currency_id": currency_id,
                    "payment_date": date.today(),
                }
            )
            .action_create_payments()
        )
        payment_id = PaymentReg["res_id"]
        payment = self.env["account.payment"].search([("id", "=", payment_id)])
