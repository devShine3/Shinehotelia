from odoo import models, fields, api, _


class agentSetup(models.Model):
    _name = "hmslite.agentsetup"
    _description = "Agent Setup Form"
    _order = "id ASC"

    name = fields.Char(string="Name", required="True")
