import json
from datetime import date

import requests
from werkzeug.urls import url_encode
from odoo import fields, models, api
from odoo.exceptions import ValidationError
from odoo.tools import datetime
from odoo import _, http
from odoo.exceptions import UserError


class RoomRate(models.Model):
    _name = "hms_room_rate"
    _description = "Room Rate"

    name = fields.Char(String="Name", tracking=True, translate=True, required=True)
    customer_type = fields.Many2one("hms.customer_type", "Customer Type")
    rate_type = fields.Selection(
        [
            ("ota", "OTA"),
            ("s_foreigner", "Single Foreigner"),
            ("d_local", "Double Local"),
            ("cooperate", "Cooperate"),
            # ('c_local','Complimentry Local'),
            ("company1", "Company"),
        ],
        String="Customer Type",
        default="ota",
        tracking=True,
        translate=True,
    )

    currency = fields.Many2one("res.currency", String="Currency", ondelete="set null")

    extra_bed = fields.Float(String="Extra Bed")
    breakfastFlag = fields.Boolean(string="Exclusive Breakfast")

    breakfast = fields.Float(String="Breakfast")
    room_rate = fields.Float(String="Room Rate")
    from_date = fields.Date(String="From Date")
    to_date = fields.Date(String="To Date")
    room_no = fields.Many2one("hms_room_setup", domain="[('function','=',True)]")
    room_type = fields.Many2one(
        "hms.room.type", String="Room Type", ondelete="set null"
    )
    function = fields.Boolean("function_room_type")

    @api.onchange("room_no")
    def onchange_roomNo(self):
        if self.room_no:
            self.room_type = self.room_no.room_type

    @api.constrains('name')
    def _check_unique_name(self):
        # Check if there is any other record with the same name
        duplicates = self.search([('name', '=', self.name), ('id', '!=', self.id)])
        if duplicates:
            raise ValidationError('Room Name. Already Exist!!.')