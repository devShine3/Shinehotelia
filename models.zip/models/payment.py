from odoo import api, fields, models
from odoo.exceptions import ValidationError


class Payment(models.Model):
    _name = "hotel.payment"
    _description = "Hotelia Payment"
    name = fields.Char("Description")
    code = fields.Char("Code")
    currency = fields.Many2one("res.currency", string="Currency")
    rate = fields.Float("Currency Rate")
    payment_group = fields.Selection(
        [
            ("cash", "Cash"),
            ("city_ledeger", "City Ledger"),
            ("complimentary", "Complimentary"),
        ],
        String="Criteria",
        default="cash",
    )
    cash_book = fields.Many2one("account.journal")

    @api.constrains('code')
    def _check_unique_code(self):
        # Check if there is any other record with the same code
        duplicates = self.search([('code', '=', self.code), ('id', '!=', self.id)])
        if duplicates:
            raise ValidationError('Payment Code. Already Exist!!.') 
 
    def unlink(self):
        for record in self:
            # Check if any record is using this payment code
            if record.code:
                bill_payment = self.env['hotel.payment.line'].search([('name', '=', record.name)])
                if bill_payment:
                    raise ValidationError("You cannot delete payment code as it's being used by other bill records.")
        super(Payment, self).unlink()
