from unicodedata import name
from odoo import api, fields, models


class Amenity(models.Model):
    _name = "hms.amenity"
    _description = "hotel room types"
    name = fields.Char(String="Name")
