# -*- coding: utf-8 -*-
import requests
from odoo import models, fields, api, _
from odoo.exceptions import UserError
from odoo import api, fields, models, tools, SUPERUSER_ID
from odoo.addons.iap.tools import iap_tools
from odoo.addons.mail.tools import mail_validation
from odoo.addons.phone_validation.tools import phone_validation
from odoo.exceptions import UserError, AccessError
from odoo.osv import expression
from odoo.tools.translate import _
from odoo.tools import date_utils, email_re, email_split, is_html_empty
from odoo import models, fields, api
from odoo.exceptions import ValidationError
from datetime import date, datetime
from odoo.tools import datetime
from dateutil.relativedelta import relativedelta
from datetime import timedelta

# Subset of partner fields: sync all or none to avoid mixed addresses
PARTNER_ADDRESS_FIELDS_TO_SYNC = [
    "street",
    "street2",
    "city",
    "zip",
    "state_id",
    "country_id",
]
# Subset of partner fields: sync any of those
PARTNER_FIELDS_TO_SYNC = [
    "mobile",
    "title",
    "function",
    "website",
]


class guest(models.Model):
    _name = "hotel.guest"
    _description = "Guest Application Form"
    _rec_name = "id"

    def _compute_full_name(self):
        for rec in self:
            if rec.title and rec.name:
                rec.full_name = rec.title.name + " " + rec.name
            elif not rec.title:
                rec.full_name = rec.name
            elif not rec.name:
                rec.full_name = ""
            else:
                rec.full_name = ""

    name = fields.Char(string="Name")
    full_name = fields.Char(compute=_compute_full_name)
    company_id = fields.Many2one(
        "res.company", string="Company", index=True, readonly=False, store=True
    )
    partner_id = fields.Integer(string="Partner ID")
    country_id = fields.Many2one(
        "res.country", string="Country", readonly=False, store=True
    )
    email_from = fields.Char(
        "Email", tracking=40, index=True, readonly=False, store=True
    )
    phone = fields.Char("Phone")
    mobile = fields.Char("Mobile")
    citizen = fields.Selection(
        [("local", "Local"), ("foreign", "Foreign"), ("others", "Others")],
        default="local",
    )
    state_id = fields.Many2one(
        "res.country.state",
        string="State",
        readonly=False,
        store=True,
        domain="[('country_id', '=?', country_id)]",
    )

    title = fields.Many2one("hms.namelist", string="Title", readonly=False, store=True)
    national = fields.Many2one("hms.national", string="Nationality")
    website = fields.Char(
        "Website", index=True, help="Website of the contact", readonly=False, store=True
    )
    date_of_birth = fields.Date("Date of Birth", tracking=True)
    age = fields.Char(string="Age", compute="_compute_age")
    gender = fields.Selection(
        [("male", "Male"), ("female", "Female"), ("na", "NA")], default="male"
    )
    father_name = fields.Char(string="Father")
    guestptr_name = fields.Char(string="Partner")
    passport_no = fields.Char("Passport")
    id_no = fields.Char("ID")
    _sql_constraints = [
        ("name_id_no_unique", "unique (name, id_no)", "Guest Already Exist!"),
    ]
    _sql_constraints = [
        (
            "barcode_uniq",
            "unique (barcode)",
            "The Badge ID must be unique, this one is already assigned to another employee.",
        ),
        (
            "user_uniq",
            "unique (user_id, company_id)",
            "A user cannot be linked to multiple employees in the same company.",
        ),
    ]
    place_of_issue = fields.Char("Place of Issue")
    isue_date = fields.Date("Issue Date")
    visa_no = fields.Char("Visa")
    visa_type = fields.Char("Visa Type")
    occupation = fields.Char("Occupation")
    anniversary_date = fields.Date("Anniversary Date")
    fax_no = fields.Char("Fax Number")
    remark = fields.Char("Remark")

    # Address fields
    street = fields.Char("Street", readonly=False, store=True)
    street2 = fields.Char("Street2", readonly=False, store=True)
    zip = fields.Char("Zip", change_default=True, readonly=False, store=True)
    city = fields.Char("City", readonly=False, store=True)
    local_form = fields.Integer()

    def copy_name_registration(self):
        g_id = 0
        for rec in self:
            g_id = rec.id
        return g_id

    def copy_guest_name(self):
        g_id = 0
        for rec in self:
            g_id = rec.id
        return g_id

    @api.depends("date_of_birth")
    def _compute_age(self):
        for emp in self:
            age = relativedelta(
                datetime.now().date(), fields.Datetime.from_string(emp.date_of_birth)
            ).years
            emp.age = str(age)

    # address values prepare
    def _prepare_values_from_partner(self, partner):
        values = self._prepare_address_values_from_partner(partner)
        # For other fields, get the info from the partner, but only if set
        values.update({f: partner[f] or self[f] for f in PARTNER_FIELDS_TO_SYNC})
        # Fields with specific logic
        values.update(self._prepare_contact_name_from_partner(partner))
        values.update(self._prepare_partner_name_from_partner(partner))

        return self._convert_to_write(values)

    def _prepare_address_values_from_partner(self, partner):
        # Sync all address fields from partner, or none, to avoid mixing them.
        if any(partner[f] for f in PARTNER_ADDRESS_FIELDS_TO_SYNC):
            values = {f: partner[f] for f in PARTNER_ADDRESS_FIELDS_TO_SYNC}
        else:
            values = {f: self[f] for f in PARTNER_ADDRESS_FIELDS_TO_SYNC}
        return values

    @api.model
    def create(self, vals):
        if "id_no" in vals or "name" in vals:
            existing_guest = self.search(
                [("name", "=", vals.get("name")), ("id_no", "=", vals.get("id_no"))]
            )
            if existing_guest:
                raise ValidationError(
                    "A guest with the same date of birth and NRC already exists."
                )

        if "name" in vals:
            guest_name = vals["name"]

        partner_data = self.env["res.partner"].create(
            {
                "name": vals.get("name"),
                "email": vals.get("email_from"),
                "type": "contact",
            }
        )
        vals["partner_id"] = partner_data.id
        vals["local_form"] = 1
        guest_setup = super(guest, self).create(vals)
        return guest_setup

    def write(self, vals):
        # if 'id_no' in vals or 'name' in vals:
        #     for g in self:
        #         existing_guest = self.search([
        #             ('id', '!=', g.id),
        #             ('name', '=', vals.get('name', g.name)),
        #             ('id_no', '=', vals.get('id_no', g.id_no))
        #         ])
        #         if existing_guest:
        #             raise ValidationError("A guest with the same date of birth and NRC already exists.")
        partner_data = self.env["res.partner"].search(
            [("id", "=", vals.get("partner_id"))]
        )
        partner_data.write({"name": vals.get("name"), "email": vals.get("email_from")})

        guest_setup = super(guest, self).write(vals)

        guest_data = self.env["hotel.guest"].search(
            [("name", "=", self.name), ("id_no", "=", self.id_no)], limit=1
        )

        guest_line_data = self.env["hms.guestline"].search(
            [
                ("guest_id", "=", self.id),
                ("name", "=", self.name),
                ("nrc", "=", self.id_no),
            ]
        )
        if guest_data.gender in ["male", "female", "na"]:
            gender = guest_data.gender
        else:
            gender = "male"
        if guest_line_data:
            guest_line_data.write(
                {
                    "phone": guest_data.phone,
                    "email": guest_data.email_from,
                    "nrc": guest_data.id_no,
                    "date_of_birth": guest_data.date_of_birth,
                    "passport_no": guest_data.passport_no,
                    "nationality": guest_data.national.id
                    if guest_data.national
                    else False,
                    "gender": gender,
                }
            )

        main_guest_update_res = self.env["hms.registration"].search(
            [("guest_key", "=", self.id)]
        )
        if main_guest_update_res:
            date_of_birth_clause = ""
            if guest_data.date_of_birth:
                date_of_birth_clause = (
                    ",date_of_birth='" + str(guest_data.date_of_birth) + "'"
                )
            update_guest = (
                f"UPDATE hms_registration SET guest_name='{guest_data.name}',nric='{guest_data.id_no}',passport_no='{guest_data.passport_no}'"
                f",national={guest_data.national.id if guest_data.national else 'NULL'}"
                f",phone='{guest_data.phone if guest_data.phone else ' '}'"
                f",email='{guest_data.email_from if guest_data.email_from else ' '}',"
                f"gender='{gender}'{date_of_birth_clause} WHERE guest_key={guest_data.id} "
            )
            self.env.cr.execute(update_guest)
        return guest_setup

    def fields_get(self, allfields=None, attributes=None):
        result = super().fields_get(allfields=allfields, attributes=attributes)
        fields_to_hide = ["id_no"]

        for field_name in fields_to_hide:
            if field_name in result:
                result[field_name]["searchable"] = False
                result[field_name]["sortable"] = False
        return result

    # bread crumbs
    def name_get(self):
        result = []
        for rec in self:
            name = str(rec.id)
            result.append((rec.id, name))
        return result

    def guest_line_update(self):
        guests = self.env["hotel.guest"].search([])
        for guest in guests:
            guest_lines = self.env["hms.guestline"].search(
                [("name", "=", guest.name), ("guest_id", "=", False)]
            )
            for guest_line in guest_lines:
                guest_line.write(
                    {
                        "phone": guest.phone,
                        "nrc": guest.id_no,
                        "email": guest.email_from,
                        "passport_no": guest.passport_no,
                        "date_of_birth": guest.date_of_birth,
                        "nationality": guest.national.id,
                        "guest_id": guest.id,
                    }
                )
