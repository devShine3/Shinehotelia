from odoo import api, fields, models, tools, _
from odoo.exceptions import RedirectWarning, Warning
import json
from datetime import datetime, timedelta, date
from datetime import datetime, timedelta, time
from dateutil import relativedelta


class HouseStatus(models.Model):
    _name = "hms.house.status"
    _description = "HMS House Status"

    # _inherit = ['hotel.reservation','hms.registration', 'hms_room_setup']

    def _default_total_reservation(self):
        reservation_count = self.env["hms.registration"].search_count(
            [("reg_departure", ">=", self.date_to), ("function_id", "=", "2")]
        )
        return reservation_count

    def _default_compute_cancellation(self):
        start_of_day = date.today()
        cancellation = self.env["hotel.reservation"].search_count(
            [("Rsv_Type", "=", "cancel"), ("arrival_date", "=", start_of_day)]
        )
        return cancellation

    def _compute_cancellation_pax(self):
        start_of_day = date.today()
        sql = """select COALESCE(SUM(adult), 0),COALESCE(SUM(child), 0) from hotel_reservation  
                where "Rsv_Type" = 'cancel'
                and arrival_date = '%s' """ % (
            start_of_day
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            cancellation_pax = record[0] + record[1]
            return cancellation_pax

    def _compute_no_show(self):
        today = date.today()
        no_show = (
            self.env["hotel.reservation"]
            .sudo()
            .search_count([("Rsv_Type", "=", "noshow"), ("arrival_date", "=", today)])
        )
        return no_show

    def _compute_no_show_pax(self):
        today = date.today()
        sql = (
            """select COALESCE(SUM(adult), 0),COALESCE(SUM(child), 0) from hotel_reservation  
                where "Rsv_Type" = 'noshow' and arrival_date = '%s' """
            % today
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            no_show_pax = record[0] + record[1]
            return no_show_pax

    def _compute_total_rooms(self):
        dm_room = self.env["hms.room.type"].search([("name", "=", "Dummy Room")]).id
        total_rooms = (
            self.env["hms_room_setup"]
            .sudo()
            .search_count([("function", "=", False), ("room_type", "!=", dm_room)])
        )
        return total_rooms

    def _compute_out_order(self):
        out_order = (
            self.env["hms_room_setup"]
            .sudo()
            .search_count([("room_status", "=", "ooo"), ("function", "=", False)])
        )
        return out_order

    def _compute_out_service(self):
        out_service = (
            self.env["hms_room_setup"]
            .sudo()
            .search_count([("room_status", "=", "oos"), ("function", "=", False)])
        )
        return out_service

    def _compute_dirty_rooms_occupied(self):
        dirty_rooms_occupied = (
            self.env["hms_room_setup"]
            .sudo()
            .search_count([("room_status", "=", "o_dirty"), ("function", "=", False)])
        )
        return dirty_rooms_occupied

    def _compute_dirty_rooms_occupied_vacant(self):
        dirty_rooms_occupied_vacant = (
            self.env["hms_room_setup"]
            .sudo()
            .search_count([("room_status", "=", "v_dirty"), ("function", "=", False)])
        )
        return dirty_rooms_occupied_vacant

    def _compute_clean_rooms_occupied_vacant(self):
        clean_rooms_occupied_vacant = (
            self.env["hms_room_setup"]
            .sudo()
            .search_count([("room_status", "=", "v_clean"), ("function", "=", False)])
        )
        return clean_rooms_occupied_vacant

    def _compute_clean_rooms_occupied(self):
        clean_rooms_occupied = (
            self.env["hms_room_setup"]
            .sudo()
            .search_count([("room_status", "=", "o_clean"), ("function", "=", False)])
        )
        return clean_rooms_occupied

    # available_room & available_tonight
    def _compute_available_room(self):
        today = datetime.today()
        dm_room = self.env["hms.room.type"].search([("name", "=", "Dummy Room")]).id
        total_rooms = self.env["hms_room_setup"].search_count(
            [
                ("function", "=", False),
                ("name", "!=", "0"),
                ("room_type", "!=", dm_room),
            ]
        )
        reservline_count = (
            self.env["hotel.reservation"]
            .sudo()
            .search_count(
                [
                    ("Rsv_Type", "=", "registration"),
                    ("arrival_date", "<=", today),
                    ("departure_date", ">=", today),
                ]
            )
        )
        out_order = (
            self.env["hms_room_setup"]
            .sudo()
            .search_count([("room_status", "=", "ooo"), ("function", "=", False)])
        )
        out_service = (
            self.env["hms_room_setup"]
            .sudo()
            .search_count([("room_status", "=", "oos"), ("function", "=", False)])
        )
        available_room = total_rooms - reservline_count - out_order - out_service
        return available_room

    def _compute_available_tonight(self):
        date_from = datetime.today()
        available_tonight = (
            self.env["hms.registration"]
            .sudo()
            .search_count(
                [
                    ("Rsv_Type", "=", "registration"),
                    ("function_id", "=", "2"),
                    ("departure_date", "=", date_from),
                ]
            )
        )
        return available_tonight

    def _compute_occupied_tonight(self):
        today = datetime.today()
        occupied_tonight = (
            self.env["hms.registration"]
            .sudo()
            .search_count(
                [
                    ("departure_date", ">=", today),
                    ("Rsv_Type", "=", "registration"),
                    ("function_id", "=", "2"),
                ]
            )
        )
        return occupied_tonight

    def _compute_occupied_tonight_pax(self):
        today = datetime.today()
        sql = (
            """select COALESCE(SUM(reg_adult), 0),COALESCE(SUM(reg_child), 0) from hms_registration 
                where "Rsv_Type" = 'registration' and function_id = '2'
                and departure_date >= '%s' """
            % today
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            occupied_tonight_pax = record[0] + record[1]
            return occupied_tonight_pax

    def _compute_non_group(self):
        start_of_day = date.today()
        non_group = (
            self.env["hms.registration"]
            .sudo()
            .search_count(
                [
                    ("group_key", "=", "0"),
                    ("arrival_date", "=", start_of_day),
                    ("function_id", "=", "2"),
                ]
            )
        )
        return non_group

    def _compute_non_group_pax(self):
        start_of_day = date.today()
        sql = (
            """select COALESCE(SUM(reg_adult), 0),COALESCE(SUM(reg_child), 0)  from hms_registration  
                where "group_key" = '0' 
                and arrival_date = '%s' and function_id = '2'"""
            % start_of_day
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            non_group_pax = record[0] + record[1]
            return non_group_pax

    def _compute_group_room(self):
        start_of_day = date.today()
        end_of_day = datetime.combine(datetime.today() + timedelta(days=1), time.max)
        group_room = (
            self.env["hms.registration"]
            .sudo()
            .search_count(
                [
                    ("group_key", "!=", "0"),
                    ("arrival_date", "=", start_of_day),
                    ("function_id", "=", "2"),
                ]
            )
        )
        return group_room

    def _compute_group_pax(self):
        start_of_day = datetime.combine(datetime.today(), time.min)
        end_of_day = datetime.combine(datetime.today() + timedelta(days=1), time.max)
        sql = (
            """select COALESCE(SUM(reg_adult), 0),COALESCE(SUM(reg_child), 0)  from hms_registration  
                where "group_key" != '0' 
                and arrival_date = '%s' and function_id = '2'"""
            % start_of_day
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            group_pax = record[0] + record[1]
            return group_pax

    def _compute_house_use(self):
        house_use = (
            self.env["hotel.reservation"]
            .sudo()
            .search_count(
                [
                    ("Rsv_Type", "=", "confirmed"),
                    ("arrival_date", ">=", self.start_of_day),
                    ("departure_date", "<=", self.end_of_day),
                ]
            )
        )
        return house_use

    def _compute_house_use_pax(self):
        sql = """select COALESCE(SUM(adult), 0),COALESCE(SUM(child), 0) from hotel_reservation  
                where "Rsv_Type" = 'confirmed'
                and arrival_date >= '%s'
                and departure_date <= '%s' """ % (
            self.start_of_day,
            self.end_of_day,
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            house_use_pax = record[0] + record[1]
            return house_use_pax

    def _compute_complimentary(self):
        start_of_day = date.today()
        end_of_day = datetime.combine(datetime.today() + timedelta(days=1), time.max)
        sql = """select  count(hr.id) from hms_registration hr
                    join hms_customer_type ct  on hr.reg_customer_type = ct.id where ct.name = 'complimentary'
                    and hr.arrival_date >= '%s'
                    and hr.departure_date <= '%s' and hr.function_id = '2' """ % (
            start_of_day,
            end_of_day,
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            complimentary = record[0]
            return complimentary

    def _compute_complimentary_pax(self):
        start_of_day = date.today()
        end_of_day = datetime.combine(datetime.today() + timedelta(days=1), time.max)
        sql = """select  COALESCE(SUM(hr.reg_adult), 0),COALESCE(SUM(hr.reg_child), 0) from hms_registration hr
                    join hms_customer_type ct  on hr.reg_customer_type = ct.id where ct.name = 'complimentary'
                and hr.arrival_date >= '%s'
                and hr.departure_date <= '%s' and hr.function_id = '2' """ % (
            start_of_day,
            end_of_day,
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            complimentary_pax = record[0] + record[1]
            return complimentary_pax

    def _compute_expected_checkout(self):
        start_of_day = date.today()
        end_of_day = datetime.combine(datetime.today() + timedelta(days=1), time.max)
        sql = (
            """select  count(id) from hms_registration 
                    where "Rsv_Type" = 'registration' and  
                    departure_date = '%s' and function_id = '2'"""
            % start_of_day
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            expected_checkout = record[0]
            return expected_checkout

    def _compute_expected_checkout_pax(self):
        start_of_day = date.today()
        # start_of_day = datetime.combine(datetime.today(), time.min)
        sql = (
            """select COALESCE(SUM(reg_adult), 0),COALESCE(SUM(reg_child), 0) from hms_registration 
                    where "Rsv_Type" = 'registration' and
                    departure_date = '%s' and function_id = '2'"""
            % start_of_day
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            expected_checkout_pax = record[0] + record[1]
            return expected_checkout_pax

    def _compute_actual_checkout(self):
        start_of_day = date.today()
        sql = (
            """select  count(id) from hms_registration 
                    where "Rsv_Type" = 'check_out' and 
                    departure_date = '%s' and function_id = '2'"""
            % start_of_day
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            actual_checkout = record[0]
            return actual_checkout

    def _compute_actual_checkout_pax(self):
        start_of_day = date.today()
        sql = (
            """select COALESCE(SUM(reg_adult), 0),COALESCE(SUM(reg_child), 0) from hms_registration 
                    where "Rsv_Type" = 'check_out' and
                    departure_date = '%s' and function_id = '2' """
            % start_of_day
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            actual_checkout_pax = record[0] + record[1]
            return actual_checkout_pax

    def _compute_expected_arrival(self):
        end_of_day = date.today()
        sql = (
            """select count(id) from hotel_reservation 
                    where  arrival_date = '%s' and  "Rsv_Type" != 'registration' and "Rsv_Type" != 'cancel' and "Rsv_Type" != 'noshow'"""
            % end_of_day
        )

        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            expected_arrival = record[0]
            return expected_arrival

    def _compute_expected_arrival_pax(self):
        end_of_day = date.today()
        sql = (
            """select COALESCE(SUM(adult), 0),COALESCE(SUM(child), 0) from hotel_reservation 
                   where  arrival_date = '%s' and  "Rsv_Type" != 'registration' and "Rsv_Type" != 'cancel' and "Rsv_Type" != 'noshow' """
            % end_of_day
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            expected_arrival_pax = record[0] + record[1]
            return expected_arrival_pax

    def _compute_actual_arrival(self):
        end_of_day = date.today()
        sql = (
            """select  count(id) from hotel_reservation 
                    where "Rsv_Type" = 'registration' and 
                    arrival_date = '%s' """
            % end_of_day
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            actual_arrival = record[0]
            return actual_arrival

    def _compute_actual_arrival_pax(self):
        end_of_day = date.today()
        sql = (
            """select COALESCE(SUM(adult), 0),COALESCE(SUM(child), 0) from hotel_reservation 
                    where "Rsv_Type" = 'registration' and 
                                arrival_date = '%s'  """
            % end_of_day
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            actual_arrival_pax = record[0] + record[1]
            return actual_arrival_pax

    def _compute_extended_stay(self):
        today = date.today()
        sql = (
            """select count(hres.id) from hotel_reservation hres
                    Join hms_registration hr on hr.reservation_id = hres.id
                    where hres.intial_departure_date < hr.reg_departure and hr."Rsv_Type" = 'registration'
                    and hr.departure_date = '%s' """
            % today
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            extended_stay = record[0]
            return extended_stay

    def _compute_extended_stay_pax(self):
        end_of_day = date.today()
        sql = (
            """select COALESCE(SUM(hres.adult), 0),COALESCE(SUM(hres.child), 0) from hotel_reservation hres
                    Join hms_registration hr on hr.reservation_id = hres.id
                    where hres.intial_departure_date < hr.reg_departure 
                    and hr.function_id = '2' and hr."Rsv_Type" = 'registration' and hr.departure_date = '%s' """
            % end_of_day
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            extended_stay_pax = record[0] + record[1]
            return extended_stay_pax

    def _compute_early_departure(self):
        end_of_day = date.today()
        sql = (
            """select count(hres.id) from hotel_reservation hres
                    Join hms_registration hr on hr.reservation_id = hres.id
                    where hres.intial_departure_date > hr.reg_departure and hr."Rsv_Type" = 'check_out' and hr.departure_date = '%s' """
            % end_of_day
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            early_departure = record[0]
            return early_departure

    def _compute_early_departure_pax(self):
        end_of_day = date.today()
        sql = (
            """select COALESCE(SUM(hres.adult), 0),COALESCE(SUM(hres.child), 0) from hotel_reservation hres
                    Join hms_registration hr on hr.reservation_id = hres.id
                    where hres.intial_departure_date > hr.reg_departure 
                    and hr."Rsv_Type" = 'check_out' and hr.departure_date = '%s' """
            % end_of_day
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            early_departure_pax = record[0] + record[1]
            return early_departure_pax

    def _compute_day_use(self):
        today = date.today()
        sql = (
            """select count(id) from hms_registration 
                           where dayuse = 'True' and arrival_date = '%s' and function_id = '2'
                            """
            % today
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            day_use = record[0]
            return day_use

    def _compute_day_use_pax(self):
        today = date.today()
        sql = (
            """select COALESCE(SUM(reg_adult), 0),COALESCE(SUM(reg_child), 0) from hms_registration 
                            where dayuse = 'True' and arrival_date = '%s' and function_id = '2'"""
            % today
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            day_use_pax = record[0] + record[1]
            return day_use_pax

    def _compute_walk_in(self):
        today = date.today()
        sql = (
            """select COALESCE(SUM(reg_adult), 0),COALESCE(SUM(reg_child), 0) from hms_registration 
                where "iamregistered" = 'True'
                and arrival_date = '%s'and function_id = '2'"""
            % today
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            walk_in = record[0]
            return walk_in

    def _compute_walk_in_pax(self):
        today = date.today()
        sql = (
            """select COALESCE(SUM(reg_adult), 0),COALESCE(SUM(reg_child), 0) from hms_registration 
                where "iamregistered" = 'True'
                and arrival_date = '%s' and function_id = '2'"""
            % today
        )
        self.env.cr.execute(sql)
        result = self.env.cr.fetchall()
        for record in result:
            walk_in_pax = record[0] + record[1]
            return walk_in_pax

    def _compute_occupancy(self):
        occupied = (
            self.env["hms.registration"]
            .sudo()
            .search_count(
                [
                    ("arrival_date", "<=", self.start_of_day),
                    ("departure_date", ">=", self.date_from),
                    ("Rsv_Type", "=", "registration"),
                ]
            )
        )
        total_rooms = (
            self.env["hms_room_setup"].sudo().search_count([("function", "=", False)])
        )
        out_order = (
            self.env["hms_room_setup"]
            .sudo()
            .search_count([("room_status", "=", "ooo"), ("function", "=", False)])
        )
        out_service = (
            self.env["hms_room_setup"]
            .sudo()
            .search_count([("room_status", "=", "oos"), ("function", "=", False)])
        )
        available_room = total_rooms - out_order - out_service
        # ((SUM(OccRm) * 100) / (SUM(nTotalRoom) - (SUM(nOutOfOdrRm) + SUM(nOutOfSvrRm)))
        occrm = occupied * 100
        if not occrm < 1 or not available_room < 1:
            occupancy = occrm / available_room
            occupancy = round(occupancy, 2)
        else:
            occupancy = 0
        return occupancy

    def _compute_average_rate_us(self):
        start_of_day = datetime.combine(datetime.today(), time.min)
        end_of_day = datetime.combine(datetime.today() + timedelta(days=1), time.max)
        total_rr_us = """SELECT sum(room_rate) FROM HMS_ROOM_rate hr
                join res_currency c on hr.currency = c.id where c.name = 'USD' and 
                 from_date <= '%s'
                and to_date >= '%s'""" % (
            start_of_day,
            end_of_day,
        )
        self.env.cr.execute(total_rr_us)
        result = self.env.cr.fetchall()
        for record in result:
            total_rr_us = record[0]

        sum_room_amount = (
            """select sum(payment_amount) from hotel_bill hb
                                    join res_currency c on hb.currency = c.id 
                                    where c.name = 'USD' 
                                    and hb.bill_date = '%s'"""
            % start_of_day
        )
        self.env.cr.execute(sum_room_amount)
        r = self.env.cr.fetchall()
        for record in r:
            sum_room_amount = record[0]

        if total_rr_us and sum_room_amount:
            average_rate_us = total_rr_us / sum_room_amount
            average_rate_us = round(average_rate_us, 2)
            return average_rate_us
        else:
            average_rate_us = 0
            return average_rate_us

    def _compute_average_rate_mmk(self):
        start_of_day = datetime.combine(datetime.today(), time.min)
        end_of_day = datetime.combine(datetime.today() + timedelta(days=1), time.max)
        total_rr_mmk = """SELECT sum(room_rate) FROM HMS_ROOM_rate hr
                join res_currency c on hr.currency = c.id where c.name = 'MMK' and 
                 from_date <= '%s'
                and to_date >= '%s'""" % (
            start_of_day,
            end_of_day,
        )

        self.env.cr.execute(total_rr_mmk)
        result = self.env.cr.fetchall()
        for record in result:
            total_rr_mmk = record[0]

        sum_room_amount = (
            """select sum(payment_amount) from hotel_bill hb
                                    join res_currency c on hb.currency = c.id 
                                    where c.name = 'MMK' 
                                    and hb.bill_date = '%s'"""
            % start_of_day
        )
        self.env.cr.execute(sum_room_amount)
        result = self.env.cr.fetchall()
        for record in result:
            sum_room_amount = record[0]

        if total_rr_mmk and sum_room_amount:
            average_rate_mmk = total_rr_mmk / sum_room_amount
            average_rate_mmk = round(average_rate_mmk, 2)
            return average_rate_mmk
        else:
            average_rate_mmk = 0
            return average_rate_mmk

        # average_rate_mmk = total_rr_mmk / sum_room_amount
        # return average_rate_us

    name = fields.Char(default="House Status")
    today = datetime.today()
    current_date = datetime.now()
    date_from = datetime.today()
    date_to = datetime.today() + timedelta(days=1)
    start_of_day = datetime.combine(datetime.today(), time.min)
    end_of_day = datetime.combine(datetime.today() + timedelta(days=1), time.max)

    # Rooms
    #     total_rr_us = fields.Integer("Cancellation",readonly=True,default=_compute_total_rr_us,store='True')
    #     sum_room_amount = fields.Integer("Cancellation",readonly=True,default=_compute_sum_room_amount,store='True')

    cancellation = fields.Integer(
        "Cancellation",
        readonly=True,
        default=_default_compute_cancellation,
        store="True",
    )
    no_show = fields.Integer(
        "No Show", readonly=True, default=_compute_no_show, store="True"
    )
    non_group = fields.Integer(
        "Non Group", readonly=True, default=_compute_non_group, store="True"
    )
    group_room = fields.Integer(
        "Group", readonly=True, default=_compute_group_room, store="True"
    )
    house_use = fields.Integer(
        "House Use", readonly=True, default=_compute_house_use, store="True"
    )
    complimentary = fields.Integer(
        "Complimentary", readonly=True, default=_compute_complimentary, store="True"
    )
    expected_checkout = fields.Integer(
        default=_compute_expected_checkout, readonly=True, store="True"
    )
    actual_checkout = fields.Integer(
        "Actual checkout", readonly=True, default=_compute_actual_checkout, store="True"
    )
    expected_arrival = fields.Integer(
        "Expected Arrival  ",
        readonly=True,
        default=_compute_expected_arrival,
        store="True",
    )
    actual_arrival = fields.Integer(
        "actual_arrival", readonly=True, default=_compute_actual_arrival, store="True"
    )
    extended_stay = fields.Integer(
        "extended_stay", readonly=True, default=_compute_extended_stay, store="True"
    )
    early_departure = fields.Integer(
        "early_departure", readonly=True, default=_compute_early_departure, store="True"
    )
    day_use = fields.Integer(
        "day_use", readonly=True, default=_compute_day_use, store="True"
    )
    walk_in = fields.Integer(
        "walk_in", readonly=True, default=_compute_walk_in, store="True"
    )
    occupied_tonight = fields.Integer(
        "Occupied tonight",
        readonly=True,
        default=_compute_occupied_tonight,
        store="True",
    )

    # # Single
    total_rooms = fields.Integer(
        "Total Rooms", readonly=True, default=_compute_total_rooms, store="True"
    )
    out_order = fields.Integer(
        "Out of Orders Rooms", readonly=True, default=_compute_out_order, store="True"
    )
    out_service = fields.Integer(
        "Out of Service Rooms",
        readonly=True,
        default=_compute_out_service,
        store="True",
    )
    available_room = fields.Integer(
        "Available Room", readonly=True, default=_compute_available_room, store="True"
    )
    available_tonight = fields.Integer(
        "Available tonight Room",
        readonly=True,
        default=_compute_available_tonight,
        store="True",
    )
    occupancy = fields.Char(
        "Occupancy", default=_compute_occupancy, readonly=True, store="True"
    )
    average_rate_us = fields.Char(
        "Average Rate", default=_compute_average_rate_us, readonly=True, store="True"
    )
    average_rate_mmk = fields.Char(
        "Average Rate", default=_compute_average_rate_mmk, readonly=True, store="True"
    )
    # # OccupiedVacant
    dirty_rooms_occupied = fields.Integer(
        "Dirty Rooms(Occupied)",
        readonly=True,
        default=_compute_dirty_rooms_occupied,
        store="True",
    )
    clean_rooms_occupied = fields.Integer(
        "Clean  Rooms(Occupied)",
        readonly=True,
        default=_compute_clean_rooms_occupied,
        store="True",
    )
    dirty_rooms_occupied_vacant = fields.Integer(
        "Dirty Rooms(Vacant)",
        readonly=True,
        default=_compute_dirty_rooms_occupied_vacant,
        store="True",
    )
    clean_rooms_occupied_vacant = fields.Integer(
        "Clean Rooms(Vacant)",
        readonly=True,
        default=_compute_clean_rooms_occupied_vacant,
        store="True",
    )
    reservation_count = fields.Integer(
        "Registration", store="True", readonly=True, default=_default_total_reservation
    )

    # pax Calculation
    cancellation_pax = fields.Integer(
        "cancellation_pax",
        readonly=True,
        default=_compute_cancellation_pax,
        store="True",
    )
    no_show_pax = fields.Integer(
        "no_show_pax", readonly=True, default=_compute_no_show_pax, store="True"
    )
    non_group_pax = fields.Integer(
        "non_group_pax", readonly=True, default=_compute_non_group_pax, store="True"
    )
    group_pax = fields.Integer(
        "group_pax", readonly=True, default=_compute_group_pax, store="True"
    )
    house_use_pax = fields.Integer(
        "house_use_pax", readonly=True, default=_compute_house_use_pax, store="True"
    )
    complimentary_pax = fields.Integer(
        "complimentary_pax",
        readonly=True,
        default=_compute_complimentary_pax,
        store="True",
    )
    expected_checkout_pax = fields.Integer(
        "expected_checkout_pax",
        readonly=True,
        default=_compute_expected_checkout_pax,
        store="True",
    )
    actual_checkout_pax = fields.Integer(
        "actual_checkout_pax",
        readonly=True,
        default=_compute_actual_checkout_pax,
        store="True",
    )
    expected_arrival_pax = fields.Integer(
        "expected_arrival_pax",
        readonly=True,
        default=_compute_expected_arrival_pax,
        store="True",
    )
    actual_arrival_pax = fields.Integer(
        "actual_arrival_pax",
        readonly=True,
        default=_compute_actual_arrival_pax,
        store="True",
    )
    extended_stay_pax = fields.Integer(
        "extended_stay_pax",
        readonly=True,
        default=_compute_extended_stay_pax,
        store="True",
    )
    early_departure_pax = fields.Integer(
        "early_departure_pax",
        readonly=True,
        default=_compute_early_departure_pax,
        store="True",
    )
    day_use_pax = fields.Integer(
        "day_use_pax", readonly=True, default=_compute_day_use_pax, store="True"
    )
    walk_in_pax = fields.Integer(
        "walk_in_pax", readonly=True, default=_compute_walk_in_pax, store="True"
    )
    occupied_tonight_pax = fields.Integer(
        "Occupied tonight pax",
        readonly=True,
        default=_compute_occupied_tonight_pax,
        store="True",
    )
