from odoo import api, fields, models, tools, _


class quickClean(models.Model):
    _name = "hms.quick.clean"
    _description = "HMS Quick Clean"
    _order = "id DESC"

    from_room_no = fields.Char("From Room No.")
    to_room_no = fields.Char("To Room No.")

    def go_clean(self):
        for rec in self:
            room_setup_sql = (
                """select id from hms_room_setup where  name between '%s'  and  '%s' """
                % (rec.from_room_no, rec.to_room_no)
            )
            self.env.cr.execute(room_setup_sql)
            room_result = self.env.cr.fetchall()
            if room_result:
                for result in room_result:
                    update_room_setup = (
                        """UPDATE hms_room_setup SET room_status='v_clean'  WHERE id=%s"""
                        % int(result[0])
                    )
                    self.env.cr.execute(update_room_setup)
                # rs_amt = float(result[0][0])
            return {
                "type": "ir.actions.client",
                "tag": "reload",
            }
