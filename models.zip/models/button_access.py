from collections import defaultdict
from lxml import etree

from odoo import models, fields, api, _
from odoo.exceptions import UserError
from odoo.tools import float_compare, frozendict


class ButtonAccess(models.Model):
    _name = "button.access.group"
    _description = "Button Access Group"

    group = fields.Many2one("res.groups")
    view = fields.Many2one("ir.ui.view")
    name = fields.Char("Button Name")
    buttons = fields.Many2many(
        "button.names",
        "button_access_button_names_rel",
        "button_access_id",
        "button_name_id",
        "Buttons",
    )
    groups = fields.Many2many(
        "res.groups",
        "button_access_res_groups_rel",
        "button_access_id",
        "group_id",
        "Groups",
    )

    @api.model
    def create(self, vals):
        view_id = vals["view"]
        view = self.env["ir.ui.view"].browse(view_id)
        doc = etree.XML(view.arch_db)

        # buttons = vals.pop('buttons', [])
        button_access = super(ButtonAccess, self).create(vals)
        for button_id in button_access.buttons:
            button = doc.xpath("//button[@string='%s']" % button_id.name)[0]
            groups = ""
            for group_id in button_access.groups:
                group_name = (
                    self.env["ir.model.data"]
                    .search(
                        [("model", "=", "res.groups"), ("res_id", "=", group_id.id)]
                    )
                    .complete_name
                )
                if groups == "":
                    groups += group_name
                else:
                    groups += "," + group_name
            if button.get("groups"):
                button.set("groups", button.get("groups") + "," + groups)
            else:
                button.set("groups", groups)
        view.write({"arch_db": etree.tostring(doc, encoding="unicode")})

        return button_access

    def unlink(self):
        for record in self:
            view = self.env["ir.ui.view"].browse(self.view.id)
            doc = etree.XML(view.arch_db)
            for button_name in self.buttons:
                button = doc.xpath("//button[@string='%s']" % button_name.name)[0]
                button_groups_string = button.get("groups")
                if button_groups_string:
                    button_groups_list = button_groups_string.split(",")
                    button_groups_string_finally = ""
                    for group_id in record.groups:
                        group_name = (
                            self.env["ir.model.data"]
                            .search(
                                [
                                    ("model", "=", "res.groups"),
                                    ("res_id", "=", group_id.id),
                                ]
                            )
                            .complete_name
                        )
                        if group_name in button_groups_list:
                            button_groups_list.remove(group_name)
                    if len(button_groups_list) >= 1:
                        button_groups_string_finally = ",".join(button_groups_list)
                        button.set("groups", button_groups_string_finally)
                    else:
                        button.set("groups", "")
            view.write({"arch_db": etree.tostring(doc, encoding="unicode")})
            button_access = super(ButtonAccess, record).unlink()

    def write(self, vals):
        current_view = self.view
        current_button_access = self.buttons
        current_button_access_list = list(current_button_access.mapped("id"))
        current_groups = self.groups
        current_groups_list = list(current_groups.mapped("id"))
        button_access_updated = super(ButtonAccess, self).write(vals)
        updated_button_access = self.env["button.access.group"].search(
            [("id", "=", self.id)]
        )
        updated_groups = updated_button_access.groups
        updated_groups_list = list(updated_groups.mapped("id"))
        updated_buttons = updated_button_access.buttons
        updated_buttons_list = list(updated_buttons.mapped("id"))

        if current_view == updated_button_access.view:
            view = self.env["ir.ui.view"].browse(current_view.id)
            doc = etree.XML(view.arch_db)

            for updated_button in updated_button_access.buttons:
                # existing button group updated case
                if updated_button.id in current_button_access_list:
                    button = doc.xpath("//button[@string='%s']" % updated_button.name)[
                        0
                    ]
                    button_groups_string = button.get("groups")
                    if button_groups_string:
                        button_groups_list = button_groups_string.split(",")
                    remove_groups = []
                    add_groups = []
                    for current_group in current_groups_list:
                        if current_group not in updated_groups_list:
                            remove_groups.append(current_group)
                    for updated_group in updated_groups_list:
                        if updated_group not in current_groups_list:
                            add_groups.append(updated_group)
                    # remove groups
                    if len(remove_groups) >= 1 and len(button_groups_list) >= 1:
                        for remove_group in remove_groups:
                            remove_group_name = (
                                self.env["ir.model.data"]
                                .search(
                                    [
                                        ("model", "=", "res.groups"),
                                        ("res_id", "=", remove_group),
                                    ]
                                )
                                .complete_name
                            )
                            button_groups_list.remove(remove_group_name)
                        if len(button_groups_list) >= 1:
                            button.set("groups", ",".join(button_groups_list))
                    # add groups
                    if len(add_groups) >= 1:
                        add_groups_names = []
                        for add_group in add_groups:
                            group_name = (
                                self.env["ir.model.data"]
                                .search(
                                    [
                                        ("model", "=", "res.groups"),
                                        ("res_id", "=", add_group),
                                    ]
                                )
                                .complete_name
                            )
                            add_groups_names.append(group_name)
                        add_groups_names_string = ",".join(add_groups_names)
                        button.set(
                            "groups",
                            button.get("groups") + "," + add_groups_names_string,
                        )
                # new button added case
                if updated_button.id not in current_button_access_list:
                    button = doc.xpath("//button[@string='%s']" % updated_button.name)[
                        0
                    ]
                    add_groups_names = []
                    for updated_group in updated_groups_list:
                        group_name = (
                            self.env["ir.model.data"]
                            .search(
                                [
                                    ("model", "=", "res.groups"),
                                    ("res_id", "=", updated_group),
                                ]
                            )
                            .complete_name
                        )
                        add_groups_names.append(group_name)

                    add_groups_names_string = ",".join(add_groups_names)
                    if button.get("groups"):
                        button.set(
                            "groups",
                            button.get("groups") + "," + add_groups_names_string,
                        )
                    else:
                        button.set("groups", add_groups_names_string)
            # button delete case
            for current_button in current_button_access:
                if current_button.id not in updated_buttons_list:
                    button = doc.xpath("//button[@string='%s']" % current_button.name)[
                        0
                    ]
                    button_groups_string = button.get("groups")
                    if button_groups_string:
                        button_groups_list = button_groups_string.split(",")
                    for updated_group in updated_groups_list:
                        group_name = (
                            self.env["ir.model.data"]
                            .search(
                                [
                                    ("model", "=", "res.groups"),
                                    ("res_id", "=", updated_group),
                                ]
                            )
                            .complete_name
                        )
                        if button_groups_list and group_name in button_groups_list:
                            button_groups_list.remove(group_name)
                    if len(button_groups_list) >= 1:
                        remove_groups_names_string = ",".join(button_groups_list)
                        button.set("groups", remove_groups_names_string)
                    else:
                        button.set("groups", "")

            view.write({"arch_db": etree.tostring(doc, encoding="unicode")})
        return button_access_updated

    @api.onchange("view")
    def createButtonNames(self):
        view = self.env["ir.ui.view"].browse(self.view.id)
        if view:
            doc = etree.XML(view.arch_db)
            buttons = doc.xpath("//button")
            for existing_button in self.buttons:
                if self.view != existing_button.view_id:
                    self.buttons = False

            for button in buttons:
                button_name = self.env["button.names"].search(
                    [
                        ("view_id", "=", self.view.id),
                        ("name", "=", button.get("string")),
                    ]
                )
                if not button_name:
                    button = self.env["button.names"].create(
                        {"name": button.get("string"), "view_id": self.view.id}
                    )
            domain = [("view_id", "=", self.view.id)]
            return {"domain": {"buttons": domain}}


class ButtonName(models.Model):
    _name = "button.names"
    _description = "Button Names"

    view_id = fields.Many2one("ir.ui.view")
    name = fields.Char("Name")
