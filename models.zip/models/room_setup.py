from datetime import datetime, date, timedelta
import pytz
import logging
from datetime import date

from werkzeug.urls import url_encode
from odoo import fields, models, api
from odoo.exceptions import ValidationError
from odoo.tools import datetime
from odoo import _, http
from odoo.exceptions import UserError

from datetime import datetime, timedelta, date

from dateutil.relativedelta import relativedelta
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT as dt
import logging

_logger = logging.getLogger(__name__)

try:
    import pytz
except (ImportError, IOError) as err:
    _logger.debug(err)


class RoomSetup(models.Model):
    _name = "hms_room_setup"
    _description = "Room Set up"

    name = fields.Char(String="Name", tracking=True, translate=True)
    room_status = fields.Selection(
        [
            ("v_clean", "Vacant Clean"),
            ("v_dirty", "Vacant Dirty"),
            ("o_clean", "Occupied Clean"),
            ("o_dirty", "Occupied Dirty"),
            ("oos", "Out of Service"),
            ("ooo", "Out of Order"),
        ],
        String="Room Status",
        default="v_clean",
        tracking=True,
        translate=True,
    )

    bed_type = fields.Selection(
        [
            ("single", "Single"),
            ("double", "Double"),
            ("twin", "Twin"),
        ],
        String="Bed Type",
        default="single",
        tracking=True,
        translate=True,
    )

    no_of_bed = fields.Selection(
        [
            ("1", "1"),
            ("2", "2"),
            ("3", "3"),
            ("4", "4"),
        ],
        String="No of Bed",
        default="1",
        tracking=True,
        translate=True,
    )

    room_type = fields.Many2one(
        "hms.room.type", String="Room Type", ondelete="set null"
    )
    customer_type = fields.Many2one(
        "hms.customer_type", String="Customer Type", ondelete="set null"
    )
    is_smoking_room = fields.Boolean(String="Smoking Room", default=False)
    is_active = fields.Boolean(String="Active", default=True)
    room_category = fields.Char(
        string="Category", compute="_compute_category", readonly=True
    )
    room_image = fields.Image("Room Image")
    room_rate = fields.Float("room rate", compute="_compute_room_rate")
    function = fields.Boolean("function_room")
    location = fields.Char()

    def copy_room_name(self):
        name = 0
        for rec in self:
            name = rec.id
        return name

    @api.constrains('name')
    def _check_unique_name(self):
        # Check if there is any other record with the same name
        duplicates = self.search([('name', '=', self.name), ('id', '!=', self.id)])
        if duplicates:
            raise ValidationError('Room no. Already Exist!!.')

    @api.depends_context("room_type")
    def _compute_category(self):
        for record in self:
            category = record.room_type.category
            record.room_category = category

    @api.onchange("room_type", "customer_type")
    def _compute_room_rate(self):
        for room in self:
            rateData = self.env["hms_room_rate"].search(
                [
                    ("room_type", "=", room.room_type.id),
                    ("customer_type", "=", room.customer_type.id),
                ],
                limit=1,
            )
            room.room_rate = rateData.room_rate

    @api.model
    def create(self, vals):
        room_setup = super(RoomSetup, self).create(vals)

        discount_line_product_id = self.env["product.product"].create(
            {
                "name": vals.get("name"),
                "type": "service",
                "taxes_id": False,
                "supplier_taxes_id": False,
                "sale_ok": False,
                "purchase_ok": False,
                "lst_price": 0,  # Do not set a high value to avoid issue with coupon code
            }
        )
        # roomreserv_id = self.env['hotel.reservation'].create(
        #     {
        #         'room_no': room_setup.id,
        #         'room_type': room_setup.room_type.id,
        #         'name': 'room',
        #         'arrival': False,
        #         'departure': False
        #     }
        # )

        return room_setup

    def write(self, vals):
        room_setup = super(RoomSetup, self).write(vals)
        if "room_status" in vals and vals["room_status"] == "v_clean":
            arrival_overbook = self.env["hotel.reservation"].search(
                [
                    ("room_no", "=", self.id),
                    ("arrival_date", "=", date.today()),
                    ("overbook", "=", True),
                ]
            )
            if arrival_overbook:
                arrival_overbook.write({"overbook": False})

        # roomreserv_id = self.env['hotel.reservation'].create(
        #     {
        #         'room_no': room_setup.id,
        #         'room_type': room_setup.room_type.id,
        #         'name': 'room',
        #         'arrival': False,
        #         'departure': False
        #     }
        # )

        return room_setup

    # def write(self, vals):
    #     if 'room_type' in vals:
    #         reservation = self.env['hotel.reservation'].search(
    #             [('name', '=', 'room'), ('room_no', '=', self.id)])
    #         if reservation:
    #             reservation.write(
    #                 {
    #                     'room_type': vals['room_type']
    #                 }
    #             )
    #
    #     room_setup = super(RoomSetup, self).write(vals)
    #     return room_setup
    #
    # def unlink(self):
    #     for rec in self:
    #         reservation = self.env['hotel.reservation'].search(
    #             [('name', '=', 'room'), ('room_no', '=', rec.id)])
    #         reservation.unlink()
    #         room_setup = super(RoomSetup, rec).unlink()

    def name_get(self):
        res = []
        fname = ""
        for rec in self:
            if rec.name and rec.room_type.category:
                fname = rec.room_type.category + "-" + rec.name
            else:
                fname = rec.name
            res.append((rec.id, fname))
        return res

    def go_houseStatus(self):
        for rec in self:
            return {
                "name": "Room Setup",
                "type": "ir.actions.act_window",
                "view_type": "form",
                "view_mode": "form",
                "res_model": "hms_room_setup",
                "res_id": self.id,
            }

    def change_clean(self):
        occupied_clean = (
            self.env["hms.registration"]
            .sudo()
            .search(
                [
                    ("reg_room_type", "=", self.room_type.id),
                    ("reg_room_no.name", "=", self.name),
                    ("Rsv_Type", "=", "registration"),
                ]
            )
        )
        vacant_clean = (
            self.env["hms.registration"]
            .sudo()
            .search(
                [
                    ("reg_room_type", "=", self.room_type.id),
                    ("reg_room_no.name", "=", self.name),
                    ("Rsv_Type", "=", "check_out"),
                ]
            )
        )
        _logger.info(f"occupied_clean: {occupied_clean}")
        _logger.info(f"vacant_clean:: {vacant_clean:}")
        if occupied_clean:
            return super(RoomSetup, self).write({"room_status": "o_clean"})
        elif vacant_clean:
            return super(RoomSetup, self).write({"room_status": "v_clean"})
        
       
        
    def change_dirty(self):
        occupied_dirty = (
            self.env["hms.registration"]
            .sudo()
            .search(
                [
                    ("reg_room_type", "=", self.room_type.id),
                    ("reg_room_no.name", "=", self.name),
                    ("Rsv_Type", "=", "registration"),
                ]
            )
        )
        vacant_dirty = (
            self.env["hms.registration"]
            .sudo()
            .search(
                [
                    ("reg_room_type", "=", self.room_type.id),
                    ("reg_room_no.name", "=", self.name),
                    ("Rsv_Type", "=", "check_out"),
                ]
            )
        )
        _logger.info(f"occupied_dirty: {occupied_dirty}")
        _logger.info(f"vacant_dirty: {vacant_dirty}")
        if occupied_dirty:
            return super(RoomSetup, self).write({"room_status": "o_dirty"})
        elif vacant_dirty:
            return super(RoomSetup, self).write({"room_status": "v_dirty"})
        
        
        
class RoomReservationSummary(models.Model):
    _name = "hotelia.room.reservation.summary"
    _description = "Room reservation summary"

    name = fields.Char("Reservation Summary", default="Reservations Summary")
    date_from = fields.Datetime("Date From", default=lambda self: fields.Date.today())
    date_to = fields.Datetime(
        "Date To",
        default=lambda self: fields.Date.today() + relativedelta(days=30),
    )
    summary_header = fields.Text("Summary Header")
    room_summary = fields.Text("Room Summary")

    def compute_daterange(self, month):
        """
        Give a month as an integer.\n
        Compute the first and last dates of that month.\n
        Return a tuple containing the first date and last date.
        """
        current_year = datetime.now().year
        first_date = date(current_year, month, 1)

        if month == 12:
            next_month = 1
            next_year = current_year + 1
        else:
            next_month = month + 1
            next_year = current_year

        last_date = date(next_year, next_month, 1) - timedelta(days=1)

        return (first_date, last_date)

    @api.onchange("date_from", "date_to")  # noqa C901 (function is too complex)
    def get_room_summary(self):  # noqa C901 (function is too complex)
        """
        @param self: object pointer
        """
        res = {}
        all_detail = []
        room_obj = self.env["hms.room.type"]
        reservation_line_obj = self.env["hotel.reservation"]
        date_range_list = []
        main_header = []
        summary_header_list = [{"date": " ", "weekend": False, "class": False}]
        if self.date_from and self.date_to:
            if self.date_from > self.date_to:
                raise UserError(_("Checkout date should be greater than Checkin date."))
            if self._context.get("tz", False):
                timezone = pytz.timezone(self._context.get("tz", False))
            else:
                timezone = pytz.timezone("UTC")
            d_frm_obj = (
                (self.date_from)
                .replace(tzinfo=pytz.timezone("UTC"))
                .astimezone(timezone)
            )
            d_to_obj = (
                (self.date_to).replace(tzinfo=pytz.timezone("UTC")).astimezone(timezone)
            )
            temp_date = d_frm_obj
            while temp_date <= d_to_obj:
                val = ""
                header = {}

                if str(temp_date.strftime("%d")) == "01" or temp_date == d_frm_obj:
                    val = (
                        str(temp_date.strftime("%b"))
                        + " "
                        + str(temp_date.strftime("%d"))
                    )
                    header = {
                        "date": val,
                        "weekend": (
                            str(temp_date.strftime("%a")) == "Sat"
                            or str(temp_date.strftime("%a")) == "Sun"
                        ),
                        "class": True,
                    }

                else:
                    val = str(temp_date.strftime("%d"))
                    header = {
                        "date": val,
                        "weekend": (
                            str(temp_date.strftime("%a")) == "Sat"
                            or str(temp_date.strftime("%a")) == "Sun"
                        ),
                        "class": False,
                    }
                summary_header_list.append(header)
                date_range_list.append(temp_date.strftime(dt))
                temp_date = temp_date + timedelta(days=1)
            all_detail.append(summary_header_list)
            room_type_ids = room_obj.search(
                [("name", "!=", "Dummy Room"), ("function", "=", False)]
            )
            all_room_detail = []
            dm_room = self.env["hms.room.type"].search([("name", "=", "Dummy Room")]).id
            total_rooms = self.env["hms_room_setup"].search_count(
                [("room_type", "!=", dm_room), ("function", "=", False)]
            )
            total_stats = []
            assigned_stats = []
            unassigned_stats = []
            overbooked_stats = []
            for room_type in room_type_ids:
                room_detail = {}
                room_list_stats = []
                total_count = self.env["hms_room_setup"].search_count(
                    [("room_type", "=", room_type.id)]
                )
                if room_type.category:
                    name = room_type.category + " (" + str(total_count) + ")"

                    room_detail.update({"name": name or "", "total": False})

                    for chk_date in date_range_list:
                        ch_dt = chk_date[:10] + " 23:59:59"
                        ttime = datetime.strptime(ch_dt, dt)
                        c = ttime.replace(tzinfo=timezone).astimezone(
                            pytz.timezone("UTC")
                        )
                        chk_date = c.strftime(dt)
                        weekend = False
                        if (
                            str(c.strftime("%a")) == "Sat"
                            or str(c.strftime("%a")) == "Sun"
                        ):
                            weekend = True
                        reservline_count = reservation_line_obj.search_count(
                            [
                                ("room_type", "=", room_type.id),
                                ("arrival_date", "<=", chk_date),
                                # ("departure_date", ">=", chk_date),
                                ("departure_date", ">", chk_date),
                                ("Rsv_Type", "=", "registration"),
                            ]
                        )

                        today_count = total_count - reservline_count
                        color = False
                        if today_count < 0:
                            today_count = 0
                            color = True
                        if today_count < total_count:
                            color = True
                        room_list_stats.append(
                            {
                                "today_count": str(today_count),
                                "date": chk_date,
                                "room_id": room_type.id,
                                "status": "rooms",
                                "weekend": weekend,
                                "color": color,
                            }
                        )

                    room_detail.update({"value": room_list_stats})
                    all_room_detail.append(room_detail)

            room_no_zero = self.env["hms_room_setup"].search(
                [("name", "=", "0"), ("room_type", "!=", dm_room)]
            )
            # room_no = self.env["hms_room_setup"].search([])
            for chk_date in date_range_list:
                total_available_count = 0
                ch_dt = chk_date[:10] + " 23:59:59"
                ttime = datetime.strptime(ch_dt, dt)
                c = ttime.replace(tzinfo=timezone).astimezone(pytz.timezone("UTC"))
                overbooked_reservation_ids = set()
                chk_date = c.strftime(dt)
                for room_type in room_type_ids:
                    overbooked_reservations = reservation_line_obj.search(
                        [
                            # ("room_type", "=", room_type.id),
                            ("arrival_date", "<=", chk_date),
                            ("departure_date", ">=", chk_date),
                            ("overbook", "=", True),
                            (
                                "Rsv_Type",
                                "not in",
                                [
                                    "cancel",
                                    "check_out",
                                    "transfer",
                                    "noshow",
                                    "registration",
                                ],
                            ),
                        ]
                    )
                    for reservation in overbooked_reservations:
                        if reservation.id not in overbooked_reservation_ids:
                            if reservation.overbook:
                                overbooked_reservation_ids.add(reservation.id)

                    total_count = self.env["hms_room_setup"].search_count(
                        [("room_type", "=", room_type.id)]
                    )
                    reservline_count = reservation_line_obj.search_count(
                        [
                            ("room_type", "=", room_type.id),
                            ("arrival_date", "<=", chk_date),
                            # ("departure_date", ">=", chk_date),
                            ("departure_date", ">", chk_date),
                            ("Rsv_Type", "=", "registration"),
                        ]
                    )
                    today_count = total_count - reservline_count
                    if today_count < 0:
                        today_count = 0
                    total_available_count += today_count
                total_color = False
                assign_color = False
                unassign_color = False
                overbook_color = False

                weekend = False
                if str(c.strftime("%a")) == "Sat" or str(c.strftime("%a")) == "Sun":
                    weekend = True

                total_room_assigned_count = reservation_line_obj.search_count(
                    [
                        ("room_no", "!=", False),
                        ("room_type", "!=", dm_room),
                        ("arrival_date", "<=", chk_date),
                        ("departure_date", ">=", chk_date),
                        ("overbook", "=", False),
                        (
                            "Rsv_Type",
                            "not in",
                            [
                                "cancel",
                                "check_out",
                                "transfer",
                                "noshow",
                                "registration",
                            ],
                        ),
                    ]
                )
                total_room_unassigned_count = reservation_line_obj.search_count(
                    [
                        ("room_no", "=", False),
                        ("room_type", "!=", dm_room),
                        ("arrival_date", "<=", chk_date),
                        ("departure_date", ">=", chk_date),
                        ("overbook", "=", False),
                        (
                            "Rsv_Type",
                            "not in",
                            [
                                "cancel",
                                "check_out",
                                "transfer",
                                "noshow",
                                "registration",
                            ],
                        ),
                    ]
                )
                if total_available_count < total_rooms:
                    total_color = True

                overbooked_count = len(overbooked_reservation_ids)

                if total_room_assigned_count > 0:
                    assign_color = True
                if total_room_unassigned_count > 0:
                    unassign_color = True
                if overbooked_count > 0:
                    overbook_color = True
                total_stats.append(
                    {
                        "today_count": str(total_available_count),
                        "date": chk_date,
                        "room_id": 0,
                        "status": "total",
                        "weekend": weekend,
                        "color": total_color,
                    }
                )
                assigned_stats.append(
                    {
                        "today_count": str(total_room_assigned_count),
                        "date": chk_date,
                        "room_id": 0,
                        "status": "assigned",
                        "weekend": weekend,
                        "color": assign_color,
                    }
                )

                unassigned_stats.append(
                    {
                        "today_count": str(total_room_unassigned_count),
                        "date": chk_date,
                        "room_id": 0,
                        "status": "unassigned",
                        "weekend": weekend,
                        "color": unassign_color,
                    }
                )

                overbooked_stats.append(
                    {
                        "today_count": str(overbooked_count),
                        "date": chk_date,
                        "room_id": 0,
                        "status": "overbooked",
                        "weekend": weekend,
                        "color": overbook_color,
                    }
                )

            all_room_detail.append(
                {
                    "name": "Total (%s)" % total_rooms,
                    "total": True,
                    "value": total_stats,
                }
            )
            all_room_detail.append(
                {
                    "name": "Assigned",
                    "total": False,
                    "value": assigned_stats,
                }
            )

            all_room_detail.append(
                {
                    "name": "Unassigned",
                    "total": False,
                    "value": unassigned_stats,
                }
            )

            all_room_detail.append(
                {
                    "name": "Overbooking",
                    "total": False,
                    "value": overbooked_stats,
                }
            )

            main_header.append({"header": summary_header_list})
            self.summary_header = str(main_header)
            self.room_summary = str(all_room_detail)
        return res

    def go_houseStatus(self):
        for rec in self:
            return {
                "name": "Room Setup",
                "type": "ir.actions.act_window",
                "view_type": "form",
                "view_mode": "form",
                "res_model": "hms_room_setup",
                "res_id": self.id,
            }
