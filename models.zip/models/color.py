from odoo import api, fields, models


class color(models.Model):
    _name = "hotel.color"
    _description = "colors setup"
    _order = "id DESC"

    name = fields.Selection(
        [
            ("open", "Open"),
            ("confirmed", "Confirm"),
            ("waitlist", "Waitlist"),
            ("registration", "Registration"),
        ],
        string="status",
    )
    color = fields.Char(string="color")

    # bread crumbs
    def name_get(self):
        result = []
        for rec in self:
            name = str(rec.id)
            result.append((rec.id, name))
        return result
