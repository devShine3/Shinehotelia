from . import room_types
from . import guest
from . import message
from . import color
from . import bill
from . import payment
from . import payment_line
from . import res_partner
from . import national
from . import hms_name
from . import amenity
from . import transaction
from . import room_status
from . import room_setup
from . import room_rate
from . import group_summary
from . import reservation
from . import ui
from . import roomreserv
from . import booking_chart
from . import agentsetup
from . import companysetup
from . import registration
from . import folio
from . import reservationPopup
from . import dashboard
from . import quick_clean
from . import group_reserve
from . import systemconfig
from . import night_audit

# from . import booking_chart_config
# from . import setting
from . import function_room
from . import customer_type

# functional room
from . import functional_room
from . import function_room

# timeline
from . import timeline
from . import room_transfer

from . import button_access
from . import currency
from . import account_move
from . import cancel_transaction


# Housestatus
from . import house_status

# package
from . import package
from . import update_group_right

from . import product
from . import product_category
from . import minibar_transaction
from . import delivery_order
from . import group_room_list