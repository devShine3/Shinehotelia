from odoo import fields, models, api


class ResconfigSettings(models.TransientModel):
    _inherit = "res.config.settings"
    _name = "new.settings"

    isGuestNameChecked = fields.Boolean(
        "Name", config_parameter="hotelia.isGuestNameChecked"
    )
    isIdChecked = fields.Boolean("IC", config_parameter="hotelia.isIdChecked")
    isGroupNameChecked = fields.Boolean(
        "Group", config_parameter="hotelia.isGroupNameChecked"
    )
    isAgentChecked = fields.Boolean("Agent", config_parameter="hotelia.isAgentChecked")
    isCompanyChecked = fields.Boolean(
        "Company", config_parameter="hotelia.isCompanyChecked"
    )
    isPhoneChecked = fields.Boolean("Phone", config_parameter="hotelia.isPhoneChecked")
    backdate_allow = fields.Boolean(
        "Backdate", config_parameter="hotelia.backdate_allow"
    )
    room_charge_auto = fields.Boolean(
        "Room Rate", config_parameter="hotelia.room_charge_auto"
    )

    minibar_erp = fields.Boolean("Minibar ERP", config_parameter="hotelia.minibar_erp")

    service_inclusive = fields.Boolean('Service Inclusive', config_parameter='hotelia.service_inclusive')
    service_percent = fields.Integer('Service Percent', config_parameter="hotelia.service_percent")

    tax_inclusive = fields.Boolean('Tax Inclusive', config_parameter="hotelia.tax_inclusive")
    tax_percent = fields.Integer('Tax Percent', config_parameter="hotelia.tax_percent")

    na_transaction_date = fields.Boolean("Transaction Date", config_parameter="hotelia.na_transaction_date", default=False)

    # for booking chart font sizes
    fontSize = fields.Char(
        "Font Size", config_parameter="hotelia.fontSize", default="12"
    )
    check_out_time = fields.Integer(
        "Check Out", config_parameter="hotelia.check_out_time", default=12
    )
