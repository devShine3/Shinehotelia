from . import res_config
