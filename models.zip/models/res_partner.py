# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models


class Partner(models.Model):
    _name = "res.partner"
    _inherit = "res.partner"

    # team_id = fields.Many2one('crm.team', string='Sales Team', ondelete="set null")
    # opportunity_ids = fields.One2many('crm.lead', 'partner_id', string='Opportunities', domain=[('type', '=', 'opportunity')])
    # opportunity_count = fields.Integer("Opportunity", compute='_compute_opportunity_count')

    # @api.model
    # def default_get(self, fields):
    #     rec = super(Partner, self).default_get(fields)
    #     active_model = self.env.context.get('active_model')
    #     if active_model == 'hotel.guest' and len(self.env.context.get('active_ids', [])) <= 1:
    #         guest = self.env[active_model].browse(self.env.context.get('active_id')).exists()
    #         if guest:
    #             rec.update(
    #                 phone=guest.phone,
    #                 mobile=guest.mobile,
    #                 function=guest.function,
    #                 title=guest.title.id,
    #                 website=guest.website,
    #                 street=guest.street,
    #                 street2=guest.street2,
    #                 city=guest.city,
    #                 state_id=guest.state_id.id,
    #                 country_id=guest.country_id.id,
    #                 zip=guest.zip,
    #             )
    #     return rec

    # @api.model
    # def default_get(self, fields):
    #     rec = super(Partner, self).default_get(fields)
    #     active_model = self.env.context.get('active_model')
    #     if active_model == 'hotelia.guest' and len(self.env.context.get('active_ids', [])) <= 1:
    #         guest = self.env[active_model].browse(self.env.context.get('active_id')).exists()
    #         if guest:
    #             rec.update(
    #                 phone=guest.phone,
    #                 mobile=guest.mobile,
    #                 title=guest.title.id,
    #                 website=guest.website,
    #                 street=guest.street,
    #                 street2=guest.street2,
    #                 city=guest.city,
    #                 state_id=guest.state_id.id,
    #                 country_id=guest.country_id.id,
    #                 zip=guest.zip,
    #             )
    #     return rec
