import json
import logging
from datetime import date

import requests
from werkzeug.urls import url_encode
from odoo import fields, models, api
from odoo.exceptions import ValidationError
from odoo.tools import datetime
from odoo import _, http
from odoo.exceptions import UserError

from datetime import datetime, timedelta

from dateutil.relativedelta import relativedelta
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT as dt

_logger = logging.getLogger(__name__)
try:
    import pytz
except (ImportError, IOError) as err:
    _logger.debug(err)


class BookingChart(models.Model):
    _name = "hotelia.booking.chart"
    _description = "Hotel Booking Chart"

    name = fields.Char("Booking Chart", default="Reservations Summary")
    date_from = fields.Datetime("Date From", default=lambda self: fields.Date.today())
    date_to = fields.Datetime(
        "Date To",
        default=lambda self: fields.Date.today() + relativedelta(days=30),
    )
    summary_header = fields.Text("Summary Header")
    room_summary = fields.Text("Room Summary")

    @api.model
    def _set_open_color(self):
        colors = self.env["hotel.color"].search([])
        for color in colors:
            if color.name == "open":
                open_color = color.color
        return open_color

    @api.model
    def _set_waitlist_color(self):
        colors = self.env["hotel.color"].search([])
        for color in colors:
            if color.name == "waitlist":
                waitlist_color = color.color
        return waitlist_color

    waitlist_color = fields.Char(string="Waitlist", default=_set_waitlist_color)

    @api.model
    def _set_confirmed_color(self):
        confirmed_color = ""
        colors = self.env["hotel.color"].search([])
        for color in colors:
            if color.name == "confirmed":
                confirmed_color = color.color
        return confirmed_color

    confirmed_color = fields.Char(string="confirmed", default=_set_confirmed_color)

    @api.model
    def _set_registration_color(self):
        colors = self.env["hotel.color"].search([])
        for color in colors:
            if color.name == "registration":
                registration_color = color.color
        return registration_color

    registration_color = fields.Char(
        string="registration", default=_set_registration_color
    )
    open_color = fields.Char(string="Open", default=_set_open_color)

    # def room_reservation(self):
    #     """
    #     @param self: object pointer
    #     """
    #     resource_id = self.env.ref("hotel_reservation.view_hotel_reservation_form").id
    #     return {
    #         "name": _("Reconcile Write-Off"),
    #         "context": self._context,
    #         "view_type": "form",
    #         "view_mode": "form",
    #         "res_model": "hotel.reservation",
    #         "views": [(resource_id, "form")],
    #         "type": "ir.actions.act_window",
    #         "target": "new",
    #     }

    @api.onchange("date_from", "date_to")  # noqa C901 (function is too complex)
    def get_room_summary(self):  # noqa C901 (function is too complex)
        """
        @param self: object pointer
        """
        res = {}
        all_detail = []
        room_obj = self.env["hms.room.type"]
        reservation_line_obj = self.env["hotel.reservation"]
        # folio_room_line_obj = self.env["folio.room.line"]
        # user_obj = self.env["res.users"]
        date_range_list = []
        main_header = []
        summary_header_list = [{"date": " ", "weekend": False, "class": False}]
        background_color = ""
        if self.date_from and self.date_to:
            if self.date_from > self.date_to:
                raise UserError(_("Checkout date should be greater than Checkin date."))
            if self._context.get("tz", False):
                timezone = pytz.timezone(self._context.get("tz", False))
            else:
                timezone = pytz.timezone("UTC")
            d_frm_obj = (
                (self.date_from)
                .replace(tzinfo=pytz.timezone("UTC"))
                .astimezone(timezone)
            )
            d_to_obj = (
                (self.date_to).replace(tzinfo=pytz.timezone("UTC")).astimezone(timezone)
            )
            temp_date = d_frm_obj
            while temp_date <= d_to_obj:
                if str(temp_date.strftime("%d")) == "01" or temp_date == d_frm_obj:
                    val = (
                        str(temp_date.strftime("%b"))
                        + " "
                        + str(temp_date.strftime("%d"))
                    )
                    header = {
                        "date": val,
                        "weekend": (
                            str(temp_date.strftime("%a")) == "Sat"
                            or str(temp_date.strftime("%a")) == "Sun"
                        ),
                        "class": True,
                    }

                else:
                    val = str(temp_date.strftime("%d"))
                    header = {
                        "date": val,
                        "weekend": (
                            str(temp_date.strftime("%a")) == "Sat"
                            or str(temp_date.strftime("%a")) == "Sun"
                        ),
                        "class": False,
                    }

                summary_header_list.append(header)

                # val = ""
                # val = (
                #
                #     str(temp_date.strftime("%d"))
                # )
                # summary_header_list.append(val)
                date_range_list.append(temp_date.strftime(dt))
                temp_date = temp_date + timedelta(days=1)
            all_detail.append(summary_header_list)

            all_room_detail = []
            total_rooms = self.env["hms_room_setup"].search([])

            for room in total_rooms:
                room_detail = {}
                # room_stats = {}
                room_list_stats = []
                # room = self.env['hms_room_setup'].search([('id', '=', room.id)])
                name = room.name

                room_detail.update({"name": name or ""})

                for chk_date in date_range_list:
                    ch_dt = chk_date[:10] + " 23:59:59"
                    today_date_only = chk_date[:10]
                    ttime = datetime.strptime(ch_dt, dt)
                    c = ttime.replace(tzinfo=timezone).astimezone(pytz.timezone("UTC"))
                    chk_date = c.strftime(dt)
                    weekend = False
                    if str(c.strftime("%a")) == "Sat" or str(c.strftime("%a")) == "Sun":
                        weekend = True
                    reservation_list = reservation_line_obj.search(
                        [
                            ("room_no", "=", room.id),
                            ("arrival", "<=", chk_date),
                            ("departure", ">=", chk_date),
                            ("overbook", "=", False),
                        ]
                    )

                    if not reservation_list:
                        room_list_stats.append(
                            {
                                "col_span": 0,
                                "date": today_date_only,
                                "room_id": room.id,
                                "room_type": room.room_type.id,
                                "reservation_id": 0,
                                "background": " ",
                                "status": "Free",
                                "guest": " ",
                                "weekend": weekend,
                            }
                        )

                    else:
                        colspan = 0
                        arrival_today_reservation_list = reservation_line_obj.search(
                            [
                                ("room_no", "=", room.id),
                                ("arrival", "=", chk_date),
                            ]
                        )

                        for reservation in reservation_list:
                            color = self.env["hotel.color"].search(
                                [("name", "=", reservation.Rsv_Type)]
                            )
                            background_color = f"background-color: {color.color};"

                            d1 = datetime.strptime(str(reservation.arrival), "%Y-%m-%d")
                            d2 = datetime.strptime(
                                str(reservation.departure), "%Y-%m-%d"
                            )
                            today = datetime.strptime(str(today_date_only), "%Y-%m-%d")
                            departure_date = reservation.departure.strftime("%Y-%m-%d")
                            arrival_date = reservation.arrival.strftime("%Y-%m-%d")
                            today_date = c.strftime("%Y-%m-%d")
                            start_date = self.date_from.strftime("%Y-%m-%d")
                            if today_date != arrival_date and today_date == start_date:
                                d3 = d2 - today
                                colspan = d3.days
                                date = start_date
                            if today_date == arrival_date:
                                d3 = d2 - d1
                                colspan = d3.days
                                date = reservation.arrival.strftime(dt)
                            name = ""
                            if colspan < 2:
                                name = reservation.name[:3]
                            else:
                                name = reservation.name
                            # date = reservation.arrival.strftime(dt)

                            if (
                                today_date == departure_date
                                and not arrival_today_reservation_list
                            ):
                                room_list_stats.append(
                                    {
                                        "col_span": 0,
                                        "date": today_date_only,
                                        "room_id": room.id,
                                        "room_type": room.room_type.id,
                                        "reservation_id": 0,
                                        "background": background_color,
                                        "status": "Free",
                                        "guest": " ",
                                        "weekend": weekend,
                                    }
                                )

                            if today_date == arrival_date or (
                                today_date != arrival_date
                                and today_date != departure_date
                                and today_date == start_date
                            ):
                                room_stats = {
                                    "col_span": colspan,
                                    "date": date,
                                    "room_id": room.id,
                                    "room_type": room.room_type.id,
                                    "reservation_id": reservation.id,
                                    "background": background_color,
                                    "status": reservation.Rsv_Type,
                                    "guest": name,
                                    "weekend": False,
                                }
                                if room_stats not in room_list_stats:
                                    room_list_stats.append(room_stats)
                            # if today_date != arrival_date and today_date != departure_date and today_date == start_date:
                            #     room_stats = {
                            #
                            #         "col_span": colspan,
                            #         "date": date,
                            #         "room_id": room.id,
                            #         "room_type": room.room_type.id,
                            #         "reservation_id": reservation.id,
                            #         "status": reservation.Rsv_Type,
                            #         "guest": name,
                            #         "weekend": False
                            #
                            #     }

                        # for room_stats in room_list_stats:
                        #     if room_stats.get("reservation_id") != 0:
                        #         room_stats["weekend"] = weekend

                room_detail.update({"value": room_list_stats})
                all_room_detail.append(room_detail)

            main_header.append({"header": summary_header_list})
            self.summary_header = str(main_header)
            self.room_summary = str(all_room_detail)
        return res
