import json
import logging
from datetime import datetime, timedelta, date

import pytz

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

_logger = logging.getLogger(__name__)


class HmsRegistraion(models.Model):
    _name = "hms.registration"
    _description = "HMS Registration"
    _rec_name = "bc_name"
    _order = "name DESC"

    def _tomorrow_date(self):
        print(f"{self.env.context} ---env")
        current_date = datetime.now()
        new_date = current_date + timedelta(days=1)
        return new_date

    def _today_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=0)
        return new_date

    def _today_date_utc(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(hours=6, minutes=30, days=0)
        return new_date

    def _compute_today_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(hours=6, minutes=30, days=0)
        for rec in self:
            rec.folio_transaction_field_date = new_date

    def _default_room_type(self):
        room_type = False
        room_type_id = (
            self.env["hms.room.type"].search([("function", "=", False)], limit=1).id
        )
        if room_type_id:
            room_type = room_type_id
        return room_type

    def _default_currency(self):
        currency = False
        currency_id = (
            self.env["res.currency"]
            .search([("hotelia_base_currency", "=", True)], limit=1)
            .id
        )
        if currency_id:
            currency = currency_id
        return currency

    def _default_customer_type(self):
        customer_type = False
        customer_type_id = (
            self.env["hms.customer_type"]
            .search(([("name", "=", "Regular")]), limit=1)
            .id
        )
        if customer_type_id:
            customer_type = customer_type_id
        return customer_type

    name = fields.Char(
        string="Reg No.", copy=False, readonly=True, default=lambda self: _("TBA")
    )
    guest_ids = fields.One2many("hms.guestline", "registration_id")

    # registration
    reg_sequence = fields.Integer("Reg Sequence", default=0)
    reg_date = fields.Date("Reg Date", default=_today_date_utc)
    bill_transfer_flag = fields.Boolean("Bill Transfer")

    # reg_arrival = fields.Datetime('Arrival Date', default=date.today())
    # reg_departure = fields.Datetime('Departure Date', default=_tomorrow_date)
    """
    Separate datetime fields to date and time
    """
    reg_arrival = fields.Datetime(
        "Arrival Date Full",
        compute="_compute_arrival_datetime_field",
        inverse="_reverse_compute_arrival_datetime",
        store=True,
        default=_today_date,
    )
    arrival_date = fields.Date("Arrival Date")
    arrival_time = fields.Float("Ariival Time")

    reg_departure = fields.Datetime(
        "Departure Date Full",
        compute="_compute_departure_datetime_field",
        inverse="_reverse_compute_departure_datetime",
        store=True,
        default=_tomorrow_date,
    )
    departure_date = fields.Date("Departure Date")
    departure_time = fields.Float("Departure Time")
    master_room = fields.Boolean(string="Master Room", default=False)
    gp_checkin = fields.Boolean(string="GroupCheckin", default=False)
    namebind = fields.Boolean(string="GroupCheckin", default=False)
    iamregistered = fields.Boolean(string="Iamregistered", default=False)
    dayuse = fields.Boolean(string="Day Use", default=False)
    master_bill = fields.Boolean()
    room_no_domain = fields.Char(
        compute="_compute_field1_field2_roomno_domain",
        readonly=True,
        store=False,
    )

    @api.depends("arrival_date", "arrival_time")
    def _compute_arrival_datetime_field(self):
        for record in self:
            if record.arrival_date:
                # Extract hour and minute values from float time field
                hour, minutes = divmod(int(record.arrival_time * 60), 60)

                # Create a timezone object from the user's timezone string
                tz_string = self.env.user.tz or "UTC"
                user_timezone = pytz.timezone(tz_string)
                print(f"{self.env.context} ---env")

                # Create a datetime object with the date and time values
                arrival_datetime = datetime.combine(
                    record.arrival_date, datetime.min.time()
                ) + timedelta(hours=hour, minutes=minutes)

                # Get the UTC offset for the datetime object
                utc_offset = user_timezone.utcoffset(arrival_datetime)

                # Convert the UTC offset to hours and minutes
                utc_offset_hours = int(utc_offset.total_seconds() / 3600)
                utc_offset_minutes = int((utc_offset.total_seconds() % 3600) / 60)

                # Adjust the datetime object for the UTC offset and store it in the field
                record.reg_arrival = arrival_datetime - timedelta(
                    hours=utc_offset_hours, minutes=utc_offset_minutes
                )

            else:
                # Clear the value of arrival_field
                record.reg_arrival = False

    @api.depends("reg_room_type")
    def _compute_field1_field2_roomno_domain(self):
        # Define your logic here to compute the domain
        for rec in self:
            rooms_id = []
            rooms_id = []

            rooms_id = (
                rec.env["hms.registration"]
                .search(
                    [
                        ("arrival_date", "<=", rec.arrival_date),
                        ("departure_date", ">", rec.arrival_date),
                        ("Rsv_Type", "!=", "waitlist"),
                        ("Rsv_Type", "!=", "cancel"),
                        ("Rsv_Type", "=", "registration"),
                    ]
                )
                .reg_room_no.ids
            )
            reserve_rooms = rec.env["hotel.reservation"].search(
                [
                    ("arrival_date", "<=", rec.arrival_date),
                    ("departure_date", ">", rec.arrival_date),
                    ("Rsv_Type", "!=", "waitlist"),
                    ("Rsv_Type", "!=", "cancel"),
                    ("Rsv_Type", "=", "registration"),
                ]
            )
            for reserve_room in reserve_rooms:
                rooms_id.append(reserve_room.room_no.id)
            domain = [
                ("id", "not in", rooms_id),
                ("room_type", "=", rec.reg_room_type.id),
                ("room_status", "!=", "oos"),
                ("room_status", "!=", "ooo"),
            ]
            rec.room_no_domain = json.dumps(domain)

    @api.onchange("reg_arrival")
    def _reverse_compute_arrival_datetime(self):
        for record in self:
            if record.reg_arrival:
                tz_string = self.env.user.tz or "UTC"
                user_timezone = pytz.timezone(tz_string)

                # Convert arrival_datetime_field to a UTC datetime object
                arrival_datetime_utc = record.reg_arrival.replace(tzinfo=pytz.utc)

                # Convert the UTC datetime object to the user's timezone
                arrival_datetime_user_tz = arrival_datetime_utc.astimezone(
                    user_timezone
                )

                # Extract the date and time components in the user's timezone
                my_date = arrival_datetime_user_tz.date()
                my_time = arrival_datetime_user_tz.time()

                # Calculate the float value of the time component
                my_time_float = my_time.hour + my_time.minute / 60

                # print(f"{my_time_float} --time")

                # Store the updated values
                record.arrival_date = my_date
                record.arrival_time = my_time_float

    @api.depends("departure_date", "departure_time")
    def _compute_departure_datetime_field(self):
        for record in self:
            if record.departure_date:
                # Extract hour and minute values from float time field
                hour, minutes = divmod(int(record.departure_time * 60), 60)

                # Create a timezone object from the user's timezone string
                tz_string = self.env.user.tz or "UTC"
                user_timezone = pytz.timezone(tz_string)

                # Create a datetime object with the date and time values
                departure_datetime = datetime.combine(
                    record.departure_date, datetime.min.time()
                ) + timedelta(hours=hour, minutes=minutes)

                # Get the UTC offset for the datetime object
                utc_offset = user_timezone.utcoffset(departure_datetime)

                # Convert the UTC offset to hours and minutes
                utc_offset_hours = int(utc_offset.total_seconds() / 3600)
                utc_offset_minutes = int((utc_offset.total_seconds() % 3600) / 60)

                # Adjust the datetime object for the UTC offset and store it in the field
                record.reg_departure = departure_datetime - timedelta(
                    hours=utc_offset_hours, minutes=utc_offset_minutes
                )

            else:
                # Clear the value of arrival_field
                record.reg_departure = False

    @api.onchange("reg_departure")
    def _reverse_compute_departure_datetime(self):
        for record in self:
            if record.reg_departure:
                tz_string = self.env.user.tz or "UTC"
                user_timezone = pytz.timezone(tz_string)

                # Convert departure_datetime_field to a UTC datetime object
                departure_datetime_utc = record.reg_departure.replace(tzinfo=pytz.utc)

                # Convert the UTC datetime object to the user's timezone
                departure_datetime_user_tz = departure_datetime_utc.astimezone(
                    user_timezone
                )

                # Extract the date and time components in the user's timezone
                my_date = departure_datetime_user_tz.date()
                my_time = departure_datetime_user_tz.time()

                # Calculate the float value of the time component
                my_time_float = my_time.hour + my_time.minute / 60

                # print(f"{my_time_float} --time")

                # Store the updated values
                record.departure_date = my_date
                record.departure_time = my_time_float

    Rsv_Type = fields.Selection(
        [
            ("open", "Open"),
            ("confirmed", "Confirmed"),
            ("waitlist", "Waitlist"),
            ("registration", "Registered"),
            ("check_out", "Check Out"),
            ("cancel", "Cancel"),
            ("transfer", "Room Transferred"),
        ],
        String="Reservation Type",
        # default="registration",
        tracking=True,
        translate=True,
        readonly=True,
    )

    reg_room_type = fields.Many2one(
        "hms.room.type",
        String="Room Type",
        ondelete="set null",
        default=_default_room_type,
        domain="[('function', '=', False)]",
    )
    reg_room_no = fields.Many2one(
        "hms_room_setup",
        string="Room No",
        domain="[('room_type', '=?', reg_room_type)]",
    )
    reg_room_no_one = fields.Many2one("hms_room_setup")
    reg_room_name = fields.Char("Room Name", compute="_compute_room_name")
    reg_room_type_name = fields.Char("Room Type Name", compute="_compute_room_name")
    reg_customer_type = fields.Many2one(
        "hms.customer_type", "Customer Type", default=_default_customer_type
    )
    reg_room_rate = fields.Selection(
        [
            ("ota", "OTA"),
            ("s_foreigner", "Single Foreigner"),
            ("d_local", "Double Local"),
            ("cooperate", "Cooperate"),
            ("company1", "Company"),
        ],
        String="Customer Type",
        default="ota",
        tracking=True,
        translate=True,
    )

    reg_amount = fields.Float("Amount", compute="_compute_room_amount", store=True)
    reg_currency = fields.Many2one(
        "res.currency", "Currency", default=_default_currency
    )
    reg_extra_bed = fields.Selection(
        [("0", "0"), ("1", "1"), ("2", "2"), ("3", "3"), ("4", "4")],
        string="Extra Bed",
        default="0",
        required="1",
    )

    reg_breakfast = fields.Boolean("Breakfast", default=False)
    reg_adult = fields.Integer("Adult", default="1")
    reg_child = fields.Integer("Child", default="0")
    reg_overbook = fields.Boolean("Overbook")
    reg_status = fields.Selection(
        [("check_in", "Check In"), ("check_out", "Check Out")],
        String="Registration Status",
        default="check_in",
    )
    form_type = fields.Selection(
        [
            ("registration", "registration"),
            ("reservation", "reservation"),
        ],
        String="Form Type",
    )

    reg_group_id = fields.Char(string="Group")
    group_key = fields.Integer("Group ID")
    reg_group_flag = fields.Boolean("Group Flag", default=False)

    reg_agent_id = fields.Many2one("hmslite.agentsetup", "Agent")
    reg_company_id = fields.Many2one("hmslite.companysetup", "Company")

    package_id = fields.Char(string="Package")
    package_key = fields.Integer("package ID")

    deposit = fields.Float("Deposit")
    payment_status = fields.Selection(
        [("partial", "Partial Paid"), ("paid", "Paid"), ("pending", "Unpaid")],
        compute="compute_payment_status",
        default="pending",
        # inverse="inverse_payment_status", store=False,
    )
    payment_info = fields.Char("Payment Info")
    payment_filter = fields.Char(
        "Payment Filter", default="pending"
    )  # compute="compute_payment_filter", store=True

    reservation_id = fields.Integer("Rsv ID")
    remark = fields.Html(string="Remark", default=" ")
    special_request = fields.Html(string="Special Request")
    overbook = fields.Boolean("Overbook")

    # guest info
    def _compute_full_name(self):
        for rec in self:
            if rec.title and rec.guest_name:
                rec.full_name = rec.title.name + " " + rec.guest_name
            elif not rec.title:
                rec.full_name = rec.guest_name
            elif not rec.guest_name:
                rec.full_name = ""
            else:
                rec.full_name = ""

    full_name = fields.Char(compute=_compute_full_name)
    title = fields.Many2one("hms.namelist", string="Title", readonly=False, store=True)
    guest_name = fields.Char(string="Guest Name")
    guest_name_testing = fields.Char(string="Guest Name Testing")
    phone = fields.Char("Phone")
    email = fields.Char("Email")
    nric = fields.Char("IC")
    date_of_birth = fields.Date("DOB")
    gender = fields.Selection(
        [("male", "Male"), ("female", "Female"), ("na", "NA")], default="male"
    )
    passport_no = fields.Char("Passport")
    visa_no = fields.Char("Visa No.")
    national = fields.Many2one("hms.national", string="Nationality")
    contact_person = fields.Char("Contact Person")
    contact_phone = fields.Char("Contact Phone")
    guest_key = fields.Integer("Guest ID")
    guestinfo_key = fields.Integer("Guest ID")
    guestinfo_name = fields.Char("Name")
    guestinfo_nric = fields.Char("NRIC")
    guestinfo_passport_no = fields.Char("Passport")
    guestinfo_visa_no = fields.Char("Visa No.")
    guestinfo_phone = fields.Char("Phone")
    guestinfo_email = fields.Char("Email")
    guestinfo_dob = fields.Date("Date of Birth", tracking=True)
    guestinfo_gender = fields.Selection(
        [("male", "Male"), ("female", "Female"), ("na", "NA")],
        default="male",
        string="Gender",
    )
    guestinto_nationality = fields.Many2one("hms.national", string="Nationality")
    # Add folio transaction values with form
    folio_transaction_field_date = fields.Date(
        "Date", compute=_compute_today_date, inverse="_inverse_today_date_folio"
    )
    folio_transaction_field_name = fields.Many2one("hms.transaction")
    folio_transaction_field_trans_type = fields.Selection(
        [
            ("pos ", "POS "),
            ("restaurant", "Restaurant"),
            ("day", "Day Use"),
            ("payment", "Payment"),
            ("night", "Night Audit"),
            ("package", "Package"),
            ("discount", "Discount"),
        ],
        string="Transaction Type",
    )
    folio_transaction_field_trans_price = fields.Float(String="Price")
    folio_transaction_field_trans_currency = fields.Many2one("res.currency", "Currency")
    folio_transaction_field_payment_type = fields.Many2one("hotel.payment", "Payment Type")
    folio_transaction_field_trans_currency_rate = fields.Float("Transaction Rate", compute="_compute_currency_rate", store=False)
    folio_transaction_field_service = fields.Float(String="Service Fee", default="0.00", compute="_compute_service") # compute="_compute_service",
    folio_transaction_field_discount = fields.Float(String="Discount", default="0.00")
    folio_transaction_field_discount_per = fields.Float(String="Discount(%)", default="0")
    folio_transaction_field_tax = fields.Float(String="Tax", default="0.00", compute="_compute_tax") # compute="_compute_tax",
    folio_transaction_field_reference = fields.Char(String="Reference")
    folio_transaction_field_bill_name = fields.Char("Bill Name")
    folio_transaction_field_trigger_field = fields.Char(
        "Transaction", default="new_trigger"
    )

    service_inclusive = fields.Boolean("Service Inclusive", compute="_compute_service_inclusive")
    tax_inclusive = fields.Boolean("Tax Inclusive", compute="_compute_tax_inclusive")

    def _compute_service_inclusive(self):
        for rec in self:
            service_inclusive = self.env["ir.config_parameter"].get_param("hotelia.service_inclusive", "")
            service_inclusive = True if service_inclusive == 'True' else False
            rec.service_inclusive = service_inclusive

    def _compute_tax_inclusive(self):
        for rec in self:
            tax_inclusive = self.env["ir.config_parameter"].get_param("hotelia.tax_inclusive", "")
            tax_inclusive = True if tax_inclusive == 'True' else False
            rec.tax_inclusive = tax_inclusive

    @api.depends("folio_transaction_field_trans_currency_rate")
    def _compute_currency_rate(self):
        for rec in self:
            base_currency = self.env["res.currency"].search(
                [("hotelia_base_currency", "=", True)], limit=1
            )
            if (
                rec.folio_transaction_field_trans_currency.id == base_currency.id
                or not rec.folio_transaction_field_trans_currency
            ):
                rec.folio_transaction_field_trans_currency_rate = 1.0
            else:
                company_obj = self.env.user.sudo().company_id
                if not base_currency:
                    raise ValidationError(
                        _("You must create hotelia base currency first")
                    )
                else:
                    rec.folio_transaction_field_trans_currency_rate = (
                        base_currency._get_conversion_rate(
                            rec.folio_transaction_field_trans_currency,
                            base_currency,
                            company_obj,
                            datetime.now().date(),
                        )
                    )

    def _compute_service(self):
        service_percent = self.env["ir.config_parameter"].get_param("hotelia.service_percent", 0)
        service_inclusive = self.env["ir.config_parameter"].get_param("hotelia.service_inclusive", "")
        service_inclusive = True if service_inclusive == 'True' else False
        for rec in self:
            if service_inclusive == True:
                rec.folio_transaction_field_service = service_percent
            else:
                rec.folio_transaction_field_service = 0.00

    def _compute_tax(self):
        tax_percent = self.env["ir.config_parameter"].get_param("hotelia.tax_percent", 0)
        tax_inclusive = self.env["ir.config_parameter"].get_param("hotelia.tax_inclusive", "")
        tax_inclusive = True if tax_inclusive == 'True' else False
        for rec in self:
            if tax_inclusive == True:
                rec.folio_transaction_field_tax = tax_percent
            else:
                rec.folio_transaction_field_tax = 0.00

    # @api.depends("room_no")
    def _inverse_today_date_folio(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=0)
        for rec in self:
            rec.folio_transaction_field_date = new_date

    @api.onchange("guestinfo_key")
    def _onchange_guestinfo_name(self):
        for rec in self:
            if rec.guestinfo_key:
                guest_data = self.env["hotel.guest"].search(
                    [("id", "=", rec.guestinfo_key)], order="id desc", limit=1
                )
                if guest_data:
                    rec.guestinfo_name = guest_data.name
                    rec.guestinfo_nric = guest_data.id_no
                    rec.guestinfo_passport_no = guest_data.passport_no or ''
                    rec.guestinfo_visa_no = guest_data.visa_no or ''
                    rec.guestinfo_email = guest_data.email_from
                    rec.guestinfo_phone = guest_data.phone
                    rec.guestinto_nationality = guest_data.national
                    rec.guestinfo_key = guest_data.id
                    rec.guestinfo_gender = guest_data.gender
                    rec.guestinfo_dob = guest_data.date_of_birth

    @api.onchange("folio_transaction_field_name")
    def _onchange_folio_transaction_field_name(self):
        if self.folio_transaction_field_name:
            room_charge_auto = self.env["ir.config_parameter"].get_param(
                "hotelia.room_charge_auto", ""
            )
            if room_charge_auto:
                if self.folio_transaction_field_name.name == "Room Charges":
                    self.room_charge_auto = True
                    self.folio_transaction_field_trans_price = self.reg_amount
                    self.folio_transaction_field_trans_currency = (
                        self.folio_transaction_field_name.currency
                    )
                else:
                    self.room_charge_auto = False
                    self.folio_transaction_field_trans_price = (
                        self.folio_transaction_field_name.price
                    )
                    self.folio_transaction_field_trans_currency = (
                        self.folio_transaction_field_name.currency
                    )
            else:
                self.folio_transaction_field_trans_price = (
                    self.folio_transaction_field_name.price
                )
                self.folio_transaction_field_trans_currency = (
                    self.folio_transaction_field_name.currency
                )
                self.room_charge_auto = False
                self.payment_type_check = False

            if self.folio_transaction_field_name.name == "Advance Receipt":
                self.folio_transaction_field_trans_currency = (
                    self.folio_transaction_field_name.currency
                )
                self.payment_type_check = True
            else:
                self.payment_type_check = False

    @api.onchange("folio_transaction_field_discount_per")
    def _onchange_folio_transaction_field_discount(self):
        if self.folio_transaction_field_discount_per:
            if (
                self.folio_transaction_field_discount_per < 0
                or self.folio_transaction_field_discount_per > 100
            ):
                raise ValidationError(_("Discount percentage should be between 1-100"))
            self.folio_transaction_field_discount = (
                self.folio_transaction_field_trans_price
                - (
                    self.folio_transaction_field_trans_price
                    * (1 - self.folio_transaction_field_discount_per / 100)
                )
            )

    @api.onchange("folio_transaction_field_trigger_field")
    def folio_transaction_fields_add(self):
        # import pdb;pdb.set_trace()
        original_price = 0.00 
        trans_price = 0.00
        service_price = 0.00
        tax_price = 0.00
        # service_percent = 10 #0.1 #10%
        service_percent_int = self.env["ir.config_parameter"].get_param("hotelia.service_percent", 0)
        service_percent = float(service_percent_int)
        # tax_percent = 5 #0.05 #5%
        tax_percent_int = self.env["ir.config_parameter"].get_param("hotelia.tax_percent", 0)
        tax_percent = float(tax_percent_int)


        original_price = self.folio_transaction_field_trans_price
        trans_price = original_price
        if self.service_inclusive == True and trans_price > 0.00:
            service_price = round((service_percent / 100) * original_price, 2)
            trans_price = trans_price + service_price
        elif self.service_inclusive == False:
            service_price = self.folio_transaction_field_service

        if self.tax_inclusive == True and trans_price > 0.00:
            tax_price = round((tax_percent / 100) * original_price, 2)
            trans_price = trans_price + tax_price
        elif self.tax_inclusive == False:
            tax_price = self.folio_transaction_field_tax
         
        if (
            self.folio_transaction_field_trigger_field != "new_trigger"
            and self.folio_transaction_field_name
            and self.folio_transaction_field_trans_currency
            and self.folio_transaction_field_date
        ):
            if (
                self.folio_transaction_field_name.name == "Advance Receipt"
                and self.folio_transaction_field_trans_price
            ):
                self.transaction_id = [
                    (
                        0,
                        0,
                        {
                            "trans_date": self.folio_transaction_field_date,
                            "trans_lines_id": self.folio_transaction_field_name.id,
                            "trans_type": self.folio_transaction_field_trans_type,
                            "original_price": original_price,
                            "trans_price": - trans_price,
                            "trans_currency": self.folio_transaction_field_trans_currency.id,
                            "trans_currency_rate": self.folio_transaction_field_trans_currency_rate,
                            "payment_type": self.folio_transaction_field_payment_type,
                            "service": service_price,
                            "discount": self.folio_transaction_field_discount,
                            "tax": tax_price,
                            "reference": "Deposit Amount",
                            "bill_name": self.folio_transaction_field_bill_name,
                        },
                    )
                ]

            elif (
                self.folio_transaction_field_name.name == "Discount"
                and self.folio_transaction_field_trans_price
            ):
                self.transaction_id = [
                    (
                        0,
                        0,
                        {
                            # "name": self.folio_transaction_field_id,
                            "trans_date": self.folio_transaction_field_date,
                            "trans_lines_id": self.folio_transaction_field_name.id,
                            "trans_type": self.folio_transaction_field_trans_type,
                            "original_price": original_price,
                            "trans_price": - trans_price,
                            "trans_currency": self.folio_transaction_field_trans_currency.id,
                            "trans_currency_rate": self.folio_transaction_field_trans_currency_rate,
                            "payment_type": self.folio_transaction_field_payment_type,
                            "service": service_price, # self.folio_transaction_field_service,
                            "discount": self.folio_transaction_field_discount,
                            "tax": tax_price, # self.folio_transaction_field_tax,
                            "reference": self.folio_transaction_field_reference,
                            "bill_name": self.folio_transaction_field_bill_name,
                        },
                    )
                ]
            else:
                self.transaction_id = [
                    (
                        0,
                        0,
                        {
                            # "name": self.folio_transaction_field_id,
                            "trans_date": self.folio_transaction_field_date,
                            "trans_lines_id": self.folio_transaction_field_name.id,
                            "trans_type": self.folio_transaction_field_trans_type,
                            "original_price": original_price,
                            "trans_price": trans_price,
                            "trans_currency": self.folio_transaction_field_trans_currency.id,
                            "trans_currency_rate": self.folio_transaction_field_trans_currency_rate,
                            "payment_type": self.folio_transaction_field_payment_type,
                            "service": service_price, # self.folio_transaction_field_service,
                            "discount": self.folio_transaction_field_discount,
                            "tax": tax_price, # self.folio_transaction_field_tax,
                            "reference": self.folio_transaction_field_reference,
                            "bill_name": self.folio_transaction_field_bill_name,
                        },
                    )
                ]

            # self.folio_transaction_field_id = ""
            # self.folio_transaction_field_date = ""
            self.folio_transaction_field_name = False
            self.folio_transaction_field_trans_type = ""
            self.folio_transaction_field_trans_price = ""
            self.folio_transaction_field_trans_currency = False
            self.folio_transaction_field_trans_currency_rate = 0.0
            self.folio_transaction_field_payment_type = False
            self.folio_transaction_field_service = ""
            self.folio_transaction_field_discount = ""
            self.folio_transaction_field_discount_per = ""
            self.folio_transaction_field_tax = ""
            self.folio_transaction_field_reference = ""
            self.folio_transaction_field_bill_name = ""
            self.payment_type_check = False
            self.room_charge_auto = False
        else:
            self.transaction_id = [
                    (
                        0,
                        0,
                        {
                            # "name": self.folio_transaction_field_id,
                            "trans_date": self.folio_transaction_field_date,
                            "trans_lines_id": self.folio_transaction_field_name.id,
                            "trans_type": self.folio_transaction_field_trans_type,
                            "original_price": original_price,
                            "trans_price": trans_price,
                            "trans_currency": self.folio_transaction_field_trans_currency.id,
                            "trans_currency_rate": self.folio_transaction_field_trans_currency_rate,
                            "payment_type": self.folio_transaction_field_payment_type,
                            "service": service_price, # self.folio_transaction_field_service,
                            "discount": self.folio_transaction_field_discount,
                            "tax": tax_price, # self.folio_transaction_field_tax,
                            "reference": self.folio_transaction_field_reference,
                            "bill_name": self.folio_transaction_field_bill_name,
                        },
                    )
                ]
            self.folio_transaction_field_name = False
            self.folio_transaction_field_trans_type = ""
            self.folio_transaction_field_trans_price = ""
            self.folio_transaction_field_trans_currency = False
            self.folio_transaction_field_trans_currency_rate = 0.0
            self.folio_transaction_field_payment_type = False
            self.folio_transaction_field_service = ""
            self.folio_transaction_field_discount = ""
            self.folio_transaction_field_discount_per = ""
            self.folio_transaction_field_tax = ""
            self.folio_transaction_field_reference = ""
            self.folio_transaction_field_bill_name = ""
            self.payment_type_check = False
            self.room_charge_auto = False

    # button no save
    trigger_field = fields.Char()

    # Transaction & Bill
    transaction_id = fields.One2many("hms.trans.line", "reg_id", string="Transactions")
    all_billed = fields.Boolean(string="All Billed", compute="_onchange_reg_key")
    bill_delete = fields.Boolean(
        string="All Billed",
        store=True,
    )
    room_charge_auto = fields.Boolean(string="Room Rate")
    payment_type_check = fields.Boolean(string="paymentypecheck", default=False)
    message_count = fields.Integer("Messages", compute="_compute_message_count")
    cashier = fields.Char("Cashier")
    bill_count = fields.Integer("No. Folio", compute="_compute_bill_count")
    delivery_order_count = fields.Integer(
        "No. Delivery Order", compute="_compute_delivery_order_count"
    )

    # breadcrumbtesting
    bc_name = fields.Integer("BC")
    trigger_field = fields.Char()
    num_1 = fields.Char("main", default="1")

    # functional fields

    function_id = fields.Char(string="function", default="2")
    function_resv_id = fields.Integer("Function Reservation")
    f_type = fields.Many2one("hms.functional.room.type", string="Function Type")
    f_room = fields.Many2one(
        "hms.functional.rooms.setup",
        string="Room No",
        domain="[('room_type', '=',f_type)]",
    )
    arrival = fields.Date(string="Arrival")
    departure = fields.Date(string="Departure")
    f_rate = fields.Float(string="Room Rate.")
    time_1 = fields.Float()
    time_2 = fields.Float()
    time_3 = fields.Float(string="Time")
    remark = fields.Html(sting="Remark")
    address = fields.Html(string="Address")
    f_deposit = fields.Float(string="Deposit.")

    total_pax_count = fields.Char(compute="_compute_total_pax_count")
    concatenated_field = fields.Char(compute="_compute_concatenated_field")
    concatenated_master = fields.Char(compute="_compute_concatenated_master")

    def _compute_total_pax_count(self):
        for record in self:
            total_pax_count = record.reg_adult + record.reg_child
            record.total_pax_count = str(total_pax_count)

    def _compute_concatenated_field(self):
        for record in self:
            if record.guest_name:
                record.concatenated_field = (
                    f"{record.full_name} - {record.total_pax_count}"
                )
            else:
                record.concatenated_field = ""

    def _compute_concatenated_master(self):
        for record in self:
            if record.group_key:
                if record.master_bill == True:
                    record.concatenated_master = f"{record.reg_group_id}(master)"
                else:
                    record.concatenated_master = record.reg_group_id
            else:
                record.concatenated_master = " "

    @api.onchange("guest_key")
    def _onchange_guest_name(self):
        for rec in self:
            if rec.guest_key:
                guest_data = self.env["hotel.guest"].search(
                    [("id", "=", rec.guest_key)], order="id desc", limit=1
                )
                if guest_data:
                    rec.guest_name = guest_data.name
                    rec.guest_name_testing = rec.guest_name
                    rec.nric = guest_data.id_no
                    rec.passport_no = guest_data.passport_no or ''
                    rec.visa_no = guest_data.visa_no or ''
                    rec.email = guest_data.email_from
                    rec.phone = guest_data.phone
                    rec.national = guest_data.national
                    rec.title = guest_data.title
                    rec.guest_key = guest_data.id
                    rec.gender = guest_data.gender
                    rec.date_of_birth = guest_data.date_of_birth

    @api.model
    def create(self, vals):
        guest_key = False
        today = str(date.today())
        date_format = date.today().strftime("%Y%m%d")
        if "reg_room_no_one" in vals:
            arrival_date = False
            if "arrival_date" in vals:
                arrival_date = vals["arrival_date"]

            reg_no = self.env["hms.registration"].search_count(
                [
                    ("arrival_date", "<=", arrival_date),
                    ("departure_date", ">", arrival_date),
                    ("reg_room_no", "=", vals["reg_room_no_one"]),
                ]
            )
            rsv_no = self.env["hotel.reservation"].search_count(
                [
                    ("arrival_date", "<=", arrival_date),
                    ("departure_date", ">", arrival_date),
                    ("room_no", "=", vals["reg_room_no_one"]),
                ]
            )

            room = self.env["hms_room_setup"].search(
                [("id", "=", vals["reg_room_no_one"])]
            )
            if room.room_status != "v_clean":
                room_name = room.name
                status_label = dict(room._fields["room_status"].selection).get(
                    room.room_status
                )
                raise ValidationError(
                    _("The room %s is %s " % (room_name, status_label))
                )

        if vals.get("name", _("TBA")) == _("TBA"):
            sql = "select coalesce(max(reg_sequence),0)+1 from hms_registration"
            self.env.cr.execute(sql)
            result = self.env.cr.fetchall()
            vals["reg_sequence"] = result[0][0]
            sequence_number = str(result[0][0])
            if len(str(result[0][0])) == 1:
                sequence_number = "00" + str(result[0][0])
            if len(str(result[0][0])) == 2:
                sequence_number = "0" + str(result[0][0])
            if len(str(result[0][0])) > 2:
                sequence_number = str(result[0][0])
            vals["name"] = sequence_number
        if vals["guest_name_testing"]:
            vals["guest_name"] = vals["guest_name_testing"]
            guest_name = vals["guest_name_testing"]
        else:
            guest_name = vals["guest_name_testing"]
        if "function_id" in vals:
            if vals["function_id"] == "2":
                vals["reg_room_no"] = vals["reg_room_no_one"]
        if "guest_key" in vals:
            guest_key = vals["guest_key"]
        if "group_key" in vals:
            group_key = vals["group_key"]
        if "master_room" in vals and vals["master_room"] == True:
            master_room = vals["master_room"]
            validate_master = self.env["hms.registration"].search(
                [
                    ("group_key", "=", group_key),
                    ("master_room", "=", True),
                    ("Rsv_Type", "=", "registration"),
                ]
            )
            if master_room == True and validate_master:
                raise ValidationError(_("Master Room already exist"))
            else:
                vals["master_bill"] = True
        reservation_obj = super(HmsRegistraion, self).create(vals)

        if not reservation_obj.reservation_id:
            transaction_ids = []
            trans_lines = []

            # Day Use
            if reservation_obj.dayuse == True:
                trans_line_id = (
                    self.env["hms.transaction"]
                    .sudo()
                    .search([("name", "=", "Room Charges")])
                )
                trans_info = (
                    0,
                    0,
                    {
                        "trans_lines_id": trans_line_id.id,
                        "trans_price": reservation_obj.reg_amount,
                        "trans_currency": reservation_obj.reg_currency.id,
                        "trans_type": "day",
                        "trans_date": date.today(),
                        "reference": "Day Use",
                    },
                )
                transaction_ids.append(trans_info)

            # Package
            if reservation_obj.package_key:
                trans_lines = (
                    self.env["hms.transaction"]
                    .sudo()
                    .search([("name", "=", "Package")])
                )
                pack_data = self.env["hms.package"].search(
                    [("id", "=", reservation_obj.package_key)], order="id desc", limit=1
                )
                for pdata in pack_data:
                    p_info = (
                        0,
                        0,
                        {
                            "trans_lines_id": trans_lines.id,
                            "trans_price": pdata.total_amt,
                            "trans_type": "package",
                            "trans_currency": pdata.currency.id,
                            "reference": pdata.name,
                            "pack_id": reservation_obj.package_key,
                        },
                    )
                transaction_ids.append(p_info)

            # Deposit
            if reservation_obj.deposit == 0.00:
                deposit = 0.00
            elif reservation_obj.deposit > 0.00:
                deposit = -reservation_obj.deposit
            type_search = self.env["hms.transaction"].search(
                [("name", "=", "Advance Receipt")]
            )

            if not type_search:
                base_currency = self.env["res.currency"].search(
                    [("hotelia_base_currency", "=", True)], limit=1
                )
                company_obj = self.env.user.sudo().company_id
                changed_currency = type_search.currency
                if not changed_currency:
                    changed_currency = base_currency

                transaction_create = self.env["hms.transaction"].create(
                    {
                        "name": "Advance Receipt",
                        "currency": changed_currency.id,
                    }
                )
                product = self.env["product.product"].create(
                    {
                        "name": "Advance Receipt",
                        "type": "service",
                        "taxes_id": False,
                        "supplier_taxes_id": False,
                        "sale_ok": False,
                        "purchase_ok": False,
                        "lst_price": deposit,
                    }
                )

            trans_lines = (
                self.env["hms.transaction"]
                .sudo()
                .search([("name", "=", "Advance Receipt")])
            )
            if deposit != 0.0:
                base_currency = self.env["res.currency"].search(
                    [("hotelia_base_currency", "=", True)], limit=1
                )
                changed_currency = trans_lines.currency
                if not changed_currency:
                    changed_currency = base_currency

                trans_info = (
                    0,
                    0,
                    {
                        "trans_lines_id": trans_lines.id,
                        "trans_price": deposit,
                        "trans_type": "payment",
                        "trans_currency": changed_currency.id,
                        "reference": "Deposit Amount",
                    },
                )
                transaction_ids.append(trans_info)

            guest_info_arr = [
                (
                    0,
                    0,
                    {
                        "name": reservation_obj.guest_name,
                        "nationality": reservation_obj.national.id,
                        "nrc": reservation_obj.nric,
                        "passport_no": reservation_obj.passport_no or '',
                        "visa_no": reservation_obj.visa_no or '',
                        "email": reservation_obj.email,
                        "phone": reservation_obj.phone,
                        "gender": reservation_obj.gender,
                        "date_of_birth": reservation_obj.date_of_birth,
                    },
                )
            ]
            reservation_obj.write(
                {
                    "guest_ids": guest_info_arr,
                    "transaction_id": transaction_ids,
                }
            )

        # Update Occupied dirty in Room Setup Form
        if reservation_obj.reg_room_no:
            room_setup_obj = self.env["hms_room_setup"].search(
                [("id", "=", reservation_obj.reg_room_no.id)]
            )
            if room_setup_obj:
                room_setup_obj.write({"room_status": "o_clean"})

        if reservation_obj.reservation_id != 0:
            rsv_obj = self.env["hotel.reservation"].search(
                [("id", "=", reservation_obj.reservation_id)]
            )
            if rsv_obj:
                rsv_obj.write({"Rsv_Type": "registration"})

        create_guest = {
            "name": reservation_obj.guest_name,
            "id_no": reservation_obj.nric,
            "passport_no": reservation_obj.passport_no or '',
            "visa_no": reservation_obj.visa_no or '',
            "email_from": reservation_obj.email,
            "phone": reservation_obj.phone,
            "national": reservation_obj.national.id,
            "title": reservation_obj.title.id,
        }
        upgrade_guest = {
            "name": reservation_obj.guest_name,
            "id_no": reservation_obj.nric,
            "passport_no": reservation_obj.passport_no or '',
            "visa_no": reservation_obj.visa_no or '',
            "email_from": reservation_obj.email,
            "phone": reservation_obj.phone,
            "national": reservation_obj.national.id,
            "title": reservation_obj.title.id,
        }
        guest_id = 0

        guest_obj = self.env["hotel.guest"].search(
            [
                ("id", "=", guest_key),
                ("name", "=", reservation_obj.guest_name),
                ("id_no", "=", reservation_obj.nric),
            ]
        )
        if guest_obj:
            guest_id = guest_obj.id
            guest_obj.write(upgrade_guest)
        else:
            guest = self.env["hotel.guest"].create(create_guest)
            guest_id = guest.id
            reservation_obj.write(
                {
                    "guest_key": guest.id,
                }
            )

        guest_lines = self.env["hms.guestline"].search(
            [("registration_id", "=", reservation_obj.id)]
        )
        if guest_lines:
            guest_lines.write({"guest_id": guest_id})

        if reservation_obj.guest_ids:
            for obj in reservation_obj.guest_ids:
                if obj.num_1 == "1":  # num1 other guest
                    # only create not main guest
                    partner_data = {
                        "name": obj.name,
                        "id_no": obj.nrc,
                        "passport_no": obj.passport_no or '',
                        "visa_no": obj.visa_no or '',
                        "email_from": obj.email,
                        "gender": obj.gender,
                        "phone": obj.phone,
                        "national": obj.nationality.id,
                    }
                    guest_info_obj = self.env["hotel.guest"].search(
                        [("name", "=", obj.name), ("id_no", "=", obj.nrc)]
                    )
                    if guest_info_obj:
                        guest_info_obj.write(partner_data)
                    else:
                        guest = self.env["hotel.guest"].create(partner_data)
                else:
                    _logger.info(f"{obj} --main guest")
        else:
            _logger.info(" --other guest not found")

        guest_info_list = []
        for g_data in self.guest_ids:
            if g_data:
                guest_info = (
                    0,
                    0,
                    {
                        "name": g_data.name,
                        "nationality": g_data.nationality.id,
                        "nrc": g_data.nrc,
                        "passport_no": g_data.passport_no or '',
                        "visa_no": g_data.visa_no or '',
                        "email": g_data.email,
                        "phone": g_data.phone,
                        "date_of_birth": g_data.date_of_birth,
                        "gender": g_data.gender,
                        "num_1": g_data.num_1,
                    },
                )
                guest_info_list.append(guest_info)

        if not reservation_obj.reservation_id:
            reservation_obj.iamregistered = True
            group_id = False
            company_id = False
            agent_id = False
            national = False
            title = False
            if reservation_obj.reg_group_id:
                group_id = reservation_obj.reg_group_id
            if reservation_obj.reg_company_id:
                company_id = reservation_obj.reg_company_id.id
            if reservation_obj.reg_agent_id:
                agent_id = reservation_obj.reg_agent_id.id
            if reservation_obj.national:
                national = reservation_obj.national.id
            if reservation_obj.title:
                title = reservation_obj.title.id
            if reservation_obj.gender:
                gender = reservation_obj.gender
            sql = "select coalesce(max(sequence),0)+1 from hotel_reservation"
            self.env.cr.execute(sql)
            result = self.env.cr.fetchall()
            sequence = result[0][0]
            sequence_number = str(result[0][0])
            if len(str(result[0][0])) == 1:
                sequence_number = "00" + str(result[0][0])
            if len(str(result[0][0])) == 2:
                sequence_number = "0" + str(result[0][0])
            if len(str(result[0][0])) > 2:
                sequence_number = str(result[0][0])

            resv_obj = {
                "name": sequence_number,
                "sequence": sequence,
                "rsv_date": reservation_obj.reg_date,
                "arrival": reservation_obj.reg_arrival,
                "arrival_date": reservation_obj.arrival_date,
                "intial_arrival_date": reservation_obj.reg_arrival,
                "arrival_time": reservation_obj.arrival_time,
                "departure": reservation_obj.reg_departure,
                "departure_date": reservation_obj.departure_date,
                "intial_departure_date": reservation_obj.reg_departure,
                "departure_time": reservation_obj.departure_time,
                "Rsv_Type": "registration",
                "room_type": reservation_obj.reg_room_type.id,
                "room_no": reservation_obj.reg_room_no.id,
                "room_rate": reservation_obj.reg_room_rate,
                "customer_type": reservation_obj.reg_customer_type.id,
                "amount": reservation_obj.reg_amount,
                "currency": reservation_obj.reg_currency.id,
                "extra_bed": reservation_obj.reg_extra_bed,
                "breakfast": reservation_obj.reg_breakfast,
                "adult": reservation_obj.reg_adult,
                "child": reservation_obj.reg_child,
                "overbook": reservation_obj.reg_overbook,
                "dayuse": reservation_obj.dayuse,
                "group_id": group_id,
                "group_key": reservation_obj.group_key,
                "package_id": reservation_obj.package_id,
                "package_key": reservation_obj.package_key,
                "group_flag": reservation_obj.reg_group_flag,
                "agent_id": agent_id,
                "company_id": company_id,
                "deposit": reservation_obj.deposit,
                # "package": reservation_obj.package.id,
                "remark": reservation_obj.remark,
                "special_request": reservation_obj.special_request,
                "title": title,
                "guest_name": reservation_obj.guest_name,
                "phone": reservation_obj.phone,
                "email": reservation_obj.email,
                "nric": reservation_obj.nric,
                "date_of_birth": reservation_obj.date_of_birth,
                "gender": gender,
                "passport_no": reservation_obj.passport_no or '',
                "visa_no": reservation_obj.visa_no or '',
                "national": national,
                "contact_person": reservation_obj.contact_person,
                "contact_phone": reservation_obj.contact_phone,
                "guest_key": reservation_obj.guest_key,
                "guest_ids": guest_info_list,
                "gpreserve_id": reservation_obj.group_key,
                # "transaction_id": reservation_obj.transaction_id,
            }
            resv = self.env["hotel.reservation"].create(resv_obj)

            reservation_obj.write(
                {
                    "reservation_id": resv.id,
                }
            )

        # master Room
        if reservation_obj.master_room:
            if reservation_obj.gp_checkin == False:
                check_master = self.env["hotel.reservation"].search(
                    [
                        ("id", "!=", reservation_obj.reservation_id),
                        ("gpreserve_id", "=", reservation_obj.group_key),
                    ]
                )

                for data in check_master:
                    existing_single_checkin = self.env["hms.registration"].search(
                        [("reservation_id", "=", data.id)]
                    )
                    if not existing_single_checkin:
                        guest_name = "ttt"
                        guest_key = False
                        title = False
                        phone = False
                        email = False
                        nric = False
                        date_of_birth = False
                        gender = False
                        national = False
                        passport_no = False
                        visa_no = False
                        contact_person = False
                        guest_info_list = []

                        if not reservation_obj.namebind:
                            guest_name = reservation_obj.guest_name
                            guest_key = reservation_obj.guest_key
                            title = reservation_obj.title.id
                            phone = reservation_obj.phone
                            email = reservation_obj.email
                            nric = reservation_obj.nric
                            date_of_birth = reservation_obj.date_of_birth
                            gender = reservation_obj.gender
                            national = reservation_obj.national.id
                            passport_no = reservation_obj.passport_no or ''
                            visa_no = reservation_obj.visa_no or ''
                            contact_person = reservation_obj.contact_person
                            for g_data in reservation_obj.guest_ids:
                                guest_info = (
                                    0,
                                    0,
                                    {
                                        "name": guest_name,
                                        "nationality": g_data.nationality.id,
                                        "nrc": g_data.nrc,
                                        "passport_no": g_data.passport_no or '',
                                        "visa_no": g_data.visa_no or '',
                                        "email": g_data.email,
                                        "phone": g_data.phone,
                                        "date_of_birth": g_data.date_of_birth,
                                        "gender": g_data.gender,
                                        "num_1": g_data.num_1,
                                    },
                                )
                                guest_info_list.append(guest_info)

                        if reservation_obj.namebind:
                            guest_name = data.guest_name
                            guest_key = data.guest_key
                            title = data.title.id
                            phone = data.phone
                            email = data.email
                            nric = data.nric
                            date_of_birth = data.date_of_birth
                            gender = data.gender
                            national = data.national
                            passport_no = data.passport_no
                            visa_no = data.visa_no
                            contact_person = data.contact_person
                            for g_data in data.guest_ids:
                                guest_info = (
                                    0,
                                    0,
                                    {
                                        "name": guest_name,
                                        "nationality": g_data.nationality.id,
                                        "nrc": g_data.nrc,
                                        "passport_no": g_data.passport_no or '',
                                        "visa_no": g_data.visa_no or '',
                                        "email": g_data.email,
                                        "phone": g_data.phone,
                                        "date_of_birth": g_data.date_of_birth,
                                        "gender": g_data.gender,
                                        "num_1": g_data.num_1,
                                    },
                                )
                                guest_info_list.append(guest_info)
                        data.write({"Rsv_Type": "registration", "master": False})

                        create_regmaster = {
                            "reg_amount": data.amount,
                            "reg_departure": data.departure,
                            "reg_room_rate": data.room_rate,
                            "reg_customer_type": data.customer_type.id,
                            "reg_room_type": data.room_type.id,
                            "reg_room_no": data.room_no.id,
                            "reg_amount": data.amount,
                            "reg_currency": data.currency.id,
                            "reg_extra_bed": data.extra_bed,
                            "reg_breakfast": data.breakfast,
                            "reg_adult": data.adult,
                            "reg_child": data.child,
                            "reg_group_id": data.group_id,
                            "package_id": data.package_id,
                            "package_key": data.package_key,
                            "reg_agent_id": data.agent_id.id,
                            "reg_company_id": data.company_id.id,
                            "group_key": data.gpreserve_id.id,
                            "reg_group_flag": data.group_flag,
                            "Rsv_Type": "registration",
                            "guest_name": guest_name,
                            "guest_name_testing": guest_name,
                            "title": title,
                            "phone": phone,
                            "email": email,
                            "nric": nric,
                            "date_of_birth": date_of_birth,
                            "gender": gender,
                            "passport_no": passport_no or '',
                            "visa_no": visa_no or '',
                            "national": national,
                            "contact_person": contact_person,
                            "guest_key": guest_key,
                            "deposit": data.deposit,
                            "payment_status": data.payment_status,
                            # "payment_info": data.payment_info,
                            "remark": data.remark,
                            "special_request": data.special_request,
                            "reservation_id": data.id,
                            "contact_person": data.contact_person,
                            "reg_customer_type": data.customer_type.id,
                        }
                        if reservation_obj.namebind:
                            create_regmaster["guest_ids"] = guest_info_list
                        resv = self.env["hms.registration"].create(create_regmaster)
        return reservation_obj

    def write(self, vals):
        if "reg_room_no_one" in vals:
            if "arrival_date" in vals:
                arrival_date = vals["arrival_date"]
            else:
                arrival_date = self.arrival_date
            reg_no = self.env["hms.registration"].search_count(
                [
                    ("arrival_date", "<=", arrival_date),
                    ("departure_date", ">", arrival_date),
                    ("reg_room_no", "=", vals["reg_room_no_one"]),
                ]
            )
            rsv_no = self.env["hotel.reservation"].search_count(
                [
                    ("arrival_date", "<=", arrival_date),
                    ("departure_date", ">", arrival_date),
                    ("room_no", "=", vals["reg_room_no_one"]),
                ]
            )
            # if reg_no > 0 and rsv_no > 0 and vals["reg_room_no_one"] != self.reg_room_no_one.id:
            #     raise ValidationError(_("This room already reserved or registered"))
            room = self.env["hms_room_setup"].search(
                [("id", "=", vals["reg_room_no_one"])]
            )
            if room.room_status != "v_clean":
                room_name = room.name
                status_label = dict(room._fields["room_status"].selection).get(
                    room.room_status
                )
                raise ValidationError(
                    _("The room %s is %s " % (room_name, status_label))
                )
            else:
                vals["reg_room_no"] = vals["reg_room_no_one"]
        if "master_room" in vals:
            if vals["master_room"] == True:
                master_reservation_obj = self.env["hms.registration"].search(
                    [("group_key", "=", self.group_key), ("master_room", "=", True)]
                )
                if master_reservation_obj.transaction_id:
                    raise ValidationError(
                        _("Master Room already exist and it has transaction added.")
                    )

                if master_reservation_obj:
                    for master in master_reservation_obj:
                        master.write({"master_room": False})

        reg_obj = super(HmsRegistraion, self).write(vals)
        # if reservation_obj.registration_id:
        reservation_obj = self.env["hms.registration"].search([("id", "=", self.id)])
        _logger.info("reservation info: %s", reservation_obj)
        if reservation_obj.id:
            guestline_info = self.env["hms.guestline"].browse(
                [("registration_id", "=", self.id)]
            )
            _logger.info("guestline info: %s", guestline_info)
            if guestline_info:
                update_guest = (
                    f"UPDATE hms_guestline SET "
                    f"name='{reservation_obj.guest_name}',"
                    f"nrc='{reservation_obj.nric}',"
                    f"nationality={reservation_obj.national.id if int(reservation_obj.national.id) else 'NULL'},"
                    f"passport_no='{reservation_obj.passport_no if reservation_obj.passport_no else ' '}',"
                    f"visa_no='{reservation_obj.visa_no if reservation_obj.visa_no else ' '}',"
                    f"phone='{reservation_obj.phone if reservation_obj.phone else ' '}',"
                    f"email='{reservation_obj.email if reservation_obj.email else ' '}',"
                    f"gender='{reservation_obj.gender}' "
                    f"WHERE registration_id={reservation_obj.id} and num_1='2'"
                )
                _logger.info("update guest %s:", update_guest)
                _logger.info(
                    f"reservation_obj.guest_name: {reservation_obj.guest_name}"
                )
                _logger.info(f"reservation_obj.nric: {reservation_obj.nric}")
                _logger.info(
                    f"reservation_obj.national.id: {reservation_obj.national.id}"
                )
                _logger.info(f"reservation_obj.passport_no: {reservation_obj.passport_no}")
                _logger.info(f"reservation_obj.visa_no: {reservation_obj.visa_no}")
                _logger.info(f"reservation_obj.phone: {reservation_obj.phone}")
                _logger.info(f"reservation_obj.email: {reservation_obj.email}")
                _logger.info(f"reservation_obj.gender: {reservation_obj.gender}")
                _logger.info(f"reservation_obj.id: {reservation_obj.id}")
                self.env.cr.execute(update_guest)

                g_update = (
                    self.env["hotel.guest"]
                    .sudo()
                    .search(
                        [
                            ("id", "=", reservation_obj.guest_key),
                            ("name", "=", reservation_obj.guest_name),
                            # ("id_no", "=", reservation_obj.nric),
                        ]
                    )
                )
                if reservation_obj.gender in ["male", "female", "na"]:
                    gender = reservation_obj.gender
                else:
                    gender = "male"
                g_update.write(
                    {
                        "name": reservation_obj.guest_name,
                        "phone": reservation_obj.phone,
                        "email_from": reservation_obj.email,
                        "passport_no": reservation_obj.passport_no or '',
                        "visa_no": reservation_obj.visa_no or '',
                        "id_no": reservation_obj.nric,
                        "gender": gender,
                        "date_of_birth": reservation_obj.date_of_birth,
                        # "national": reservation_obj.national.id,
                    }
                )
            for obj in reservation_obj.guest_ids:
                if obj.num_1 == "1":
                    _logger.info(f"{obj.num_1} --other guest")
                    citizen = "local"
                    if obj.nationality.name != "Myanmar":
                        citizen = "foreign"
                    partner_data = {
                        "name": obj.name,
                        "id_no": obj.nrc,
                        "passport_no": obj.passport_no or '',
                        "visa_no": obj.visa_no or '',
                        "email_from": obj.email,
                        "phone": obj.phone,
                        "national": obj.nationality.id,
                        "citizen": citizen
                        # "gender": obj.gender,
                    }
                    guest_info_obj = self.env["hotel.guest"].search(
                        [("name", "=", obj.name), ("id_no", "=", obj.nrc)], limit=1
                    )
                    if guest_info_obj:
                        guest_info_obj.write(partner_data)
                    else:
                        guest = self.env["hotel.guest"].create(partner_data)
                        obj.write({"guest_id": guest.id})
                else:
                    _logger.info(f"{obj} --main guest")

            group_id = False
            company_id = False
            agent_id = False
            national = False
            title = False
            if reservation_obj.reg_group_id:
                group_id = reservation_obj.reg_group_id
            if reservation_obj.reg_company_id:
                company_id = reservation_obj.reg_company_id.id
            if reservation_obj.reg_agent_id:
                agent_id = reservation_obj.reg_agent_id.id
            if reservation_obj.national:
                national = reservation_obj.national.id
            if reservation_obj.title:
                title = reservation_obj.title.id

            resv_obj = {
                # 'name': _('TBA'),
                "rsv_date": reservation_obj.reg_date,
                "arrival": reservation_obj.reg_arrival,
                "arrival_date": reservation_obj.arrival_date,
                "arrival_time": reservation_obj.arrival_time,
                "departure": reservation_obj.reg_departure,
                "departure_date": reservation_obj.departure_date,
                "departure_time": reservation_obj.departure_time,
                "Rsv_Type": "registration",
                "room_type": reservation_obj.reg_room_type.id,
                "room_no": reservation_obj.reg_room_no.id,
                "room_rate": reservation_obj.reg_room_rate,
                "customer_type": reservation_obj.reg_customer_type.id,
                "amount": reservation_obj.reg_amount,
                "currency": reservation_obj.reg_currency.id,
                "extra_bed": reservation_obj.reg_extra_bed,
                "breakfast": reservation_obj.reg_breakfast,
                "adult": reservation_obj.reg_adult,
                "child": reservation_obj.reg_child,
                "overbook": reservation_obj.reg_overbook,
                "group_id": group_id,
                "group_key": reservation_obj.group_key,
                "package_id": group_id,
                "package_key": reservation_obj.package_key,
                "group_flag": reservation_obj.reg_group_flag,
                "agent_id": agent_id,
                "company_id": company_id,
                "deposit": reservation_obj.deposit,
                # "package": reservation_obj.package,
                "remark": reservation_obj.remark,
                "special_request": reservation_obj.special_request,
                "overbook": reservation_obj.overbook,
                "title": title,
                "guest_name": reservation_obj.guest_name,
                "phone": reservation_obj.phone,
                "email": reservation_obj.email,
                "nric": reservation_obj.nric,
                "date_of_birth": reservation_obj.date_of_birth,
                "gender": reservation_obj.gender,
                "passport_no": reservation_obj.passport_no or '',
                "visa_no": reservation_obj.visa_no or '',
                "national": national,
                "contact_person": reservation_obj.contact_person,
                "contact_phone": reservation_obj.contact_phone,
                "guest_key": reservation_obj.guest_key,
            }
            if reservation_obj.reservation_id:
                resv = self.env["hotel.reservation"].search(
                    [("id", "=", reservation_obj.reservation_id)]
                )
                if resv and reservation_obj.Rsv_Type == "registration":
                    resv.write(resv_obj)

            day_use = 0
            if "dayuse" in vals:
                day_use = vals["dayuse"]
            # else:
            #     day_use = self.dayuse

            if day_use:
                transaction_parent = (
                    self.env["hms.transaction"]
                    .sudo()
                    .search([("name", "=", "Room Charges")])
                )
                trans_line_id = (
                    self.env["hms.trans.line"]
                    .sudo()
                    .search(
                        [
                            ("reg_id", "=", reservation_obj.id),
                            ("trans_lines_id", "=", transaction_parent.id),
                            ("trans_date", "=", date.today()),
                        ]
                    )
                )
                if not trans_line_id:
                    trans_obj = {
                        "trans_lines_id": transaction_parent.id,
                        "trans_price": reservation_obj.reg_amount,
                        "trans_currency": reservation_obj.reg_currency.id,
                        "trans_type": "day",
                        "trans_date": date.today(),
                        "reference": "Day Use",
                        "reg_id": reservation_obj.id,
                    }
                    self.env["hms.trans.line"].create(trans_obj)

            if reservation_obj.group_key and not reservation_obj.master_bill:
                master_reservation_obj = self.env["hms.registration"].search(
                    [
                        ("group_key", "=", reservation_obj.group_key),
                        ("master_bill", "=", True),
                        ("Rsv_Type", "!=", "transfer"),
                    ],
                    limit=1,
                )
                trans_lines = []
                for transaction in reservation_obj.transaction_id:
                    found = False
                    for master_transaction in master_reservation_obj.transaction_id:
                        if transaction.id == master_transaction.non_master_id:
                            found = True
                            break
                    if found == False:
                        trans_line = [
                            (
                                0,
                                0,
                                {
                                    "trans_lines_id": transaction.trans_lines_id.id,
                                    "trans_price": transaction.trans_price,
                                    "trans_date": transaction.trans_date,
                                    "tax": transaction.tax,
                                    "service": transaction.service,
                                    "discount": transaction.discount,
                                    "trans_type": transaction.trans_type,
                                    "trans_currency": transaction.trans_currency.id,
                                    "non_master_id": transaction.id,
                                },
                            )
                        ]
                        master_reservation_obj.transaction_id = trans_line
                    # trans_lines.append(trans_line)

            if reservation_obj.master_bill and reservation_obj.Rsv_Type != "transfer":
                for transaction in reservation_obj.transaction_id:
                    if transaction.non_master_id:
                        linked_transaction = self.env["hms.trans.line"].search(
                            [("id", "=", transaction.non_master_id)]
                        )
                        if linked_transaction.bill_name:
                            transaction.write(
                                {
                                    "bill_name": linked_transaction.bill_name,
                                    "trans_lines_id": linked_transaction.trans_lines_id.id,
                                    "trans_price": linked_transaction.trans_price,
                                    "tax": linked_transaction.tax,
                                    "service": linked_transaction.service,
                                    "discount": linked_transaction.discount,
                                    "trans_type": linked_transaction.trans_type,
                                    "trans_currency": linked_transaction.trans_currency.id,
                                    "non_master_id": linked_transaction.id,
                                }
                            )
                existing_master_bill = self.env["hms.registration"].search(
                    [
                        ("master_bill", "=", True),
                        ("id", "!=", self.id),
                        ("Rsv_Type", "=", "registration"),
                    ]
                )
                if existing_master_bill:
                    bill_ids = []
                    records_to_remove = existing_master_bill.transaction_id.filtered(
                        lambda r: r.non_master_id != False
                    )
                    existing_master_bill.write(
                        {
                            "transaction_id": [
                                (3, record.id) for record in records_to_remove
                            ],
                            "master_bill": False,
                        }
                    )
        return reg_obj

    @api.onchange("trigger_field")
    def add_guestinfo(self):
        if self.guestinfo_name:
            self.guest_ids = [
                (
                    0,
                    0,
                    {
                        "name": self.guestinfo_name,
                        "nationality": self.guestinto_nationality.id,
                        "nrc": self.guestinfo_nric,
                        "passport_no": self.guestinfo_passport_no,
                        "visa_no": self.guestinfo_visa_no,
                        "email": self.guestinfo_email,
                        "phone": self.guestinfo_phone,
                        "date_of_birth": self.guestinfo_dob,
                        "gender": self.guestinfo_gender,
                        "num_1": "1",
                        "guest_id": self.guestinfo_key,
                    },
                )
            ]
            self.guestinfo_name = ""
            self.guestinfo_key = False
            self.guestinfo_nric = ""
            self.guestinfo_passport_no = ""
            self.guestinfo_visa_no = ""
            self.guestinfo_email = ""
            self.guestinfo_phone = ""
            self.guestinfo_dob = ""
            self.guestinfo_gender = False
            self.num_1 = ""
            self.guestinto_nationality = False

    @api.onchange("reg_room_type")
    def _onchange_reg_room_type(self):
        if self.reg_room_type and self.reg_room_type != self.reg_room_no.room_type:
            self.reg_room_no = False

    # show this field for confirm alert box
    @api.onchange("reg_room_no", "reg_room_type")
    def _compute_room_name(self):
        room_name = ""
        room_type_name = ""
        room_no_one = False
        for rec in self:
            if rec.reg_room_no:
                room_name = rec.reg_room_no.name
                # room_no_one = rec.reg_room_no

            if rec.reg_room_type.id:
                room_type_name = rec.reg_room_type.name
            rec.reg_room_name = room_name
            rec.reg_room_type_name = room_type_name
            # rec.reg_room_no_one = room_no_one

    @api.onchange("reg_room_no")
    def _compute_room_no(self):
        self.reg_room_no_one = self.reg_room_no

    @api.depends(
        "reg_room_type",
        "reg_customer_type",
        "reg_extra_bed",
        "reg_breakfast",
        "arrival_date",
        "reg_currency",
    )
    def _compute_room_amount(self):
        for guest in self:
            rateData = self.env["hms_room_rate"].search(
                [
                    ("room_type", "=", guest.reg_room_type.id),
                    ("customer_type", "=", guest.reg_customer_type.id),
                    ("currency", "=", guest.reg_currency.id),
                    ("from_date", "<=", guest.arrival_date),
                    ("to_date", ">=", guest.arrival_date),
                ],
                limit=1,
            )
            guest.reg_amount = rateData.room_rate
            # extra bed
            if guest.reg_extra_bed == "0":
                guest.reg_amount = guest.reg_amount
            else:
                guest.reg_amount += rateData.extra_bed * int(guest.reg_extra_bed)
            # break fast
            if rateData.room_type and rateData.rate_type:
                if guest.reg_breakfast:
                    guest.reg_amount += rateData.breakfast

    # Messages Ref modal relatedAction
    def copy_reg_guest_name(self):
        g_id = 0
        for rec in self:
            g_id = rec.id
        return g_id

    @api.onchange("group_key")
    def _onchange_group_name(self):
        for rec in self:
            if rec.group_key:
                group_data = self.env["hms.groupreserve"].search(
                    [("id", "=", rec.group_key)], order="id desc", limit=1
                )
                if group_data:
                    rec.reg_group_id = group_data.name
                    rec.group_key = group_data.id

    @api.onchange("package_key")
    def _onchange_package_name(self):
        for rec in self:
            if rec.package_key:
                transaction_lines = []
                # for transaction in rec.transaction_id:
                #     transaction_lines.append(transaction)

                package_data = self.env["hms.package"].search(
                    [("id", "=", rec.package_key)]
                )

                if rec.id.origin:
                    # Delete package transaction of Folio in Edit Mode if exists
                    package_transaction_line = self.env["hms.trans.line"].search(
                        [("reg_id", "=", rec.id.origin), ("trans_type", "=", "package")]
                    )
                    if package_transaction_line:
                        package_transaction_line.unlink()

                    # Add new package transaction of Folio in Edit Mode
                    package_transaction = (
                        self.env["hms.transaction"]
                        .sudo()
                        .search([("name", "=", "Package")])
                    )
                    if package_data:
                        rec.package_id = package_data.name
                        rec.package_key = package_data.id

                        package_object = (
                            0,
                            0,
                            {
                                "trans_lines_id": package_transaction.id,
                                "trans_price": package_data.total_amt,
                                "trans_type": "package",
                                "trans_currency": package_data.currency.id,
                                "reference": package_data.name,
                                # 'pack_id': rec.package_key,
                                "reg_id": rec.id.origin,
                            },
                        )
                        package_trans_line = self.env["hms.trans.line"].create(
                            package_object
                        )

    def show_booking_chart(self):
        for rec in self:
            return {
                "name": "Booking Chart",
                "type": "ir.actions.act_window",
                "view_type": "timeline",
                "view_mode": "timeline",
                "res_model": "hotel.reservation",
                "view_id": self.env.ref(
                    "hotelia.reservation_timeline_booking_chart"
                ).id,
            }

    def name_get(self):
        res = []
        fname = ""
        for rec in self:
            if rec.name:
                fname = "Reg" + str(rec.name)
                res.append((rec.id, fname))

        return res

    def _onchange_reg_key(self):
        for rec in self:
            # import pdb; pdb.set_trace()
            rec.all_billed = True
            # _logger.info("all_billed is True for record %s", rec.id)
            # rec.all_billed = all(transaction.bill_name == False for transaction in rec.transaction_id)
            for transaction in rec.transaction_id:
                if not transaction.bill_name:
                    rec.all_billed = False
            # _logger.info("all_billed is value for record %s", rec.all_billed)
            if rec.bill_delete:
                for transaction in rec.transaction_id:
                    if not transaction.bill_id:
                        rec.all_billed = False
            # _logger.info("all_billed value for record %s is %s", rec.all_billed)
            _logger.info("all_billed value: %s", rec.all_billed)

    def _compute_bill_count(self):
        for rec in self:
            rec.bill_count = self.env["hotel.bill"].search_count(
                [("reg_ids", "=", rec.id)]
            )

    def _compute_delivery_order_count(self):
        for rec in self:
            rec.delivery_order_count = self.env["stock.picking"].search_count(
                [
                    ("customer_name", "=", rec.guest_name),
                    ("room", "=", rec.reg_room_no.name),
                ]
            )

    def _compute_message_count(self):
        for rec in self:
            rec.message_count = self.env["hotel.message"].search_count(
                [("reg_key", "=", rec.id)]
            )

    def open_bill_view(self):
        return {
            "name": _("Bills"),
            "domain": [("reg_ids", "=", self.id)],
            "res_model": "hotel.bill",
            "type": "ir.actions.act_window",
            "context": self._context,
            # 'view_id': self.env.ref('hms_integration.add_account_move_view_tree').id,
            "views": [[False, "tree"], [False, "kanban"], [False, "form"]],
            "view_mode": "tree, kanban, form",
        }

    def open_minibar_delivery_order_view(self):
        delivery_order_view = {
            "name": _("Delivery Orders"),
            "domain": [
                ("customer_name", "=", self.guest_name),
                ("room", "=", self.reg_room_no.name),
            ],
            "res_model": "stock.picking",
            "type": "ir.actions.act_window",
            "context": self._context,
            "views": [[False, "tree"], [False, "kanban"], [False, "form"]],
            "view_mode": "tree, kanban, form",
        }
        return delivery_order_view

    def open_message_view(self):
        return {
            "name": _("Messages"),
            "domain": [("reg_key", "=", self.id)],
            "res_model": "hotel.message",
            "type": "ir.actions.act_window",
            "context": self._context,
            # 'view_id': self.env.ref('hms_integration.add_account_move_view_tree').id,
            "views": [[False, "tree"], [False, "kanban"], [False, "form"]],
            "view_mode": "tree, kanban, form",
        }

    def open_bill(self):
        bill_amount = 0
        trans_lines = []
        for transaction in self.transaction_id:
            if not transaction.bill_name:
                base_currency = self.env["res.currency"].search(
                    [("hotelia_base_currency", "=", True)], limit=1
                )
                company_obj = self.env.user.sudo().company_id

                changed_currency = transaction.trans_currency
                if not changed_currency:
                    changed_currency = base_currency
                rate = base_currency._get_conversion_rate(
                    changed_currency, base_currency, company_obj, datetime.now().date()
                )
                bill_amount = bill_amount + (transaction.trans_price * rate)
                trans_line = (
                    0,
                    0,
                    {
                        "trans_lines_id": transaction.trans_lines_id.id,
                        "trans_price": transaction.trans_price,
                        "trans_currency": changed_currency.id,
                        "reg_id": self.id,
                    },
                )
                trans_lines.append(transaction.id)
        base_currency = self.env["res.currency"].search(
            [("hotelia_base_currency", "=", True)], limit=1
        )
        payment_code = self.env["hotel.payment"].search(
            [("currency", "=", base_currency.id), ("payment_group", "=", "cash")],
            limit=1,
        )
        payment_line = [
            (
                0,
                0,
                {
                    "payment_code": payment_code.id,
                    # "currency": base_currency.id,
                    # "rate": 1.0,
                    "amount": bill_amount,
                },
            )
        ]
        return {
            "name": _("Bill"),
            "type": "ir.actions.act_window",
            "view_type": "form",
            "view_mode": "form",
            "res_model": "hotel.bill",
            "context": {
                "default_all_or_transactions": "all",
                "default_date": True,
                "default_reg_ids": self.id,
                "default_transaction_lines": trans_lines,
                "default_bill_amount": bill_amount,
                "default_payment_amount": bill_amount,
                "default_payment_lines": payment_line,
                "default_trigger_field_search": "something",
                "default_trigger_field_add": "something",
                "default_trigger_field_ip": "something",
            },
        }

    def open_transfer(self):
        trans_lines = []

        for transaction in self.transaction_id:
            if not transaction.bill_name:
                self.bill_transfer_flag = True
                self.transaction_id = [
                    (
                        1,
                        transaction.id,
                        {
                            "trans_lines_id": transaction.trans_lines_id.id,
                            "trans_price": transaction.trans_price,
                            "trans_currency": transaction.trans_currency.id,
                            "reg_id": self.id,
                            "data_type": "left",
                        },
                    )
                ]
                trans_lines.append(transaction.id)

        # bill_transfer = self.env["hotel.bill_transfer"].create({
        #     "reg_ids": self.id,
        #     "guest_name": self.guest_name,
        #     "arrival": self.reg_arrival,
        #     "departure": self.reg_departure,
        #     "agent": self.reg_agent_id.id,
        #     "group": self.reg_group_id,
        #     "transaction_lines": trans_lines
        # })

        # transfer_action = {
        #     'type': 'ir.actions.act_window',
        #     'res_model': 'hotel.bill_transfer',
        #     'view_mode': 'form',
        #     'res_id': bill_transfer.id,
        #     'target': 'current',
        # }

        # return transfer_action

        return {
            "name": _("Transfer"),
            "type": "ir.actions.act_window",
            "view_type": "form",
            "view_mode": "form",
            "res_model": "hotel.bill_transfer",
            "context": {
                "default_all_or_transactions": "all",
                "default_date": True,
                "default_reg_ids": self.id,
                "default_guest_name": self.guest_name,
                "default_arrival": self.reg_arrival,
                "default_departure": self.reg_departure,
                "default_agent": self.reg_agent_id.id,
                "default_group": self.reg_group_id,
                "default_transaction_lines": trans_lines,
            },
        }

    def compute_payment_status(self):
        for rec in self:
            payment_status = "pending"
            unpaid_count = self.env["hms.trans.line"].search_count(
                [("reg_id", "=", rec.id), ("bill_id", "=", False)]
            )
            bills = self.env["hotel.bill"].search([("reg_ids", "=", rec.id)])
            partial_count = 0
            if bills:
                for bill in bills:
                    partial_count += self.env["hotel.payment.line"].search_count(
                        [
                            ("bill_id", "=", bill.id),
                            ("payment_code.payment_group", "!=", "cash"),
                        ]
                    )
                    payment_status = "partial"
            if rec.transaction_id and unpaid_count == 0 and partial_count == 0:
                payment_status = "paid"
            rec.payment_status = payment_status

    def checkout(self):
        check_bill = self.env["hms.trans.line"].search_count(
            [("bill_name", "=", False), ("reg_id", "=", self.id)]
        )
        current_date = datetime.now()
        new_date = current_date + timedelta(days=1)
        if check_bill == 0:
            if self.function_resv_id:
                function_room = self.env["function.room"].search(
                    [("id", "=", self.function_resv_id)]
                )
                if function_room:
                    function_room.write({"status": "check_out"})
            super(HmsRegistraion, self).write(
                {
                    "Rsv_Type": "check_out",
                    "reg_departure": new_date,
                    "departure_date": fields.Date.today(),
                }
            )
            rsv_checkout_data = self.env["hotel.reservation"].search(
                [("id", "=", self.reservation_id)]
            )
            if rsv_checkout_data:
                rsv_checkout_data.write(
                    {
                        "Rsv_Type": "check_out",
                        "departure": new_date,
                        "departure_date": fields.Date.today(),
                    }
                )

            self.reg_departure = new_date
            self.departure_date = fields.Date.today()
            b = (
                self.env["hms_room_setup"]
                .sudo()
                .search(
                    [
                        ("name", "=", self.reg_room_no.name),
                        ("room_type", "=", self.reg_room_type.id),
                    ]
                )
            )
            b.write(
                {
                    "room_status": "v_dirty",
                }
            )
            noti = {
                "type": "ir.actions.client",
                "tag": "display_notification",
                "params": {
                    "type": "info",
                    "sticky": False,
                    "message": _("Checkout Completed"),
                    "fadeout": "slow",
                    "next": {
                        "type": "ir.actions.act_window_close",
                    },
                },
            }
            return noti
        else:
            message_id = self.env["warning.wizard"].create(
                {"message": _("Guest has some bills to pay.")}
            )
            return {
                "name": _("Warning"),
                "type": "ir.actions.act_window",
                "view_mode": "form",
                "res_model": "warning.wizard",
                # pass the id
                "res_id": message_id.id,
                "target": "new",
            }

    def gpcheckout(self):
        check_group = self.env["hms.registration"].search(
            [("group_key", "=", self.group_key)]
        )
        if check_group:
            for data in check_group:
                check_bill = self.env["hms.trans.line"].search_count(
                    [("reg_id", "=", data.id), ("bill_name", "=", False)]
                )
                current_date = datetime.now()
                new_date = current_date + timedelta(days=1)
                if check_bill == 0:
                    super(HmsRegistraion, data).write(
                        {
                            "Rsv_Type": "check_out",
                            "reg_departure": new_date,
                            "departure_date": fields.Date.today(),
                        }
                    )
                    data.reg_departure = new_date
                    data.departure_date = fields.Date.today()
                    b = (
                        self.env["hms_room_setup"]
                        .sudo()
                        .search(
                            [
                                ("name", "=", data.reg_room_no.name),
                                ("room_type", "=", data.reg_room_type.id),
                            ]
                        )
                    )
                    b.write(
                        {
                            "room_status": "v_dirty",
                        }
                    )
                else:
                    message_id = self.env["warning.wizard"].create(
                        {"message": _("Guest has some bills to pay.")}
                    )
                    return {
                        "name": _("Warning"),
                        "type": "ir.actions.act_window",
                        "view_mode": "form",
                        "res_model": "warning.wizard",
                        "res_id": message_id.id,
                        "target": "new",
                    }
            noti = {
                "type": "ir.actions.client",
                "tag": "display_notification",
                "params": {
                    "type": "info",
                    "sticky": False,
                    "message": _("Group Checkout Completed"),
                    "fadeout": "slow",
                    "next": {
                        "type": "ir.actions.act_window_close",
                    },
                },
            }
            return noti

    def unlink(self):
        for rec in self:
            reservation = self.env["hotel.reservation"].search(
                [("id", "=", rec.reservation_id)]
            )
            reservation.unlink()
            super(HmsRegistraion, rec).unlink()

    def compute_daterange(self, month):
        """
        Give a month as an integer.\n
        Compute the first and last dates of that month.\n
        Return a tuple containing the first date and last date.
        """
        current_year = datetime.now().year
        first_date = date(current_year, month, 1)

        if month == 12:
            next_month = 1
            next_year = current_year + 1
        else:
            next_month = month + 1
            next_year = current_year

        last_date = date(next_year, next_month, 1) - timedelta(days=1)

        return (first_date, last_date)

    def total_registration(self, current_month=datetime.now().month):
        fast_date, last_date = self.compute_daterange(month=current_month)
        registration_count: int = self.env["hms.registration"].search_count(
            [
                ("create_date", ">=", fast_date),
                ("create_date", "<=", last_date),
                ("Rsv_Type", "!=", "cancel"),
                ("Rsv_Type", "!=", "transfer"),
            ]
        )
        return registration_count

    def total_checkout(self, current_month=datetime.now().month):
        fast_date, last_date = self.compute_daterange(month=current_month)
        checkout_count = self.env["hms.registration"].search_count(
            [
                ("create_date", ">=", fast_date),
                ("create_date", "<=", last_date),
                ("Rsv_Type", "=", "check_out"),
            ]
        )
        return checkout_count

    @api.onchange("master_bill")
    def master_bill_chante(self):
        for rec in self:
            if rec.master_bill == True:
                record_ids = []
                for master in rec.transaction_id:
                    record_ids.append(master.id)
                same_gp_checkins = self.env["hms.registration"].search(
                    [
                        ("group_key", "=", rec.group_key),
                        ("id", "!=", rec._origin.id),
                        ("Rsv_Type", "=", "registration"),
                    ]
                )
                existing_master = self.env["hms.registration"].search(
                    [("group_key", "=", rec.group_key), ("master_bill", "=", True)]
                )

                for same_gp_checkin in same_gp_checkins:
                    for transaction in same_gp_checkin.transaction_id:
                        if not transaction.non_master_id:
                            found = False
                            for exist in rec.transaction_id:
                                if transaction.id == exist.non_master_id:
                                    found = True
                                    break
                            if found == False:
                                trans = {
                                    "trans_lines_id": transaction.trans_lines_id.id,
                                    "trans_date": transaction.trans_date,
                                    "trans_price": transaction.trans_price,
                                    "tax": transaction.tax,
                                    "service": transaction.service,
                                    "discount": transaction.discount,
                                    "trans_type": transaction.trans_type,
                                    "trans_currency": transaction.trans_currency.id,
                                    "non_master_id": transaction.id,
                                }
                                bill_name = ""
                                bill_id = False
                                # if transaction.bill_id:
                                #     trans['bill_id'] = transaction.bill_id.id
                                if transaction.bill_name:
                                    trans["bill_name"] = transaction.bill_name
                                trans_line = [
                                    (
                                        0,
                                        0,
                                        trans,
                                    )
                                ]
                                rec.transaction_id = trans_line
            else:
                if rec.transaction_id:
                    records_to_remove = rec.transaction_id.filtered(
                        lambda r: r.non_master_id != False
                    )
                    rec.transaction_id -= records_to_remove

    def open_room_transfer_wizard(self):
        return {
            "name": _("Room Transfer"),
            "type": "ir.actions.act_window",
            "view_type": "form",
            "view_mode": "form",
            "target": "new",
            "res_model": "room.transfer.wizard",
            "context": {
                "default_reg_no": self.id,
            },
        }

    def action_cancel(self):
        if self.transaction_id:
            message_id = self.env["warning.wizard"].create(
                {
                    "message": _(
                        "You cannot cancel registration which already have transactions."
                    )
                }
            )
            return {
                "name": _("Warning"),
                "type": "ir.actions.act_window",
                "view_mode": "form",
                "res_model": "warning.wizard",
                # pass the id
                "res_id": message_id.id,
                "target": "new",
            }
        else:
            current_date = datetime.now()
            new_date = current_date + timedelta(days=1)
            super(HmsRegistraion, self).write(
                {
                    "Rsv_Type": "cancel",
                    "reg_departure": new_date,
                    "departure_date": fields.Date.today(),
                }
            )
            # Update Occupied dirty in Room Setup Form
            if self.reg_room_no:
                room_setup_obj = self.env["hms_room_setup"].search(
                    [("id", "=", self.reg_room_no.id)]
                )
                if room_setup_obj:
                    room_setup_obj.write({"room_status": "v_dirty"})
            if self.reservation_id:
                reservation = self.env["hotel.reservation"].search(
                    [("id", "=", self.reservation_id)]
                )
                if reservation:
                    reservation.write({"Rsv_Type": "cancel"})
            noti = {
                "type": "ir.actions.client",
                "tag": "display_notification",
                "params": {
                    "type": "info",
                    "sticky": False,
                    "message": _("Cancel Completed"),
                    "fadeout": "slow",
                    "next": {
                        "type": "ir.actions.act_window_close",
                    },
                },
            }
            return noti

    def fields_get(self, allfields=None, attributes=None):
        result = super().fields_get(allfields=allfields, attributes=attributes)

        fields_to_hide = [
            "bc_name",
            "guestinfo_key",
            "guestinfo_name",
            "guestinfo_nric",
            "guestinfo_passport_no",
            "guestinfo_visa_no",
            "reg_overbook",
            "f_room",
            "f_type",
            "guestinfo_phone",
            "function_id",
            "reg_sequence",
            "reg_room_no_one",
            "transaction_id",
            "all_billed",
            "bill_count",
            "message_count",
            "cashier",
            "group_key",
            "reg_group_flag",
            "master_bill",
            "guest_name_testing",
            "guestinfo_nric",
            "folio_transaction_field_trans_type",
            "guest_key",
            "guestinfo_name",
            "guestinfo_nric",
            "guestinfo_passport_no",
            "guestinfo_visa_no",
            "guestinfo_phone",
            "guestinfo_email",
            "guestinfo_dob",
            "guestinfo_gender",
            "guestinto_nationality",
            "time_1",
            "guestinfo_email",
            "guestinfo_dob",
            "guestinfo_gender",
            "guestinto_nationality",
            "trigger_field",
            "num_1",
            "folio_transaction_field_trans_price",
            "folio_transaction_field_trans_currency",
            "folio_transaction_field_trans_currency_rate",
            "folio_transaction_field_service",
            "folio_transaction_field_discount",
            "folio_transaction_field_tax",
            "folio_transaction_field_reference",
            "folio_transaction_field_bill_name",
            "folio_transaction_field_trigger_field",
            "total_pax_count",
            "concatenated_field",
            "concatenated_master",
            "time_2",
            "time_3",
            "f_deposit",
            "gp_checkin",
            "namebind",
            "folio_transaction_field_date",
            "guest_key",
            "group_key",
        ]  # Replace with the field names you want to hide

        for field_name in fields_to_hide:
            if field_name in result:
                result[field_name]["searchable"] = False
                result[field_name]["sortable"] = False

        return result

    def get_registration(self):
        minibar_transaction = self.env["hotel.minibar_transaction"]
        registration = self
        minibar_transaction.copy_registration(data=registration)

        registration_id = 0
        for rec in self:
            registration_id = rec.id
        return registration_id

    # set guestline_data based on all registration
    # registration num1->1
    # geust_line num1->2
    def action_running(self):
        reg_data = self.env["hms.registration"].sudo().search([("num_1", "=", "1")])
        for r in reg_data:
            if r.guest_key:
                g_line_data = (
                    self.env["hms.guestline"]
                    .sudo()
                    .search([("registration_id", "=", r.id), ("num_1", "=", "2")])
                )
                g_line_data.write({"guest_id": r.guest_key})

    # find guests who have registration and assign that guest to incomplete registration
    def action_nomain(self):
        nomain_data = (
            self.env["hms.guestline"]
            .sudo()
            .search([("num_1", "=", "1"), ("registration_id", "!=", "0")])
        )
        for r in nomain_data:
            if not r.guest_id:
                guest = (
                    self.env["hotel.guest"]
                    .sudo()
                    .search([("name", "=", r.name), ("id_no", "=", r.nrc)])
                )
                r.write({"guest_id": guest.id})

    def open_transfer_window(self):
        view_id = self.env.ref("hotelia.bill_transfer_wizard").id
        return {
            "name": "Bill Transfer Wizard",
            "type": "ir.actions.act_window",
            "view_mode": "form",
            "view_id": view_id,
            "res_model": "your.model.wizard",
            "target": "new",
        }
