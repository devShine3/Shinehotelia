from datetime import date
from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime, timedelta, date
from odoo.http import request


class ManagerReport(models.TransientModel):
    _name = "manager.report.wizard"
    _description = "Manager Report"
    _inherit = ["portal.mixin"]

    def _today_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=0)
        return new_date

    report_date = fields.Datetime("Report Date :", default=_today_date)
    report_type = fields.Selection(
        [
            ("bydate", "By Daily"),
            ("bymonth", "By Monthly"),
            ("byyear", "By Yearly"),
        ],
        default="bymonth",
    )

    cdate = fields.Date("Choose Date :", default=date.today())
    cyear = fields.Integer("Choose Year :", default="2023")
    yearfrom = fields.Integer(string="From Year", default="2020")
    yearto = fields.Integer(string="To Year", default="2023")

    def action_print_manager_report(self):
        data = {}
        data["form"] = self.read(
            ["report_type", "report_date", "cdate", "cyear", "yearfrom", "yearto"]
        )[0]
        return self.env.ref("hotelia.action_manager_report_template").report_action(
            self, data=data
        )

    def preview_manager(self):
        print("preview_manager")
        data = {}
        data["form"] = self.read(
            ["report_type", "report_date", "cdate", "cyear", "yearfrom", "yearto"]
        )[0]

        action_manager_report_template = self.env["report.hotelia.report_manager"]
        manager_data = {
            "data": data["form"],
            "lines": action_manager_report_template.get_lines(data.get("form")),
        }

        print_data = data

        request.session["manager_data"] = manager_data
        request.session["print_data"] = print_data

        self.ensure_one()
        return {
            "type": "ir.actions.act_url",
            "target": "",
            "url": self.get_portal_url(),
        }

    def _compute_access_url(self):
        super(ManagerReport, self)._compute_access_url()
        for manager in self.filtered(lambda manager: manager.is_manager()):
            manager.access_url = "/my/manager/report"

    def is_manager(self):
        correct_manager = False
        if self:
            correct_manager = True
        return correct_manager
