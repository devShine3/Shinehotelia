from datetime import datetime
from datetime import date
from odoo import api, fields, models, Command, _


class BillTransfer(models.Model):
    _name = "hotel.bill_transfer"
    _description = "Hotelia Bill Transfer"
    name = fields.Char(
        "Transfer No.", copy=False, readonly=True, default=lambda self: _("TBA")
    )
    transfer_date = fields.Date("Transfer Date", default=datetime.today())
    sequence = fields.Integer("Sequence")

    reg_ids = fields.Many2one("hms.registration", string="Reg No.")
    guest_name = fields.Char(string="Guest Name")
    arrival = fields.Datetime("Arrival Date", default=date.today())
    departure = fields.Datetime("Departure Date", default=date.today())
    agent = fields.Char(string="Agent")
    group = fields.Char("Group")
    transaction_lines = fields.One2many(
        "hms.trans.line", "bill_transfer_id", domain="[('bill_name', '=', False)]"
    )

    right_reg_ids = fields.Many2one(
        "hms.registration",
        string="Reg No.",
        required=True,
        domain="[('id', '!=', reg_ids),('Rsv_Type','=','registration')]",
    )
    right_guest_name = fields.Char(string="Guest Name")
    right_arrival = fields.Datetime("Arrival Date", default=date.today())
    right_departure = fields.Datetime("Departure Date", default=date.today())
    right_agent = fields.Char(string="Agent")
    right_group = fields.Char("Group")
    right_transaction_lines = fields.One2many("hms.trans.line", "bill_transfer_id")

    @api.model
    def create(self, vals):
        if vals.get("name", _("TBA")) == _("TBA"):
            sql = "select coalesce(max(sequence),0)+1 from hotel_bill_transfer"
            self.env.cr.execute(sql)
            result = self.env.cr.fetchall()
            vals["sequence"] = result[0][0]
            sequence_number = str(result[0][0])
            if len(str(result[0][0])) == 1:
                sequence_number = "00" + str(result[0][0])
            if len(str(result[0][0])) == 2:
                sequence_number = "0" + str(result[0][0])
            if len(str(result[0][0])) > 2:
                sequence_number = str(result[0][0])
            vals["name"] = sequence_number
        bill_transfer = super(BillTransfer, self).create(vals)
        return bill_transfer

    def write(self, vals):
        result = super(BillTransfer, self).write(vals)
        return result

    def unlink(self, vals):
        result = super(BillTransfer, self).unlink()
        return result

    @api.onchange("right_reg_ids")
    def _onchange_reg(self):
        for rec in self:
            if rec.reg_ids:
                reg_trans_data = self.env["hms.registration"].search(
                    [("id", "=", rec.right_reg_ids.id)], order="id desc", limit=1
                )
                if reg_trans_data:
                    rec.right_guest_name = reg_trans_data.guest_name
                    rec.right_arrival = reg_trans_data.reg_arrival
                    rec.right_departure = reg_trans_data.reg_departure
                    rec.right_agent = reg_trans_data.reg_agent_id.id
                    rec.right_group = reg_trans_data.reg_group_id
                    right_ids = []
                    for transaction in reg_trans_data.transaction_id:
                        if (
                            not transaction.bill_name
                        ):  # to filter trasaction completed bill
                            reg_trans_data.transaction_id = [
                                (
                                    1,
                                    transaction.id,
                                    {
                                        "data_type": "right",
                                    },
                                )
                            ]
                            right_ids.append(transaction.id)
                    rec.right_transaction_lines = right_ids

    @api.depends("reg_ids", "right_reg_ids")
    def transfer_right(self):
        for rec in self:
            if rec.reg_ids:
                for trans in rec.transaction_lines:
                    if trans.select and not trans.bill_name:
                        trans.write(
                            {
                                "reg_id": rec.right_reg_ids.id,
                                "data_type": "right",
                                "reference": "transfered bill from "
                                + str(rec.reg_ids.reg_room_no.display_name),
                            }
                        )

                        # rec.right_transaction_lines = [(1, trans.id, {
                        #     'reg_id': rec.right_reg_ids.id,
                        #     'data_type': 'right',
                        #     'reference' : 'transfered bill from ' + str(rec.right_reg_ids.id),
                        # })]

                        # rec.right_transaction_lines = [Command.create({
                        #     'reg_id': rec.right_reg_ids.id,
                        #     'trans_lines_id': trans.trans_lines_id.id,
                        #     'trans_price': trans.trans_price,
                        #     'trans_currency': trans.trans_currency.id,
                        #     'trans_type': trans.trans_type,
                        #     'data_type': 'right',
                        #     'reference' : 'transfered bill from ' + str(rec.reg_ids.reg_room_no.display_name),
                        # })]

    def transfer_left(self):
        for rec in self:
            if rec.right_reg_ids:
                for trans in rec.right_transaction_lines:
                    if trans.select and not trans.bill_name:
                        trans.write(
                            {
                                "reg_id": rec.reg_ids.id,
                                "data_type": "left",
                                "reference": "transfered bill from "
                                + str(rec.right_reg_ids.reg_room_no.display_name),
                            }
                        )

                        # rec.transaction_lines = [(1, trans.id, {
                        #     'reg_id': rec.reg_ids.id,
                        #     'data_type': 'left',
                        #     'reference' : 'transfered bill from ' + str(rec.reg_ids.id),
                        # })]

                        # rec.transaction_lines = [Command.create({
                        #     'reg_id': rec.reg_ids.id,
                        #     'trans_lines_id': trans.trans_lines_id.id,
                        #     'trans_price': trans.trans_price,
                        #     'trans_currency': trans.trans_currency.id,
                        #     'trans_type': trans.trans_type,
                        #     'data_type': 'left',
                        #     'reference' : 'transfered bill from ' + str(rec.right_reg_ids.reg_room_no.display_name),
                        # })]


class TransactionLine(models.Model):
    _name = "bill_transfer.trans.line"
    _inherit = "hms.trans.line"

    bill_transfer_id = fields.Many2one("hotel.bill_transfer", "Bill Transfer")
    transaction_line_id = fields.Many2one("hms.trans.line", "Transaction Line")


class RightTransactionLine(models.Model):
    _name = "bill_transfer.right_trans.line"
    _inherit = "hms.trans.line"

    bill_transfer_id = fields.Many2one("hotel.bill_transfer", "Bill Transfer")
    transaction_line_id = fields.Many2one("hms.trans.line", "Transaction Line")
