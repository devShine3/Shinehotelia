from odoo import api, fields, models, tools, _


# class CreateGuestWizard(models.TransientModel):
# _name = "hmslite.guestwizard"
# _description ="Guest Wizard List"
# name = fields.Char('Name')


class CreateGuestWizard(models.Model):
    _inherit = "hotel.guest"

    guest_key = fields.Integer("Guest ID")

    def open_table(self):
        result = super(CreateGuestWizard, self).invoice_refund()
        obj = self.env["hotel.guest"].browse(self._context.get("active_id"))
        obj.guest_key = self.id
        print(obj.guest_key, "Guest Key")
        return result

    def copy_name(self):
        hotel_reservation = self.env["hotel.reservation"].browse(
            self._context.get("active_id")
        )
        for rec in self:
            hotel_reservation.guest_name = rec.name
