from odoo import api, fields, models, tools, _
from odoo.http import request
import datetime
import logging

_logger = logging.getLogger(__name__)


class GuestInHouseWizard(models.TransientModel):
    def _today_date(self):
        new_date = fields.Date.today()
        return new_date

    _name = "hotel.reservation.inhouse.wizard"
    _inherit = ["portal.mixin"]
    # _inherit = 'report.report_xlsx.abstract'

    data = fields.Binary("Data", readonly=True)

    report_date = fields.Date("Report Date :", default=_today_date)
    choose_date = fields.Date(String="Choose Date", default=_today_date)
    type_reservation = fields.Selection(
        [
            ("all", "All"),
            ("group", "Group"),
            ("agent", "Agent"),
            ("company", "Company"),
        ],
        default="all",
    )
    agent = fields.Many2one("hmslite.agentsetup", String="Agent")
    company = fields.Many2one("hmslite.companysetup", String="Company")
    group = fields.Many2one("hms.groupreserve", String="Group")
    report_type = fields.Selection(
        [
            ("byroom", "By Room"),
            ("immigration", "Immigration"),
            ("police", "Police"),
            ("iall", "Immigration for All"),
        ],
        "Report Type",
        default="byroom",
    )
    national = fields.Selection(
        [("local", "Local"), ("foreigner", "Foreigner")], "Citizen"
    )

    def action_guest_in_house_report(self):
        data = {}
        print(data)
        data["form"] = self.read()[0]
        if (
            data["form"]["report_type"] == "byroom"
            or data["form"]["report_type"] == "iall"
        ):
            data["form"]["national"] = False

        return (
            self.env.ref("hotelia.action_guest_in_house_template")
            .with_context(landscape=True)
            .report_action(self, data=data)
        )

    # @api.multi
    def action_guest_in_house_report_xlsx(self):
        data = {}
        print(data)
        data["form"] = self.read()[0]
        if (
            data["form"]["report_type"] == "byroom"
            or data["form"]["report_type"] == "iall"
        ):
            data["form"]["national"] = False

        return (
            self.env.ref("hotelia.action_guest_in_house_template_xlsx")
            .with_context(landscape=True)
            .report_action(self, data=data)
        )

    def preview_guest_in_house(self):
        data = {}
        data["form"] = self.read()[0]
        if (
            data["form"]["report_type"] == "byroom"
            or data["form"]["report_type"] == "iall"
        ):
            data["form"]["national"] = False

        guest_in_house_report_template = self.env[
            "report.hotelia.report_guest_in_house_details"
        ]
        guest_in_house_data = {
            "data": data["form"],
            "lines": guest_in_house_report_template.get_lines(data.get("form")),
        }
        # print(guest_in_house_data)
        # guest_in_house_report_xlsx = self.env['report.hotelia.report_gih_xlsx']
        # guest_in_house_excel_data = {
        #     'data': data['form'],
        # }
        # try:
        #     guest_in_house_report_xlsx.data = guest_in_house_excel_data
        # except Exception as e:
        #     _logger.error("Error during data assignment: %s", str(e))
        # print(guest_in_house_report_xlsx.data)
        print_data = data

        request.session["guest_in_house_data"] = guest_in_house_data
        # request.session['guest_in_house_excel_data'] = guest_in_house_excel_data
        request.session["print_data"] = print_data

        self.ensure_one()
        return {
            "type": "ir.actions.act_url",
            "target": "",
            "url": self.get_portal_url(),
        }

    # def action_guest_in_house_report_xlsx(self):
    #     data = {}
    #     data['form'] = self.read()[0]
    #
    #     # Generate the Excel report (replace this with your actual report generation logic).
    #     excel_data = hotelia.generate_excel_report(data)
    #
    #     # Store the Excel data in the session.
    #     request.session['excel_data'] = excel_data
    #
    #     return self.env.ref('hotelia.action_guest_in_house_template_xlsx').with_context(
    #         landscape=True).report_action(self, data=data)

    def _compute_access_url(self):
        super(GuestInHouseWizard, self)._compute_access_url()
        for guest_in_house in self.filtered(
            lambda guest_in_house: guest_in_house.is_guest_in_house()
        ):
            guest_in_house.access_url = "/my/guest_in_house/report"

    def is_guest_in_house(self):
        correct_guest_in_house = False
        if self:
            correct_guest_in_house = True
        return correct_guest_in_house
