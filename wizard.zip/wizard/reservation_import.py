import datetime
import time
from odoo import models, fields, _, api
import openpyxl
import base64
import io
from odoo.exceptions import UserError


class ImportReservationWizard(models.TransientModel):
    _name = "import.reservation.wizard"

    file = fields.Binary(string="File")

    def import_reservation(self):
        if self.file:
            wb = openpyxl.load_workbook(
                filename=io.BytesIO(base64.b64decode(self.file)), read_only=True
            )
            ws = wb.active
            reservation_id = []

            last_record = (
                self.env["hotel.reservation"]
                .search([], order="id desc", limit=1)
                .sequence
            )

            for i, record in enumerate(ws.iter_rows(min_row=2, values_only=True)):
                name_int = int(last_record) + i + 1
                name_str = "{:03d}".format(name_int)

                if record[0]:
                    new_reservation = self.env["hotel.reservation"].create(
                        {
                            "name": name_str,
                            "sequence": name_int,
                            "guest_name": record[0],
                            "arrival": record[1],
                            "departure": record[2],
                            "change_room_type": self.env["hms.room.type"]
                            .search([("name", "=", record[3])])
                            .id,
                            "room_no": self.env["hms_room_setup"]
                            .search([("name", "=", str(record[4]))])
                            .id,
                            "group_id": record[5],
                            "agent_id": self.env["hmslite.agentsetup"]
                            .search([("name", "=", record[6])])
                            .id,
                            "company_id": self.env["hmslite.companysetup"]
                            .search([("name", "=", record[7])])
                            .id,
                            "special_request": "<p><br></p>",
                            # 'order_line': sales_lines
                        }
                    )
                    reservation_id.append(new_reservation.id)

            if reservation_id:
                return {
                    "type": "ir.actions.client",
                    "tag": "reload",
                }
            else:
                raise UserError(_("No reservation created from the file."))
        else:
            raise UserError(_("Please choose a file to import."))

    def download_excel(self):
        base_url = self.env["ir.config_parameter"].sudo().get_param("web.base.url")
        url = base_url + "/hotelia/download_excel/"
        return {
            "type": "ir.actions.act_url",
            "url": url,
        }
