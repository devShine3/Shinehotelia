from datetime import datetime, timedelta
from odoo import models, fields, api


class NightAuditBill(models.TransientModel):
    _name = "night.audit.wizard"
    _description = "Night Audit Bill"

    def _today_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=0)
        return new_date

    report_date = fields.Datetime("Report Date", default=_today_date, required=True)

    def action_print_nab_report(self):
        data = {
            "form": {
                "report_date": self.report_date,
            }
        }
        return (
            self.env.ref("hotelia.action_nab_report_template")
            .with_context(landscape=True)
            .report_action(self, data=data)
        )
