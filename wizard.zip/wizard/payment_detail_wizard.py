from datetime import date
from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime, timedelta, date
from odoo.http import request


class PaymentDetailReport(models.TransientModel):
    _name = "payment.detail.wizard"
    _description = "Payment Detail Report"
    _inherit = ["portal.mixin"]

    def _today_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=0)
        return new_date

    report_date = fields.Datetime("Report Date :", default=_today_date)
    date_from = fields.Date(string="From Date :")
    date_to = fields.Date(string="To Date :")
    report_type = fields.Selection(
        [
            ("all", "All"),
            ("user", "By User ID"),
            ("payment", "By Payment Type"),
        ],
        default="all",
    )

    all_or_agent = fields.Selection(
        [
            ("all", "All"),
            ("agent", "Agent"),
        ],
        default="all",
    )
    agent = fields.Many2one("hmslite.agentsetup")
    user_id = fields.Many2one("res.users", default=lambda self: self.env.user)
    payment_type = fields.Many2one("hotel.payment")

    def action_print_pd_report(self):
        data = {}
        data["form"] = self.read()[0]
        return (
            self.env.ref("hotelia.action_pd_report_template")
            .with_context(landscape=True)
            .report_action(self, data=data)
        )

    def preview_payment(self):
        print("preview_payment")
        data = {}
        data["form"] = self.read()[0]

        action_pd_report_template = self.env["report.hotelia.report_payment_detail"]
        pd_data = {
            "data": data["form"],
            "lines": action_pd_report_template.get_lines(data.get("form")),
        }

        print_data = data

        request.session["pd_data"] = pd_data
        request.session["print_data"] = print_data

        self.ensure_one()
        return {
            "type": "ir.actions.act_url",
            "target": "",
            "url": self.get_portal_url(),
        }

    def _compute_access_url(self):
        super(PaymentDetailReport, self)._compute_access_url()
        for pd in self.filtered(lambda pd: pd.is_pd()):
            pd.access_url = "/my/payment_detail/report"

    def is_pd(self):
        correct_pd = False
        if self:
            correct_pd = True
        return correct_pd
