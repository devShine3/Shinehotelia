from datetime import date
from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime, timedelta, date
from odoo.http import request


class DepartureReport(models.TransientModel):
    _name = "departure.wizard"
    _description = "Departure List"
    _inherit = ["portal.mixin"]

    def _today_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=0)
        return new_date

    report_date = fields.Datetime("Report Date :", default=_today_date)
    date_from = fields.Date(string="From")
    date_to = fields.Date(string="To")

    def action_print_dp_report(self):
        data = {}
        data["form"] = self.read(["date_from", "report_date", "date_to"])[0]
        return (
            self.env.ref("hotelia.action_dp_report_template")
            .with_context(landscape=True)
            .report_action(self, data=data)
        )

    def preview_departure(self):
        print("preview_departure")
        data = {}
        data["form"] = self.read(["date_from", "report_date", "date_to"])[0]

        action_dp_report_template = self.env["report.hotelia.report_departure"]
        dp_data = {
            "data": data["form"],
            "lines": action_dp_report_template.get_lines(data.get("form")),
        }

        print_data = data

        request.session["dp_data"] = dp_data
        request.session["print_data"] = print_data

        self.ensure_one()
        return {
            "type": "ir.actions.act_url",
            "target": "",
            "url": self.get_portal_url(),
        }

    def _compute_access_url(self):
        super(DepartureReport, self)._compute_access_url()
        for departure in self.filtered(lambda departure: departure.is_departure()):
            departure.access_url = "/my/departure/report"

    def is_departure(self):
        correct_departure = False
        if self:
            correct_departure = True
        return correct_departure
