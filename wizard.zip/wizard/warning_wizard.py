from odoo import models, fields, api, _


class MessageWizard(models.TransientModel):
    _name = "warning.wizard"

    message = fields.Text("Message", required=True)

    def action_ok(self):
        """close wizard"""
        return {"type": "ir.actions.act_window_close"}
