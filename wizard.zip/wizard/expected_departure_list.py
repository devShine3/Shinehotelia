from datetime import date
from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime, timedelta, date
from odoo.http import request


class EDepartureReport(models.TransientModel):
    _name = "expected.departure.wizard"
    _description = "Departure List"
    _inherit = ["portal.mixin"]

    def _today_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=0)
        return new_date

    report_date = fields.Datetime("Report Date :", default=_today_date)
    date_from = fields.Date(string="Choose Date:")
    # date_to = fields.Date(string="To")

    def action_print_edp_report(self):
        data = {}
        data["form"] = self.read(["date_from", "report_date"])[0]
        return (
            self.env.ref("hotelia.action_edp_report_template")
            .with_context(landscape=True)
            .report_action(self, data=data)
        )

    def preview_expected_depature(self):
        print("preview_expected_depature")
        data = {}
        data["form"] = self.read(["date_from", "report_date"])[0]

        action_edp_report_template = self.env["report.hotelia.report_edeparture"]
        dp_data = {
            "data": data["form"],
            "lines": action_edp_report_template.get_lines(data.get("form")),
        }

        print_data = data

        request.session["dp_data"] = dp_data
        request.session["print_data"] = print_data

        self.ensure_one()
        return {
            "type": "ir.actions.act_url",
            "target": "",
            "url": self.get_portal_url(),
        }

    def _compute_access_url(self):
        super(EDepartureReport, self)._compute_access_url()
        for edeparture in self.filtered(lambda edeparture: edeparture.is_edeparture()):
            edeparture.access_url = "/my/expected_departure/report"

    def is_edeparture(self):
        correct_edeparture = False
        if self:
            correct_edeparture = True
        return correct_edeparture
