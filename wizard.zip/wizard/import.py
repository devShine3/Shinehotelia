import datetime

from odoo import models, fields, _
import openpyxl
import base64
from io import BytesIO
from odoo.exceptions import UserError


class ImportCustomerWizard(models.TransientModel):
    _name = "import.reservation.wizard"
    file = fields.Binary(string="File", required=True)

    def import_reservation(self):
        reservation_id = []
        try:
            wb = openpyxl.load_workbook(
                filename=BytesIO(base64.b64decode(self.file)), read_only=True
            )
            ws = wb.active

            index = 0
            vals_list = []
            reservation_order_list = []
            for record in ws.iter_rows(
                min_row=2, max_row=None, min_col=None, max_col=None, values_only=True
            ):
                values = {}
                reservation_order = {}

                values[index] = {
                    "name": record[0],
                    "guest_name": record[1],
                    "arrival": record[2],
                    "departure": record[3],
                    "room_type": record[4],
                    # 'room_no': record[5],
                    # 'group_id': record[6],
                    # 'agent_id': record[7],
                    # 'company_id': record[8],
                }
                reservation_order[index] = {
                    "name": record[0],
                    "guest_name": record[1],
                    "arrival": record[2],
                    "departure": record[3],
                    "room_type": record[4],
                    # 'room_no': record[5],
                    # 'group_id': record[6],
                    # 'agent_id': record[7],
                    # 'company_id': record[8],
                }

                vals_list.append(values[index])
                if reservation_order[index] not in reservation_order_list:
                    reservation_order_list.append(reservation_order[index])
                index = index + 1

            # unique_duplicates = list(set(sales_order_list))

            for rsv in reservation_order_list:
                stm = self.env["hotel.reservation"].create(
                    {
                        "name": rsv["name"],
                        "guest_name": self.env["hotel.guest"]
                        .search([("name", "=", rsv["guest_name"])])
                        .name,
                        "arrival": rsv["arrival"],
                        "departure": rsv["departure"],
                        "room_type": rsv["room_type"],
                        # 'room_no': self.env['hms_room_setup'].search([('name', '=', rsv['room_no'])]).name,
                        # 'group_id': rsv['group_id'],
                        # 'agent_id': self.env['hmslite.agentsetup'].search([('name', '=', rsv['agent_id'])]).name,
                        # 'company_id': self.env['hmslite.companysetup'].search([('name', '=', rsv['company_id'])]).name,
                        # 'order_line': sales_lines
                    }
                )
                reservation_id.append(stm.id)

            if reservation_id:
                return {
                    "type": "ir.actions.act_window",
                    "name": "Imported",
                    "view_mode": "tree",
                    "res_model": "hotel.reservation",
                    "domain": [("id", "in", reservation_id)],
                    "context": "{'create': False}",
                }
            else:
                raise UserError(_("Unsupported File Type"))
        except:
            raise UserError(_("Please insert a valid file"))
