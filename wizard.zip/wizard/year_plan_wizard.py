from datetime import date
from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime, timedelta, date
from datetime import date as dt
from odoo.http import request


class YearPlanReport(models.TransientModel):
    _name = "year.plan.wizard"
    _description = "Year Plan Report"
    _inherit = ["portal.mixin"]

    def _today_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=0)
        return new_date

    report_date = fields.Datetime("Report Date :", default=_today_date)

    def _get_available_years(self):
        today_date = dt.today()
        today = datetime.strptime(str(today_date), "%Y-%m-%d").date()
        current_month = today.month
        current_year = today.year
        years = [
            (str(year), str(year))
            for year in range(current_year, current_year - 10, -1)
        ]
        return years

    year = fields.Selection(selection="_get_available_years", string="Choose Year : ")

    def action_print_yp_report(self):
        data = {}
        data["form"] = self.read(["year", "report_date"])[0]
        return self.env.ref("hotelia.action_yp_report_template").report_action(
            self, data=data
        )

    def preview_year_plan(self):
        data = {}
        data["form"] = self.read(["year", "report_date"])[0]

        action_yp_report_template = self.env["report.hotelia.report_year_plan"]
        yp_data = {
            "data": data["form"],
            "lines": action_yp_report_template.get_lines(data.get("form")),
        }

        print_data = data

        request.session["yp_data"] = yp_data
        request.session["print_data"] = print_data

        self.ensure_one()
        return {
            "type": "ir.actions.act_url",
            "target": "",
            "url": self.get_portal_url(),
        }

    def _compute_access_url(self):
        super(YearPlanReport, self)._compute_access_url()
        for yp in self.filtered(lambda yp: yp.is_yp()):
            yp.access_url = "/my/year_plan/report"

    def is_yp(self):
        correct_yp = False
        if self:
            correct_yp = True
        return correct_yp
