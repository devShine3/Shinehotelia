from datetime import date
from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime, timedelta, date
from odoo.http import request


class CashierSummaryReport(models.TransientModel):
    _name = "cashier.report.wizard"
    _description = "Cashier Summary Report"
    _inherit = ["portal.mixin"]

    def _today_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=0)
        return new_date

    report_date = fields.Datetime("Report Date :", default=_today_date)
    date_from = fields.Date(string="From Date :")
    date_to = fields.Date(string="To Date :")
    report_type = fields.Selection(
        [
            ("alls", "All - Summary"),
            ("alldetail", "All - Detail"),
        ],
        default="alldetail",
    )

    def action_print_cashier_summary_report(self):
        data = {}
        data["form"] = self.read(
            ["date_from", "date_to", "report_date", "report_type"]
        )[0]
        return (
            self.env.ref("hotelia.action_cashier_summary_report_template")
            .with_context(landscape=True)
            .report_action(self, data=data)
        )

    def action_print_cashier_summary_report_xlsx(self):
        data = {}
        data["form"] = self.read(
            ["date_from", "date_to", "report_date", "report_type"]
        )[0]
        return (
            self.env.ref("hotelia.action_cashier_summary_report_template_xlsx")
            .with_context(landscape=True)
            .report_action(self, data=data)
        )

    def preview_cashier_summary(self):
        data = {}
        data["form"] = self.read(
            ["date_from", "date_to", "report_date", "report_type"]
        )[0]

        action_cashier_summary_report_template = self.env[
            "report.hotelia.report_cashier_summary"
        ]
        cs_data = {
            "data": data["form"],
            "lines": action_cashier_summary_report_template.get_lines(data.get("form")),
        }

        print_data = data

        request.session["cs_data"] = cs_data
        request.session["print_data"] = print_data

        self.ensure_one()
        return {
            "type": "ir.actions.act_url",
            "target": "",
            "url": self.get_portal_url(),
        }

    def _compute_access_url(self):
        super(CashierSummaryReport, self)._compute_access_url()
        for cs_data in self.filtered(lambda cs_data: cs_data.is_cs_data()):
            cs_data.access_url = "/my/cashier_summary/report"

    def is_cs_data(self):
        correct_cs_data = False
        if self:
            correct_cs_data = True
        return correct_cs_data
