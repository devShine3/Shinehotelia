import datetime
import time
from odoo import models, fields, _
import openpyxl
import base64
from io import BytesIO
from odoo.exceptions import UserError


class ImportRegWizard(models.TransientModel):
    _name = "import.reg.wizard"

    file = fields.Binary(string="File", required=True)

    def import_reg(self):
        registration_id = []
        # try:
        wb = openpyxl.load_workbook(
            filename=BytesIO(base64.b64decode(self.file)), read_only=True
        )
        ws = wb.active
        for record in ws.iter_rows(
            min_row=2, max_row=None, min_col=None, max_col=None, values_only=True
        ):
            reservation = self.env["hms.registration"].search(
                [("name", "=", record[0])]
            )
            if not reservation:
                new_reg = self.env["hms.registration"].create(
                    {
                        "name": record[0],
                        "guest_name_testing": record[1],
                        "guest_name": record[1],
                        "guest_key": self.env["hotel.guest"]
                        .search([("name", "=", record[1])], limit=1)
                        .id,
                        "reg_arrival": record[2],
                        "reg_departure": record[3],
                        "reg_room_type": self.env["hms.room.type"]
                        .search([("name", "=", record[4])])
                        .id,
                        "reg_room_no": self.env["hms_room_setup"]
                        .search([("name", "=", str(record[5]))])
                        .id,
                        "reg_group_id": record[6],
                        "reg_agent_id": self.env["hmslite.agentsetup"]
                        .search([("name", "=", record[7])])
                        .id,
                        "reg_company_id": self.env["hmslite.companysetup"]
                        .search([("name", "=", record[8])])
                        .id,
                        # 'order_line': sales_lines
                    }
                )
                registration_id.append(new_reg.id)

        if registration_id:
            return {
                "type": "ir.actions.act_window",
                "name": "Reservation Imported",
                "view_mode": "tree",
                "res_model": "hms.registration",
                "domain": [("id", "in", registration_id)],
                # 'context': "{'create': False}"
                "context": self._context,
            }
        else:
            raise UserError(_("Unsupported File Type or Existing records"))
        # except:
        #     raise UserError(_('Please insert a valid file'))
