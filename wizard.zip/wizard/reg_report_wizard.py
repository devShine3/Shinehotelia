from datetime import date
from odoo import models, fields, api, _
from odoo.http import request
from odoo.exceptions import UserError
from datetime import datetime, timedelta, date


class RegistrationReport(models.TransientModel):
    _name = "hotel.registration.report.wizard"
    _description = "Hms Registration Report"
    _inherit = ["portal.mixin"]

    def _today_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=0)
        return new_date

    report_date = fields.Datetime("Report Date :", default=_today_date)
    date_filter = fields.Selection(
        [("rsvdate", "Registration Date"), ("arrdate", "Arrival Date")],
        String="Date Filter",
        default="rsvdate",
    )
    date_from = fields.Date(string="From")
    date_to = fields.Date(string="To")
    rsv_type = fields.Selection(
        [
            ("registration", "Registered"),
            ("cancel", "Cancelled"),
        ],
        String="Registrarion Type",
        default="registration",
    )
    roomtype_ids = fields.Many2one("hms.room.type", String="Room Type")

    def action_print_reg_report(self):
        data = {}
        data["form"] = self.read(
            [
                "date_from",
                "date_to",
                "roomtype_ids",
                "rsv_type",
                "date_filter",
                "report_date",
            ]
        )[0]
        return self.env.ref(
            "hotelia.action_registration_report_template"
        ).report_action(self, data=data)

    def preview_registration(self):
        print("preview_registration")
        data = {}
        data["form"] = self.read(
            [
                "date_from",
                "date_to",
                "roomtype_ids",
                "rsv_type",
                "date_filter",
                "report_date",
            ]
        )[0]

        registration_report_template = self.env[
            "report.hotelia.report_registration_details"
        ]
        registration_data = {
            "data": data["form"],
            "lines": registration_report_template.get_lines(data.get("form")),
        }

        print_data = data

        request.session["registration_data"] = registration_data
        request.session["print_data"] = print_data

        self.ensure_one()
        return {
            "type": "ir.actions.act_url",
            "target": "",
            "url": self.get_portal_url(),
        }

    def _compute_access_url(self):
        super(RegistrationReport, self)._compute_access_url()
        for registration in self.filtered(
            lambda registration: registration.is_registration()
        ):
            registration.access_url = "/my/registrations/report"

    def is_registration(self):
        correct_registration = False
        if self:
            correct_registration = True
        return correct_registration
