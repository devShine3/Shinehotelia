from datetime import date
from odoo import models, fields, api, _
from odoo.http import request
from odoo.exceptions import UserError
from datetime import datetime, timedelta, date


class TransactionReport(models.TransientModel):
    _name = "hmstransaction.report.wizard"
    _description = "Hms Transaction Report"
    _inherit = ["portal.mixin"]

    def _today_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=0)
        return new_date

    report_date = fields.Datetime("Report Date :", default=_today_date)
    date_from = fields.Date(string="From Date :")
    date_to = fields.Date(string="To Date :")

    report_type = fields.Selection(
        [
            ("summary", "Summary"),
            ("transaction", "Detail By Transaction Type"),
            ("bill", "Detail by Bill No"),
        ],
        default="summary",
    )

    def action_print_transaction_report(self):
        data = {}
        data["form"] = self.read(
            ["date_from", "date_to", "report_date", "report_type"]
        )[0]
        return (
            self.env.ref("hotelia.action_transaction_report_template")
            .with_context(landscape=True)
            .report_action(self, data=data)
        )

    def action_print_transaction_report_xlsx(self):
        data = {}
        data["form"] = self.read(
            ["date_from", "date_to", "report_date", "report_type"]
        )[0]
        return self.env.ref(
            "hotelia.action_transaction_report_template_xlsx"
        ).report_action(self, data=data)

    def preview_transaction(self):
        data = {}
        data["form"] = self.read(
            ["date_from", "date_to", "report_date", "report_type"]
        )[0]

        transaction_report_template = self.env[
            "report.hotelia.report_transaction_details"
        ]
        transaction_data = {
            "data": data["form"],
            "lines": transaction_report_template.get_lines(data.get("form")),
        }

        print_data = data

        request.session["transaction_data"] = transaction_data
        request.session["print_data"] = print_data

        self.ensure_one()
        return {
            "type": "ir.actions.act_url",
            "target": "",
            "url": self.get_portal_url(),
        }

    def _compute_access_url(self):
        super(TransactionReport, self)._compute_access_url()
        for transaction in self.filtered(
            lambda transaction: transaction.is_transaction()
        ):
            transaction.access_url = "/my/transactions/report"

    def is_transaction(self):
        correct_transaction = False
        if self:
            correct_transaction = True
        return correct_transaction
