from datetime import date
from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime, timedelta, date
from odoo.http import request


class GuestLedgerReport(models.TransientModel):
    _name = "guest.ledger.wizard"
    _description = "Guest Ledger Report"
    _inherit = ["portal.mixin"]

    def _today_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=0)
        return new_date

    report_date = fields.Datetime("Report Date :", default=_today_date)
    date_to = fields.Date(string="Departure Date :")
    report_type = fields.Selection(
        [
            ("summary", "All - Summary"),
            ("detail", "All - Detail"),
        ],
        default="summary",
    )
    report_format = fields.Selection(
        [
            ("all", "All In-House Guest"),
            ("departure", "By Departure Date"),
        ],
        default="all",
    )

    def action_print_guest_ledger_report(self):
        data = {}
        data["form"] = self.read(
            ["report_format", "date_to", "report_date", "report_type"]
        )[0]
        return (
            self.env.ref("hotelia.action_guest_ledger_report_template")
            .with_context(landscape=True)
            .report_action(self, data=data)
        )

    def preview_guest_ledger(self):
        data = {}
        data["form"] = self.read(
            ["report_format", "date_to", "report_date", "report_type"]
        )[0]

        action_guest_ledger_report_template = self.env[
            "report.hotelia.report_guest_ledger"
        ]
        guest_data = {
            "data": data["form"],
            "lines": action_guest_ledger_report_template.get_lines(data.get("form")),
        }

        print_data = data

        request.session["guest_data"] = guest_data
        request.session["print_data"] = print_data

        self.ensure_one()
        return {
            "type": "ir.actions.act_url",
            "target": "",
            "url": self.get_portal_url(),
        }

    def _compute_access_url(self):
        super(GuestLedgerReport, self)._compute_access_url()
        for guest in self.filtered(lambda guest: guest.is_guest()):
            guest.access_url = "/my/guest_ledger/report"

    def is_guest(self):
        correct_guest = False
        if self:
            correct_guest = True
        return correct_guest
