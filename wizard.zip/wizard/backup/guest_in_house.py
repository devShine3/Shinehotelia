from odoo import api, fields, models, tools, _


class GuestInHousetWizard(models.TransientModel):
    _name = "hotel.reservation.inhouse.wizard"
    choose_date = fields.Date(String="Choose Date")
    type_reservation = fields.Selection(
        [
            ("all", "All"),
            ("group", "Group"),
            ("agent", "Agent"),
            ("company", "Company"),
        ],
        default="all",
    )
    agent = fields.Many2one("hmslite.agentsetup", String="Agent")
    company = fields.Many2one("hmslite.companysetup", String="Company")
    group = fields.Many2one("hms.groupreserve", String="Group")

    def action_guest_in_house_report(self):
        data = {}
        data["form"] = self.read()[0]
        return self.env.ref("hotelia.action_guest_in_house_template").report_action(
            self, data=data
        )
