from datetime import date
from odoo import models, fields, api, _
from odoo.http import request
from odoo.exceptions import UserError
from datetime import datetime, timedelta, date


class SaleSummaryReport(models.TransientModel):
    _name = "hmssalesummary.report.wizard"
    _description = "Hms Sale Summary Report"
    _inherit = ["portal.mixin"]

    def _today_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=0)
        return new_date

    report_date = fields.Datetime("Report Date :", default=_today_date)
    date_from = fields.Date(string="From Date :")
    date_to = fields.Date(string="To Date :")
    all_or_trans = fields.Selection(
        [
            ("all", "All"),
            ("transaction", "By Transaction Type"),
        ],
        default="all",
    )
    trans_type = fields.Many2one("hms.transaction")
    report_type = fields.Selection(
        [
            ("user", "By User Id"),
            ("type", "By Type"),
            ("base", "By Base Currency"),
        ],
        default="user",
    )
    payment_status = fields.Selection(
        [
            ("all", "All"),
            ("paid", "Paid"),
            ("unpaid", "Unpaid"),
        ],
        default="all",
    )

    def action_print_sale_summary_report(self):
        data = {}
        data["form"] = self.read(
            [
                "date_from",
                "date_to",
                "report_date",
                "report_type",
                "all_or_trans",
                "trans_type",
                "payment_status",
            ]
        )[0]
        return (
            self.env.ref("hotelia.action_sale_summary_report_template")
            .with_context(landscape=True)
            .report_action(self, data=data)
        )

    def preview_sale_summary(self):
        data = {}
        data["form"] = self.read(
            [
                "date_from",
                "date_to",
                "report_date",
                "report_type",
                "all_or_trans",
                "trans_type",
                "payment_status",
            ]
        )[0]

        sale_summary_report_template = self.env[
            "report.hotelia.report_sale_summary_details"
        ]
        sale_summary_data = {
            "data": data["form"],
            "lines": sale_summary_report_template.get_lines(data.get("form")),
        }

        print_data = data

        request.session["sale_summary_data"] = sale_summary_data
        request.session["print_data"] = print_data

        self.ensure_one()
        return {
            "type": "ir.actions.act_url",
            "target": "",
            "url": self.get_portal_url(),
        }

    def _compute_access_url(self):
        super(SaleSummaryReport, self)._compute_access_url()
        for sale_summary in self.filtered(
            lambda sale_summary: sale_summary.is_sale_summary()
        ):
            sale_summary.access_url = "/my/sale_summary/report"

    def is_sale_summary(self):
        correct_sale_summary = False
        if self:
            correct_sale_summary = True
        return correct_sale_summary
