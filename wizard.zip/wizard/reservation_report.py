# -*- coding: utf-8 -*-
# Copyright 2017-2020 Akretion France (http://www.akretion.com/)
# @author: Alexis de Lattre <alexis.delattre@akretion.com>
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).


from datetime import date
from odoo import models, fields, api, _
from odoo.http import request
from odoo.exceptions import UserError
from datetime import datetime, timedelta, date


class ReservationReport(models.TransientModel):
    _name = "hotel.reservation.report.wizard"
    _description = "Hms Reservation Report"
    _inherit = ["portal.mixin"]

    def _today_date(self):
        current_date = datetime.now()
        new_date = current_date + timedelta(days=0)
        return new_date

    date_filter = fields.Selection(
        [("rsvdate", "Reservation Date"), ("arrdate", "Arrival Date")],
        String="Date Filter",
        default="rsvdate",
    )
    date_from = fields.Date(string="From")
    date_to = fields.Date(string="To")
    rsv_type = fields.Selection(
        [
            ("open", "Open"),
            ("confirmed", "Confirmed"),
            ("waitlist", "Waitlist"),
            ("cancel", "Cancel"),
            ("noshow", "No Show"),
            ("check_out", "Check Out"),
        ],
        String="Reservation Type",
    )
    roomtype_ids = fields.Many2one("hms.room.type", String="Room Type")

    report_date = fields.Datetime("Report Date :", default=_today_date)

    def action_print_reservation_report(self):
        data = {}
        data["form"] = self.read(
            [
                "date_from",
                "date_to",
                "roomtype_ids",
                "rsv_type",
                "date_filter",
                "report_date",
            ]
        )[0]
        return self.env.ref("hotelia.action_reservation_report_template").report_action(
            self, data=data
        )

    def preview_reservation(self):
        data = {}
        data["form"] = self.read(
            [
                "date_from",
                "date_to",
                "roomtype_ids",
                "rsv_type",
                "date_filter",
                "report_date",
            ]
        )[0]

        reservation_report_template = self.env[
            "report.hotelia.report_reservation_details"
        ]
        reservation_data = {
            "data": data["form"],
            "lines": reservation_report_template.get_lines(data.get("form")),
        }

        print_data = data

        request.session["reservation_data"] = reservation_data
        request.session["print_data"] = print_data

        self.ensure_one()
        return {
            "type": "ir.actions.act_url",
            "target": "",
            "url": self.get_portal_url(),
        }

    def print_preview(self, data):
        print_data = data
        return self.env.ref("hotelia.action_reservation_report_template").report_action(
            self, data=print_data
        )

    def _compute_access_url(self):
        super(ReservationReport, self)._compute_access_url()
        for reservation in self.filtered(
            lambda reservation: reservation.is_reservation()
        ):
            reservation.access_url = "/my/reservations/report"

    def is_reservation(self):
        correct_reservation = False
        if self:
            correct_reservation = True
        return correct_reservation
